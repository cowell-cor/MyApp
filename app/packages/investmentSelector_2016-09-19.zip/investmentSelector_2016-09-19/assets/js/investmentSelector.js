(function($,jQuery){
/*!
 * Bootstrap v3.3.5 (http://getbootstrap.com)
 * Copyright 2011-2016 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */

/*!
 * Generated using the Bootstrap Customizer (http://getbootstrap.com/customize/?id=4a9d31470d6708ed0aab40cba86c559b)
 * Config saved to config.json and https://gist.github.com/4a9d31470d6708ed0aab40cba86c559b
 */
if("undefined"==typeof jQuery)throw new Error("Bootstrap's JavaScript requires jQuery");+function(t){"use strict";var e=t.fn.jquery.split(" ")[0].split(".");if(e[0]<2&&e[1]<9||1==e[0]&&9==e[1]&&e[2]<1||e[0]>2)throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher, but lower than version 3")}(jQuery),+function(t){"use strict";function e(e){return this.each(function(){var i=t(this),n=i.data("bs.alert");n||i.data("bs.alert",n=new o(this)),"string"==typeof e&&n[e].call(i)})}var i='[data-dismiss="alert"]',o=function(e){t(e).on("click",i,this.close)};o.VERSION="3.3.6",o.TRANSITION_DURATION=150,o.prototype.close=function(e){function i(){a.detach().trigger("closed.bs.alert").remove()}var n=t(this),s=n.attr("data-target");s||(s=n.attr("href"),s=s&&s.replace(/.*(?=#[^\s]*$)/,""));var a=t(s);e&&e.preventDefault(),a.length||(a=n.closest(".alert")),a.trigger(e=t.Event("close.bs.alert")),e.isDefaultPrevented()||(a.removeClass("in"),t.support.transition&&a.hasClass("fade")?a.one("bsTransitionEnd",i).emulateTransitionEnd(o.TRANSITION_DURATION):i())};var n=t.fn.alert;t.fn.alert=e,t.fn.alert.Constructor=o,t.fn.alert.noConflict=function(){return t.fn.alert=n,this},t(document).on("click.bs.alert.data-api",i,o.prototype.close)}(jQuery),+function(t){"use strict";function e(e){return this.each(function(){var o=t(this),n=o.data("bs.button"),s="object"==typeof e&&e;n||o.data("bs.button",n=new i(this,s)),"toggle"==e?n.toggle():e&&n.setState(e)})}var i=function(e,o){this.$element=t(e),this.options=t.extend({},i.DEFAULTS,o),this.isLoading=!1};i.VERSION="3.3.6",i.DEFAULTS={loadingText:"loading..."},i.prototype.setState=function(e){var i="disabled",o=this.$element,n=o.is("input")?"val":"html",s=o.data();e+="Text",null==s.resetText&&o.data("resetText",o[n]()),setTimeout(t.proxy(function(){o[n](null==s[e]?this.options[e]:s[e]),"loadingText"==e?(this.isLoading=!0,o.addClass(i).attr(i,i)):this.isLoading&&(this.isLoading=!1,o.removeClass(i).removeAttr(i))},this),0)},i.prototype.toggle=function(){var t=!0,e=this.$element.closest('[data-toggle="buttons"]');if(e.length){var i=this.$element.find("input");"radio"==i.prop("type")?(i.prop("checked")&&(t=!1),e.find(".active").removeClass("active"),this.$element.addClass("active")):"checkbox"==i.prop("type")&&(i.prop("checked")!==this.$element.hasClass("active")&&(t=!1),this.$element.toggleClass("active")),i.prop("checked",this.$element.hasClass("active")),t&&i.trigger("change")}else this.$element.attr("aria-pressed",!this.$element.hasClass("active")),this.$element.toggleClass("active")};var o=t.fn.button;t.fn.button=e,t.fn.button.Constructor=i,t.fn.button.noConflict=function(){return t.fn.button=o,this},t(document).on("click.bs.button.data-api",'[data-toggle^="button"]',function(i){var o=t(i.target);o.hasClass("btn")||(o=o.closest(".btn")),e.call(o,"toggle"),t(i.target).is('input[type="radio"]')||t(i.target).is('input[type="checkbox"]')||i.preventDefault()}).on("focus.bs.button.data-api blur.bs.button.data-api",'[data-toggle^="button"]',function(e){t(e.target).closest(".btn").toggleClass("focus",/^focus(in)?$/.test(e.type))})}(jQuery),+function(t){"use strict";function e(e){return this.each(function(){var o=t(this),n=o.data("bs.carousel"),s=t.extend({},i.DEFAULTS,o.data(),"object"==typeof e&&e),a="string"==typeof e?e:s.slide;n||o.data("bs.carousel",n=new i(this,s)),"number"==typeof e?n.to(e):a?n[a]():s.interval&&n.pause().cycle()})}var i=function(e,i){this.$element=t(e),this.$indicators=this.$element.find(".carousel-indicators"),this.options=i,this.paused=null,this.sliding=null,this.interval=null,this.$active=null,this.$items=null,this.options.keyboard&&this.$element.on("keydown.bs.carousel",t.proxy(this.keydown,this)),"hover"==this.options.pause&&!("ontouchstart"in document.documentElement)&&this.$element.on("mouseenter.bs.carousel",t.proxy(this.pause,this)).on("mouseleave.bs.carousel",t.proxy(this.cycle,this))};i.VERSION="3.3.6",i.TRANSITION_DURATION=600,i.DEFAULTS={interval:5e3,pause:"hover",wrap:!0,keyboard:!0},i.prototype.keydown=function(t){if(!/input|textarea/i.test(t.target.tagName)){switch(t.which){case 37:this.prev();break;case 39:this.next();break;default:return}t.preventDefault()}},i.prototype.cycle=function(e){return e||(this.paused=!1),this.interval&&clearInterval(this.interval),this.options.interval&&!this.paused&&(this.interval=setInterval(t.proxy(this.next,this),this.options.interval)),this},i.prototype.getItemIndex=function(t){return this.$items=t.parent().children(".item"),this.$items.index(t||this.$active)},i.prototype.getItemForDirection=function(t,e){var i=this.getItemIndex(e),o="prev"==t&&0===i||"next"==t&&i==this.$items.length-1;if(o&&!this.options.wrap)return e;var n="prev"==t?-1:1,s=(i+n)%this.$items.length;return this.$items.eq(s)},i.prototype.to=function(t){var e=this,i=this.getItemIndex(this.$active=this.$element.find(".item.active"));return t>this.$items.length-1||0>t?void 0:this.sliding?this.$element.one("slid.bs.carousel",function(){e.to(t)}):i==t?this.pause().cycle():this.slide(t>i?"next":"prev",this.$items.eq(t))},i.prototype.pause=function(e){return e||(this.paused=!0),this.$element.find(".next, .prev").length&&t.support.transition&&(this.$element.trigger(t.support.transition.end),this.cycle(!0)),this.interval=clearInterval(this.interval),this},i.prototype.next=function(){return this.sliding?void 0:this.slide("next")},i.prototype.prev=function(){return this.sliding?void 0:this.slide("prev")},i.prototype.slide=function(e,o){var n=this.$element.find(".item.active"),s=o||this.getItemForDirection(e,n),a=this.interval,r="next"==e?"left":"right",l=this;if(s.hasClass("active"))return this.sliding=!1;var h=s[0],d=t.Event("slide.bs.carousel",{relatedTarget:h,direction:r});if(this.$element.trigger(d),!d.isDefaultPrevented()){if(this.sliding=!0,a&&this.pause(),this.$indicators.length){this.$indicators.find(".active").removeClass("active");var p=t(this.$indicators.children()[this.getItemIndex(s)]);p&&p.addClass("active")}var c=t.Event("slid.bs.carousel",{relatedTarget:h,direction:r});return t.support.transition&&this.$element.hasClass("slide")?(s.addClass(e),s[0].offsetWidth,n.addClass(r),s.addClass(r),n.one("bsTransitionEnd",function(){s.removeClass([e,r].join(" ")).addClass("active"),n.removeClass(["active",r].join(" ")),l.sliding=!1,setTimeout(function(){l.$element.trigger(c)},0)}).emulateTransitionEnd(i.TRANSITION_DURATION)):(n.removeClass("active"),s.addClass("active"),this.sliding=!1,this.$element.trigger(c)),a&&this.cycle(),this}};var o=t.fn.carousel;t.fn.carousel=e,t.fn.carousel.Constructor=i,t.fn.carousel.noConflict=function(){return t.fn.carousel=o,this};var n=function(i){var o,n=t(this),s=t(n.attr("data-target")||(o=n.attr("href"))&&o.replace(/.*(?=#[^\s]+$)/,""));if(s.hasClass("carousel")){var a=t.extend({},s.data(),n.data()),r=n.attr("data-slide-to");r&&(a.interval=!1),e.call(s,a),r&&s.data("bs.carousel").to(r),i.preventDefault()}};t(document).on("click.bs.carousel.data-api","[data-slide]",n).on("click.bs.carousel.data-api","[data-slide-to]",n),t(window).on("load",function(){t('[data-ride="carousel"]').each(function(){var i=t(this);e.call(i,i.data())})})}(jQuery),+function(t){"use strict";function e(e){var i=e.attr("data-target");i||(i=e.attr("href"),i=i&&/#[A-Za-z]/.test(i)&&i.replace(/.*(?=#[^\s]*$)/,""));var o=i&&t(i);return o&&o.length?o:e.parent()}function i(i){i&&3===i.which||(t(n).remove(),t(s).each(function(){var o=t(this),n=e(o),s={relatedTarget:this};n.hasClass("open")&&(i&&"click"==i.type&&/input|textarea/i.test(i.target.tagName)&&t.contains(n[0],i.target)||(n.trigger(i=t.Event("hide.bs.dropdown",s)),i.isDefaultPrevented()||(o.attr("aria-expanded","false"),n.removeClass("open").trigger(t.Event("hidden.bs.dropdown",s)))))}))}function o(e){return this.each(function(){var i=t(this),o=i.data("bs.dropdown");o||i.data("bs.dropdown",o=new a(this)),"string"==typeof e&&o[e].call(i)})}var n=".dropdown-backdrop",s='[data-toggle="dropdown"]',a=function(e){t(e).on("click.bs.dropdown",this.toggle)};a.VERSION="3.3.6",a.prototype.toggle=function(o){var n=t(this);if(!n.is(".disabled, :disabled")){var s=e(n),a=s.hasClass("open");if(i(),!a){"ontouchstart"in document.documentElement&&!s.closest(".navbar-nav").length&&t(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(t(this)).on("click",i);var r={relatedTarget:this};if(s.trigger(o=t.Event("show.bs.dropdown",r)),o.isDefaultPrevented())return;n.trigger("focus").attr("aria-expanded","true"),s.toggleClass("open").trigger(t.Event("shown.bs.dropdown",r))}return!1}},a.prototype.keydown=function(i){if(/(38|40|27|32)/.test(i.which)&&!/input|textarea/i.test(i.target.tagName)){var o=t(this);if(i.preventDefault(),i.stopPropagation(),!o.is(".disabled, :disabled")){var n=e(o),a=n.hasClass("open");if(!a&&27!=i.which||a&&27==i.which)return 27==i.which&&n.find(s).trigger("focus"),o.trigger("click");var r=" li:not(.disabled):visible a",l=n.find(".dropdown-menu"+r);if(l.length){var h=l.index(i.target);38==i.which&&h>0&&h--,40==i.which&&h<l.length-1&&h++,~h||(h=0),l.eq(h).trigger("focus")}}}};var r=t.fn.dropdown;t.fn.dropdown=o,t.fn.dropdown.Constructor=a,t.fn.dropdown.noConflict=function(){return t.fn.dropdown=r,this},t(document).on("click.bs.dropdown.data-api",i).on("click.bs.dropdown.data-api",".dropdown form",function(t){t.stopPropagation()}).on("click.bs.dropdown.data-api",s,a.prototype.toggle).on("keydown.bs.dropdown.data-api",s,a.prototype.keydown).on("keydown.bs.dropdown.data-api",".dropdown-menu",a.prototype.keydown)}(jQuery),+function(t){"use strict";function e(e,o){return this.each(function(){var n=t(this),s=n.data("bs.modal"),a=t.extend({},i.DEFAULTS,n.data(),"object"==typeof e&&e);s||n.data("bs.modal",s=new i(this,a)),"string"==typeof e?s[e](o):a.show&&s.show(o)})}var i=function(e,i){this.options=i,this.$body=t(document.body),this.$element=t(e),this.$dialog=this.$element.find(".modal-dialog"),this.$backdrop=null,this.isShown=null,this.originalBodyPad=null,this.scrollbarWidth=0,this.ignoreBackdropClick=!1,this.options.remote&&this.$element.find(".modal-content").load(this.options.remote,t.proxy(function(){this.$element.trigger("loaded.bs.modal")},this))};i.VERSION="3.3.6",i.TRANSITION_DURATION=300,i.BACKDROP_TRANSITION_DURATION=150,i.DEFAULTS={backdrop:!0,keyboard:!0,show:!0},i.prototype.toggle=function(t){return this.isShown?this.hide():this.show(t)},i.prototype.show=function(e){var o=this,n=t.Event("show.bs.modal",{relatedTarget:e});this.$element.trigger(n),this.isShown||n.isDefaultPrevented()||(this.isShown=!0,this.checkScrollbar(),this.setScrollbar(),this.$body.addClass("modal-open"),this.escape(),this.resize(),this.$element.on("click.dismiss.bs.modal",'[data-dismiss="modal"]',t.proxy(this.hide,this)),this.$dialog.on("mousedown.dismiss.bs.modal",function(){o.$element.one("mouseup.dismiss.bs.modal",function(e){t(e.target).is(o.$element)&&(o.ignoreBackdropClick=!0)})}),this.backdrop(function(){var n=t.support.transition&&o.$element.hasClass("fade");o.$element.parent().length||o.$element.appendTo(o.$body),o.$element.show().scrollTop(0),o.adjustDialog(),n&&o.$element[0].offsetWidth,o.$element.addClass("in"),o.enforceFocus();var s=t.Event("shown.bs.modal",{relatedTarget:e});n?o.$dialog.one("bsTransitionEnd",function(){o.$element.trigger("focus").trigger(s)}).emulateTransitionEnd(i.TRANSITION_DURATION):o.$element.trigger("focus").trigger(s)}))},i.prototype.hide=function(e){e&&e.preventDefault(),e=t.Event("hide.bs.modal"),this.$element.trigger(e),this.isShown&&!e.isDefaultPrevented()&&(this.isShown=!1,this.escape(),this.resize(),t(document).off("focusin.bs.modal"),this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"),this.$dialog.off("mousedown.dismiss.bs.modal"),t.support.transition&&this.$element.hasClass("fade")?this.$element.one("bsTransitionEnd",t.proxy(this.hideModal,this)).emulateTransitionEnd(i.TRANSITION_DURATION):this.hideModal())},i.prototype.enforceFocus=function(){t(document).off("focusin.bs.modal").on("focusin.bs.modal",t.proxy(function(t){this.$element[0]===t.target||this.$element.has(t.target).length||this.$element.trigger("focus")},this))},i.prototype.escape=function(){this.isShown&&this.options.keyboard?this.$element.on("keydown.dismiss.bs.modal",t.proxy(function(t){27==t.which&&this.hide()},this)):this.isShown||this.$element.off("keydown.dismiss.bs.modal")},i.prototype.resize=function(){this.isShown?t(window).on("resize.bs.modal",t.proxy(this.handleUpdate,this)):t(window).off("resize.bs.modal")},i.prototype.hideModal=function(){var t=this;this.$element.hide(),this.backdrop(function(){t.$body.removeClass("modal-open"),t.resetAdjustments(),t.resetScrollbar(),t.$element.trigger("hidden.bs.modal")})},i.prototype.removeBackdrop=function(){this.$backdrop&&this.$backdrop.remove(),this.$backdrop=null},i.prototype.backdrop=function(e){var o=this,n=this.$element.hasClass("fade")?"fade":"";if(this.isShown&&this.options.backdrop){var s=t.support.transition&&n;if(this.$backdrop=t(document.createElement("div")).addClass("modal-backdrop "+n).appendTo(this.$body),this.$element.on("click.dismiss.bs.modal",t.proxy(function(t){return this.ignoreBackdropClick?void(this.ignoreBackdropClick=!1):void(t.target===t.currentTarget&&("static"==this.options.backdrop?this.$element[0].focus():this.hide()))},this)),s&&this.$backdrop[0].offsetWidth,this.$backdrop.addClass("in"),!e)return;s?this.$backdrop.one("bsTransitionEnd",e).emulateTransitionEnd(i.BACKDROP_TRANSITION_DURATION):e()}else if(!this.isShown&&this.$backdrop){this.$backdrop.removeClass("in");var a=function(){o.removeBackdrop(),e&&e()};t.support.transition&&this.$element.hasClass("fade")?this.$backdrop.one("bsTransitionEnd",a).emulateTransitionEnd(i.BACKDROP_TRANSITION_DURATION):a()}else e&&e()},i.prototype.handleUpdate=function(){this.adjustDialog()},i.prototype.adjustDialog=function(){var t=this.$element[0].scrollHeight>document.documentElement.clientHeight;this.$element.css({paddingLeft:!this.bodyIsOverflowing&&t?this.scrollbarWidth:"",paddingRight:this.bodyIsOverflowing&&!t?this.scrollbarWidth:""})},i.prototype.resetAdjustments=function(){this.$element.css({paddingLeft:"",paddingRight:""})},i.prototype.checkScrollbar=function(){var t=window.innerWidth;if(!t){var e=document.documentElement.getBoundingClientRect();t=e.right-Math.abs(e.left)}this.bodyIsOverflowing=document.body.clientWidth<t,this.scrollbarWidth=this.measureScrollbar()},i.prototype.setScrollbar=function(){var t=parseInt(this.$body.css("padding-right")||0,10);this.originalBodyPad=document.body.style.paddingRight||"",this.bodyIsOverflowing&&this.$body.css("padding-right",t+this.scrollbarWidth)},i.prototype.resetScrollbar=function(){this.$body.css("padding-right",this.originalBodyPad)},i.prototype.measureScrollbar=function(){var t=document.createElement("div");t.className="modal-scrollbar-measure",this.$body.append(t);var e=t.offsetWidth-t.clientWidth;return this.$body[0].removeChild(t),e};var o=t.fn.modal;t.fn.modal=e,t.fn.modal.Constructor=i,t.fn.modal.noConflict=function(){return t.fn.modal=o,this},t(document).on("click.bs.modal.data-api",'[data-toggle="modal"]',function(i){var o=t(this),n=o.attr("href"),s=t(o.attr("data-target")||n&&n.replace(/.*(?=#[^\s]+$)/,"")),a=s.data("bs.modal")?"toggle":t.extend({remote:!/#/.test(n)&&n},s.data(),o.data());o.is("a")&&i.preventDefault(),s.one("show.bs.modal",function(t){t.isDefaultPrevented()||s.one("hidden.bs.modal",function(){o.is(":visible")&&o.trigger("focus")})}),e.call(s,a,this)})}(jQuery),+function(t){"use strict";function e(e){return this.each(function(){var o=t(this),n=o.data("bs.tooltip"),s="object"==typeof e&&e;(n||!/destroy|hide/.test(e))&&(n||o.data("bs.tooltip",n=new i(this,s)),"string"==typeof e&&n[e]())})}var i=function(t,e){this.type=null,this.options=null,this.enabled=null,this.timeout=null,this.hoverState=null,this.$element=null,this.inState=null,this.init("tooltip",t,e)};i.VERSION="3.3.6",i.TRANSITION_DURATION=150,i.DEFAULTS={animation:!0,placement:"top",selector:!1,template:'<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',trigger:"hover focus",title:"",delay:0,html:!1,container:!1,viewport:{selector:"body",padding:0}},i.prototype.init=function(e,i,o){if(this.enabled=!0,this.type=e,this.$element=t(i),this.options=this.getOptions(o),this.$viewport=this.options.viewport&&t(t.isFunction(this.options.viewport)?this.options.viewport.call(this,this.$element):this.options.viewport.selector||this.options.viewport),this.inState={click:!1,hover:!1,focus:!1},this.$element[0]instanceof document.constructor&&!this.options.selector)throw new Error("`selector` option must be specified when initializing "+this.type+" on the window.document object!");for(var n=this.options.trigger.split(" "),s=n.length;s--;){var a=n[s];if("click"==a)this.$element.on("click."+this.type,this.options.selector,t.proxy(this.toggle,this));else if("manual"!=a){var r="hover"==a?"mouseenter":"focusin",l="hover"==a?"mouseleave":"focusout";this.$element.on(r+"."+this.type,this.options.selector,t.proxy(this.enter,this)),this.$element.on(l+"."+this.type,this.options.selector,t.proxy(this.leave,this))}}this.options.selector?this._options=t.extend({},this.options,{trigger:"manual",selector:""}):this.fixTitle()},i.prototype.getDefaults=function(){return i.DEFAULTS},i.prototype.getOptions=function(e){return e=t.extend({},this.getDefaults(),this.$element.data(),e),e.delay&&"number"==typeof e.delay&&(e.delay={show:e.delay,hide:e.delay}),e},i.prototype.getDelegateOptions=function(){var e={},i=this.getDefaults();return this._options&&t.each(this._options,function(t,o){i[t]!=o&&(e[t]=o)}),e},i.prototype.enter=function(e){var i=e instanceof this.constructor?e:t(e.currentTarget).data("bs."+this.type);return i||(i=new this.constructor(e.currentTarget,this.getDelegateOptions()),t(e.currentTarget).data("bs."+this.type,i)),e instanceof t.Event&&(i.inState["focusin"==e.type?"focus":"hover"]=!0),i.tip().hasClass("in")||"in"==i.hoverState?void(i.hoverState="in"):(clearTimeout(i.timeout),i.hoverState="in",i.options.delay&&i.options.delay.show?void(i.timeout=setTimeout(function(){"in"==i.hoverState&&i.show()},i.options.delay.show)):i.show())},i.prototype.isInStateTrue=function(){for(var t in this.inState)if(this.inState[t])return!0;return!1},i.prototype.leave=function(e){var i=e instanceof this.constructor?e:t(e.currentTarget).data("bs."+this.type);return i||(i=new this.constructor(e.currentTarget,this.getDelegateOptions()),t(e.currentTarget).data("bs."+this.type,i)),e instanceof t.Event&&(i.inState["focusout"==e.type?"focus":"hover"]=!1),i.isInStateTrue()?void 0:(clearTimeout(i.timeout),i.hoverState="out",i.options.delay&&i.options.delay.hide?void(i.timeout=setTimeout(function(){"out"==i.hoverState&&i.hide()},i.options.delay.hide)):i.hide())},i.prototype.show=function(){var e=t.Event("show.bs."+this.type);if(this.hasContent()&&this.enabled){this.$element.trigger(e);var o=t.contains(this.$element[0].ownerDocument.documentElement,this.$element[0]);if(e.isDefaultPrevented()||!o)return;var n=this,s=this.tip(),a=this.getUID(this.type);this.setContent(),s.attr("id",a),this.$element.attr("aria-describedby",a),this.options.animation&&s.addClass("fade");var r="function"==typeof this.options.placement?this.options.placement.call(this,s[0],this.$element[0]):this.options.placement,l=/\s?auto?\s?/i,h=l.test(r);h&&(r=r.replace(l,"")||"top"),s.detach().css({top:0,left:0,display:"block"}).addClass(r).data("bs."+this.type,this),this.options.container?s.appendTo(this.options.container):s.insertAfter(this.$element),this.$element.trigger("inserted.bs."+this.type);var d=this.getPosition(),p=s[0].offsetWidth,c=s[0].offsetHeight;if(h){var f=r,u=this.getPosition(this.$viewport);r="bottom"==r&&d.bottom+c>u.bottom?"top":"top"==r&&d.top-c<u.top?"bottom":"right"==r&&d.right+p>u.width?"left":"left"==r&&d.left-p<u.left?"right":r,s.removeClass(f).addClass(r)}var g=this.getCalculatedOffset(r,d,p,c);this.applyPlacement(g,r);var v=function(){var t=n.hoverState;n.$element.trigger("shown.bs."+n.type),n.hoverState=null,"out"==t&&n.leave(n)};t.support.transition&&this.$tip.hasClass("fade")?s.one("bsTransitionEnd",v).emulateTransitionEnd(i.TRANSITION_DURATION):v()}},i.prototype.applyPlacement=function(e,i){var o=this.tip(),n=o[0].offsetWidth,s=o[0].offsetHeight,a=parseInt(o.css("margin-top"),10),r=parseInt(o.css("margin-left"),10);isNaN(a)&&(a=0),isNaN(r)&&(r=0),e.top+=a,e.left+=r,t.offset.setOffset(o[0],t.extend({using:function(t){o.css({top:Math.round(t.top),left:Math.round(t.left)})}},e),0),o.addClass("in");var l=o[0].offsetWidth,h=o[0].offsetHeight;"top"==i&&h!=s&&(e.top=e.top+s-h);var d=this.getViewportAdjustedDelta(i,e,l,h);d.left?e.left+=d.left:e.top+=d.top;var p=/top|bottom/.test(i),c=p?2*d.left-n+l:2*d.top-s+h,f=p?"offsetWidth":"offsetHeight";o.offset(e),this.replaceArrow(c,o[0][f],p)},i.prototype.replaceArrow=function(t,e,i){this.arrow().css(i?"left":"top",50*(1-t/e)+"%").css(i?"top":"left","")},i.prototype.setContent=function(){var t=this.tip(),e=this.getTitle();t.find(".tooltip-inner")[this.options.html?"html":"text"](e),t.removeClass("fade in top bottom left right")},i.prototype.hide=function(e){function o(){"in"!=n.hoverState&&s.detach(),n.$element.removeAttr("aria-describedby").trigger("hidden.bs."+n.type),e&&e()}var n=this,s=t(this.$tip),a=t.Event("hide.bs."+this.type);return this.$element.trigger(a),a.isDefaultPrevented()?void 0:(s.removeClass("in"),t.support.transition&&s.hasClass("fade")?s.one("bsTransitionEnd",o).emulateTransitionEnd(i.TRANSITION_DURATION):o(),this.hoverState=null,this)},i.prototype.fixTitle=function(){var t=this.$element;(t.attr("title")||"string"!=typeof t.attr("data-original-title"))&&t.attr("data-original-title",t.attr("title")||"").attr("title","")},i.prototype.hasContent=function(){return this.getTitle()},i.prototype.getPosition=function(e){e=e||this.$element;var i=e[0],o="BODY"==i.tagName,n=i.getBoundingClientRect();null==n.width&&(n=t.extend({},n,{width:n.right-n.left,height:n.bottom-n.top}));var s=o?{top:0,left:0}:e.offset(),a={scroll:o?document.documentElement.scrollTop||document.body.scrollTop:e.scrollTop()},r=o?{width:t(window).width(),height:t(window).height()}:null;return t.extend({},n,a,r,s)},i.prototype.getCalculatedOffset=function(t,e,i,o){return"bottom"==t?{top:e.top+e.height,left:e.left+e.width/2-i/2}:"top"==t?{top:e.top-o,left:e.left+e.width/2-i/2}:"left"==t?{top:e.top+e.height/2-o/2,left:e.left-i}:{top:e.top+e.height/2-o/2,left:e.left+e.width}},i.prototype.getViewportAdjustedDelta=function(t,e,i,o){var n={top:0,left:0};if(!this.$viewport)return n;var s=this.options.viewport&&this.options.viewport.padding||0,a=this.getPosition(this.$viewport);if(/right|left/.test(t)){var r=e.top-s-a.scroll,l=e.top+s-a.scroll+o;r<a.top?n.top=a.top-r:l>a.top+a.height&&(n.top=a.top+a.height-l)}else{var h=e.left-s,d=e.left+s+i;h<a.left?n.left=a.left-h:d>a.right&&(n.left=a.left+a.width-d)}return n},i.prototype.getTitle=function(){var t,e=this.$element,i=this.options;return t=e.attr("data-original-title")||("function"==typeof i.title?i.title.call(e[0]):i.title)},i.prototype.getUID=function(t){do t+=~~(1e6*Math.random());while(document.getElementById(t));return t},i.prototype.tip=function(){if(!this.$tip&&(this.$tip=t(this.options.template),1!=this.$tip.length))throw new Error(this.type+" `template` option must consist of exactly 1 top-level element!");return this.$tip},i.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".tooltip-arrow")},i.prototype.enable=function(){this.enabled=!0},i.prototype.disable=function(){this.enabled=!1},i.prototype.toggleEnabled=function(){this.enabled=!this.enabled},i.prototype.toggle=function(e){var i=this;e&&(i=t(e.currentTarget).data("bs."+this.type),i||(i=new this.constructor(e.currentTarget,this.getDelegateOptions()),t(e.currentTarget).data("bs."+this.type,i))),e?(i.inState.click=!i.inState.click,i.isInStateTrue()?i.enter(i):i.leave(i)):i.tip().hasClass("in")?i.leave(i):i.enter(i)},i.prototype.destroy=function(){var t=this;clearTimeout(this.timeout),this.hide(function(){t.$element.off("."+t.type).removeData("bs."+t.type),t.$tip&&t.$tip.detach(),t.$tip=null,t.$arrow=null,t.$viewport=null})};var o=t.fn.tooltip;t.fn.tooltip=e,t.fn.tooltip.Constructor=i,t.fn.tooltip.noConflict=function(){return t.fn.tooltip=o,this}}(jQuery),+function(t){"use strict";function e(e){return this.each(function(){var o=t(this),n=o.data("bs.popover"),s="object"==typeof e&&e;(n||!/destroy|hide/.test(e))&&(n||o.data("bs.popover",n=new i(this,s)),"string"==typeof e&&n[e]())})}var i=function(t,e){this.init("popover",t,e)};if(!t.fn.tooltip)throw new Error("Popover requires tooltip.js");i.VERSION="3.3.6",i.DEFAULTS=t.extend({},t.fn.tooltip.Constructor.DEFAULTS,{placement:"right",trigger:"click",content:"",template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'}),i.prototype=t.extend({},t.fn.tooltip.Constructor.prototype),i.prototype.constructor=i,i.prototype.getDefaults=function(){return i.DEFAULTS},i.prototype.setContent=function(){var t=this.tip(),e=this.getTitle(),i=this.getContent();t.find(".popover-title")[this.options.html?"html":"text"](e),t.find(".popover-content").children().detach().end()[this.options.html?"string"==typeof i?"html":"append":"text"](i),t.removeClass("fade top bottom left right in"),t.find(".popover-title").html()||t.find(".popover-title").hide()},i.prototype.hasContent=function(){return this.getTitle()||this.getContent()},i.prototype.getContent=function(){var t=this.$element,e=this.options;return t.attr("data-content")||("function"==typeof e.content?e.content.call(t[0]):e.content)},i.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".arrow")};var o=t.fn.popover;t.fn.popover=e,t.fn.popover.Constructor=i,t.fn.popover.noConflict=function(){return t.fn.popover=o,this}}(jQuery),+function(t){"use strict";function e(e){return this.each(function(){var o=t(this),n=o.data("bs.tab");n||o.data("bs.tab",n=new i(this)),"string"==typeof e&&n[e]()})}var i=function(e){this.element=t(e)};i.VERSION="3.3.6",i.TRANSITION_DURATION=150,i.prototype.show=function(){var e=this.element,i=e.closest("ul:not(.dropdown-menu)"),o=e.data("target");if(o||(o=e.attr("href"),o=o&&o.replace(/.*(?=#[^\s]*$)/,"")),!e.parent("li").hasClass("active")){var n=i.find(".active:last a"),s=t.Event("hide.bs.tab",{relatedTarget:e[0]}),a=t.Event("show.bs.tab",{relatedTarget:n[0]});if(n.trigger(s),e.trigger(a),!a.isDefaultPrevented()&&!s.isDefaultPrevented()){var r=t(o);this.activate(e.closest("li"),i),this.activate(r,r.parent(),function(){n.trigger({type:"hidden.bs.tab",relatedTarget:e[0]}),e.trigger({type:"shown.bs.tab",relatedTarget:n[0]})})}}},i.prototype.activate=function(e,o,n){function s(){a.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!1),e.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded",!0),r?(e[0].offsetWidth,e.addClass("in")):e.removeClass("fade"),e.parent(".dropdown-menu").length&&e.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!0),n&&n()}var a=o.find("> .active"),r=n&&t.support.transition&&(a.length&&a.hasClass("fade")||!!o.find("> .fade").length);a.length&&r?a.one("bsTransitionEnd",s).emulateTransitionEnd(i.TRANSITION_DURATION):s(),a.removeClass("in")};var o=t.fn.tab;t.fn.tab=e,t.fn.tab.Constructor=i,t.fn.tab.noConflict=function(){return t.fn.tab=o,this};var n=function(i){i.preventDefault(),e.call(t(this),"show")};t(document).on("click.bs.tab.data-api",'[data-toggle="tab"]',n).on("click.bs.tab.data-api",'[data-toggle="pill"]',n)}(jQuery),+function(t){"use strict";function e(e){return this.each(function(){var o=t(this),n=o.data("bs.affix"),s="object"==typeof e&&e;n||o.data("bs.affix",n=new i(this,s)),"string"==typeof e&&n[e]()})}var i=function(e,o){this.options=t.extend({},i.DEFAULTS,o),this.$target=t(this.options.target).on("scroll.bs.affix.data-api",t.proxy(this.checkPosition,this)).on("click.bs.affix.data-api",t.proxy(this.checkPositionWithEventLoop,this)),this.$element=t(e),this.affixed=null,this.unpin=null,this.pinnedOffset=null,this.checkPosition()};i.VERSION="3.3.6",i.RESET="affix affix-top affix-bottom",i.DEFAULTS={offset:0,target:window},i.prototype.getState=function(t,e,i,o){var n=this.$target.scrollTop(),s=this.$element.offset(),a=this.$target.height();if(null!=i&&"top"==this.affixed)return i>n?"top":!1;if("bottom"==this.affixed)return null!=i?n+this.unpin<=s.top?!1:"bottom":t-o>=n+a?!1:"bottom";var r=null==this.affixed,l=r?n:s.top,h=r?a:e;return null!=i&&i>=n?"top":null!=o&&l+h>=t-o?"bottom":!1},i.prototype.getPinnedOffset=function(){if(this.pinnedOffset)return this.pinnedOffset;this.$element.removeClass(i.RESET).addClass("affix");var t=this.$target.scrollTop(),e=this.$element.offset();return this.pinnedOffset=e.top-t},i.prototype.checkPositionWithEventLoop=function(){setTimeout(t.proxy(this.checkPosition,this),1)},i.prototype.checkPosition=function(){if(this.$element.is(":visible")){var e=this.$element.height(),o=this.options.offset,n=o.top,s=o.bottom,a=Math.max(t(document).height(),t(document.body).height());"object"!=typeof o&&(s=n=o),"function"==typeof n&&(n=o.top(this.$element)),"function"==typeof s&&(s=o.bottom(this.$element));var r=this.getState(a,e,n,s);if(this.affixed!=r){null!=this.unpin&&this.$element.css("top","");var l="affix"+(r?"-"+r:""),h=t.Event(l+".bs.affix");if(this.$element.trigger(h),h.isDefaultPrevented())return;this.affixed=r,this.unpin="bottom"==r?this.getPinnedOffset():null,this.$element.removeClass(i.RESET).addClass(l).trigger(l.replace("affix","affixed")+".bs.affix")}"bottom"==r&&this.$element.offset({top:a-e-s})}};var o=t.fn.affix;t.fn.affix=e,t.fn.affix.Constructor=i,t.fn.affix.noConflict=function(){return t.fn.affix=o,this},t(window).on("load",function(){t('[data-spy="affix"]').each(function(){var i=t(this),o=i.data();o.offset=o.offset||{},null!=o.offsetBottom&&(o.offset.bottom=o.offsetBottom),null!=o.offsetTop&&(o.offset.top=o.offsetTop),e.call(i,o)})})}(jQuery),+function(t){"use strict";function e(e){var i,o=e.attr("data-target")||(i=e.attr("href"))&&i.replace(/.*(?=#[^\s]+$)/,"");return t(o)}function i(e){return this.each(function(){var i=t(this),n=i.data("bs.collapse"),s=t.extend({},o.DEFAULTS,i.data(),"object"==typeof e&&e);!n&&s.toggle&&/show|hide/.test(e)&&(s.toggle=!1),n||i.data("bs.collapse",n=new o(this,s)),"string"==typeof e&&n[e]()})}var o=function(e,i){this.$element=t(e),this.options=t.extend({},o.DEFAULTS,i),this.$trigger=t('[data-toggle="collapse"][href="#'+e.id+'"],[data-toggle="collapse"][data-target="#'+e.id+'"]'),this.transitioning=null,this.options.parent?this.$parent=this.getParent():this.addAriaAndCollapsedClass(this.$element,this.$trigger),this.options.toggle&&this.toggle()};o.VERSION="3.3.6",o.TRANSITION_DURATION=350,o.DEFAULTS={toggle:!0},o.prototype.dimension=function(){var t=this.$element.hasClass("width");return t?"width":"height"},o.prototype.show=function(){if(!this.transitioning&&!this.$element.hasClass("in")){var e,n=this.$parent&&this.$parent.children(".panel").children(".in, .collapsing");if(!(n&&n.length&&(e=n.data("bs.collapse"),e&&e.transitioning))){var s=t.Event("show.bs.collapse");if(this.$element.trigger(s),!s.isDefaultPrevented()){n&&n.length&&(i.call(n,"hide"),e||n.data("bs.collapse",null));var a=this.dimension();this.$element.removeClass("collapse").addClass("collapsing")[a](0).attr("aria-expanded",!0),this.$trigger.removeClass("collapsed").attr("aria-expanded",!0),this.transitioning=1;var r=function(){this.$element.removeClass("collapsing").addClass("collapse in")[a](""),this.transitioning=0,this.$element.trigger("shown.bs.collapse")};if(!t.support.transition)return r.call(this);var l=t.camelCase(["scroll",a].join("-"));this.$element.one("bsTransitionEnd",t.proxy(r,this)).emulateTransitionEnd(o.TRANSITION_DURATION)[a](this.$element[0][l]);
}}}},o.prototype.hide=function(){if(!this.transitioning&&this.$element.hasClass("in")){var e=t.Event("hide.bs.collapse");if(this.$element.trigger(e),!e.isDefaultPrevented()){var i=this.dimension();this.$element[i](this.$element[i]())[0].offsetHeight,this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded",!1),this.$trigger.addClass("collapsed").attr("aria-expanded",!1),this.transitioning=1;var n=function(){this.transitioning=0,this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")};return t.support.transition?void this.$element[i](0).one("bsTransitionEnd",t.proxy(n,this)).emulateTransitionEnd(o.TRANSITION_DURATION):n.call(this)}}},o.prototype.toggle=function(){this[this.$element.hasClass("in")?"hide":"show"]()},o.prototype.getParent=function(){return t(this.options.parent).find('[data-toggle="collapse"][data-parent="'+this.options.parent+'"]').each(t.proxy(function(i,o){var n=t(o);this.addAriaAndCollapsedClass(e(n),n)},this)).end()},o.prototype.addAriaAndCollapsedClass=function(t,e){var i=t.hasClass("in");t.attr("aria-expanded",i),e.toggleClass("collapsed",!i).attr("aria-expanded",i)};var n=t.fn.collapse;t.fn.collapse=i,t.fn.collapse.Constructor=o,t.fn.collapse.noConflict=function(){return t.fn.collapse=n,this},t(document).on("click.bs.collapse.data-api",'[data-toggle="collapse"]',function(o){var n=t(this);n.attr("data-target")||o.preventDefault();var s=e(n),a=s.data("bs.collapse"),r=a?"toggle":n.data();i.call(s,r)})}(jQuery),+function(t){"use strict";function e(i,o){this.$body=t(document.body),this.$scrollElement=t(t(i).is(document.body)?window:i),this.options=t.extend({},e.DEFAULTS,o),this.selector=(this.options.target||"")+" .nav li > a",this.offsets=[],this.targets=[],this.activeTarget=null,this.scrollHeight=0,this.$scrollElement.on("scroll.bs.scrollspy",t.proxy(this.process,this)),this.refresh(),this.process()}function i(i){return this.each(function(){var o=t(this),n=o.data("bs.scrollspy"),s="object"==typeof i&&i;n||o.data("bs.scrollspy",n=new e(this,s)),"string"==typeof i&&n[i]()})}e.VERSION="3.3.6",e.DEFAULTS={offset:10},e.prototype.getScrollHeight=function(){return this.$scrollElement[0].scrollHeight||Math.max(this.$body[0].scrollHeight,document.documentElement.scrollHeight)},e.prototype.refresh=function(){var e=this,i="offset",o=0;this.offsets=[],this.targets=[],this.scrollHeight=this.getScrollHeight(),t.isWindow(this.$scrollElement[0])||(i="position",o=this.$scrollElement.scrollTop()),this.$body.find(this.selector).map(function(){var e=t(this),n=e.data("target")||e.attr("href"),s=/^#./.test(n)&&t(n);return s&&s.length&&s.is(":visible")&&[[s[i]().top+o,n]]||null}).sort(function(t,e){return t[0]-e[0]}).each(function(){e.offsets.push(this[0]),e.targets.push(this[1])})},e.prototype.process=function(){var t,e=this.$scrollElement.scrollTop()+this.options.offset,i=this.getScrollHeight(),o=this.options.offset+i-this.$scrollElement.height(),n=this.offsets,s=this.targets,a=this.activeTarget;if(this.scrollHeight!=i&&this.refresh(),e>=o)return a!=(t=s[s.length-1])&&this.activate(t);if(a&&e<n[0])return this.activeTarget=null,this.clear();for(t=n.length;t--;)a!=s[t]&&e>=n[t]&&(void 0===n[t+1]||e<n[t+1])&&this.activate(s[t])},e.prototype.activate=function(e){this.activeTarget=e,this.clear();var i=this.selector+'[data-target="'+e+'"],'+this.selector+'[href="'+e+'"]',o=t(i).parents("li").addClass("active");o.parent(".dropdown-menu").length&&(o=o.closest("li.dropdown").addClass("active")),o.trigger("activate.bs.scrollspy")},e.prototype.clear=function(){t(this.selector).parentsUntil(this.options.target,".active").removeClass("active")};var o=t.fn.scrollspy;t.fn.scrollspy=i,t.fn.scrollspy.Constructor=e,t.fn.scrollspy.noConflict=function(){return t.fn.scrollspy=o,this},t(window).on("load.bs.scrollspy.data-api",function(){t('[data-spy="scroll"]').each(function(){var e=t(this);i.call(e,e.data())})})}(jQuery),+function(t){"use strict";function e(){var t=document.createElement("bootstrap"),e={WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd otransitionend",transition:"transitionend"};for(var i in e)if(void 0!==t.style[i])return{end:e[i]};return!1}t.fn.emulateTransitionEnd=function(e){var i=!1,o=this;t(this).one("bsTransitionEnd",function(){i=!0});var n=function(){i||t(o).trigger(t.support.transition.end)};return setTimeout(n,e),this},t(function(){t.support.transition=e(),t.support.transition&&(t.event.special.bsTransitionEnd={bindType:t.support.transition.end,delegateType:t.support.transition.end,handle:function(e){return t(e.target).is(this)?e.handleObj.handler.apply(this,arguments):void 0}})})}(jQuery);
})($cmsj,$cmsj);
!function(a){"use strict";var b=a.module("angular-bind-html-compile",[]);b.directive("bindHtmlCompile",["$compile",function(a){return{restrict:"A",link:function(b,c,d){b.$watch(function(){return b.$eval(d.bindHtmlCompile)},function(e){c.html(e&&e.toString());var f=b;d.bindHtmlScope&&(f=b.$eval(d.bindHtmlScope)),a(c.contents())(f)})}}}])}(window.angular);
/*! nouislider - 8.3.0 - 2016-02-14 17:37:19 */

!function(a){"function"==typeof define&&define.amd?define([],a):"object"==typeof exports?module.exports=a():window.noUiSlider=a()}(function(){"use strict";function a(a){return a.filter(function(a){return this[a]?!1:this[a]=!0},{})}function b(a,b){return Math.round(a/b)*b}function c(a){var b=a.getBoundingClientRect(),c=a.ownerDocument,d=c.documentElement,e=m();return/webkit.*Chrome.*Mobile/i.test(navigator.userAgent)&&(e.x=0),{top:b.top+e.y-d.clientTop,left:b.left+e.x-d.clientLeft}}function d(a){return"number"==typeof a&&!isNaN(a)&&isFinite(a)}function e(a){var b=Math.pow(10,7);return Number((Math.round(a*b)/b).toFixed(7))}function f(a,b,c){j(a,b),setTimeout(function(){k(a,b)},c)}function g(a){return Math.max(Math.min(a,100),0)}function h(a){return Array.isArray(a)?a:[a]}function i(a){var b=a.split(".");return b.length>1?b[1].length:0}function j(a,b){a.classList?a.classList.add(b):a.className+=" "+b}function k(a,b){a.classList?a.classList.remove(b):a.className=a.className.replace(new RegExp("(^|\\b)"+b.split(" ").join("|")+"(\\b|$)","gi")," ")}function l(a,b){return a.classList?a.classList.contains(b):new RegExp("\\b"+b+"\\b").test(a.className)}function m(){var a=void 0!==window.pageXOffset,b="CSS1Compat"===(document.compatMode||""),c=a?window.pageXOffset:b?document.documentElement.scrollLeft:document.body.scrollLeft,d=a?window.pageYOffset:b?document.documentElement.scrollTop:document.body.scrollTop;return{x:c,y:d}}function n(a){a.stopPropagation()}function o(a){return function(b){return a+b}}function p(a,b){return 100/(b-a)}function q(a,b){return 100*b/(a[1]-a[0])}function r(a,b){return q(a,a[0]<0?b+Math.abs(a[0]):b-a[0])}function s(a,b){return b*(a[1]-a[0])/100+a[0]}function t(a,b){for(var c=1;a>=b[c];)c+=1;return c}function u(a,b,c){if(c>=a.slice(-1)[0])return 100;var d,e,f,g,h=t(c,a);return d=a[h-1],e=a[h],f=b[h-1],g=b[h],f+r([d,e],c)/p(f,g)}function v(a,b,c){if(c>=100)return a.slice(-1)[0];var d,e,f,g,h=t(c,b);return d=a[h-1],e=a[h],f=b[h-1],g=b[h],s([d,e],(c-f)*p(f,g))}function w(a,c,d,e){if(100===e)return e;var f,g,h=t(e,a);return d?(f=a[h-1],g=a[h],e-f>(g-f)/2?g:f):c[h-1]?a[h-1]+b(e-a[h-1],c[h-1]):e}function x(a,b,c){var e;if("number"==typeof b&&(b=[b]),"[object Array]"!==Object.prototype.toString.call(b))throw new Error("noUiSlider: 'range' contains invalid value.");if(e="min"===a?0:"max"===a?100:parseFloat(a),!d(e)||!d(b[0]))throw new Error("noUiSlider: 'range' value isn't numeric.");c.xPct.push(e),c.xVal.push(b[0]),e?c.xSteps.push(isNaN(b[1])?!1:b[1]):isNaN(b[1])||(c.xSteps[0]=b[1])}function y(a,b,c){return b?void(c.xSteps[a]=q([c.xVal[a],c.xVal[a+1]],b)/p(c.xPct[a],c.xPct[a+1])):!0}function z(a,b,c,d){this.xPct=[],this.xVal=[],this.xSteps=[d||!1],this.xNumSteps=[!1],this.snap=b,this.direction=c;var e,f=[];for(e in a)a.hasOwnProperty(e)&&f.push([a[e],e]);for(f.length&&"object"==typeof f[0][0]?f.sort(function(a,b){return a[0][0]-b[0][0]}):f.sort(function(a,b){return a[0]-b[0]}),e=0;e<f.length;e++)x(f[e][1],f[e][0],this);for(this.xNumSteps=this.xSteps.slice(0),e=0;e<this.xNumSteps.length;e++)y(e,this.xNumSteps[e],this)}function A(a,b){if(!d(b))throw new Error("noUiSlider: 'step' is not numeric.");a.singleStep=b}function B(a,b){if("object"!=typeof b||Array.isArray(b))throw new Error("noUiSlider: 'range' is not an object.");if(void 0===b.min||void 0===b.max)throw new Error("noUiSlider: Missing 'min' or 'max' in 'range'.");if(b.min===b.max)throw new Error("noUiSlider: 'range' 'min' and 'max' cannot be equal.");a.spectrum=new z(b,a.snap,a.dir,a.singleStep)}function C(a,b){if(b=h(b),!Array.isArray(b)||!b.length||b.length>2)throw new Error("noUiSlider: 'start' option is incorrect.");a.handles=b.length,a.start=b}function D(a,b){if(a.snap=b,"boolean"!=typeof b)throw new Error("noUiSlider: 'snap' option must be a boolean.")}function E(a,b){if(a.animate=b,"boolean"!=typeof b)throw new Error("noUiSlider: 'animate' option must be a boolean.")}function F(a,b){if("lower"===b&&1===a.handles)a.connect=1;else if("upper"===b&&1===a.handles)a.connect=2;else if(b===!0&&2===a.handles)a.connect=3;else{if(b!==!1)throw new Error("noUiSlider: 'connect' option doesn't match handle count.");a.connect=0}}function G(a,b){switch(b){case"horizontal":a.ort=0;break;case"vertical":a.ort=1;break;default:throw new Error("noUiSlider: 'orientation' option is invalid.")}}function H(a,b){if(!d(b))throw new Error("noUiSlider: 'margin' option must be numeric.");if(0!==b&&(a.margin=a.spectrum.getMargin(b),!a.margin))throw new Error("noUiSlider: 'margin' option is only supported on linear sliders.")}function I(a,b){if(!d(b))throw new Error("noUiSlider: 'limit' option must be numeric.");if(a.limit=a.spectrum.getMargin(b),!a.limit)throw new Error("noUiSlider: 'limit' option is only supported on linear sliders.")}function J(a,b){switch(b){case"ltr":a.dir=0;break;case"rtl":a.dir=1,a.connect=[0,2,1,3][a.connect];break;default:throw new Error("noUiSlider: 'direction' option was not recognized.")}}function K(a,b){if("string"!=typeof b)throw new Error("noUiSlider: 'behaviour' must be a string containing options.");var c=b.indexOf("tap")>=0,d=b.indexOf("drag")>=0,e=b.indexOf("fixed")>=0,f=b.indexOf("snap")>=0,g=b.indexOf("hover")>=0;if(d&&!a.connect)throw new Error("noUiSlider: 'drag' behaviour must be used with 'connect': true.");a.events={tap:c||f,drag:d,fixed:e,snap:f,hover:g}}function L(a,b){var c;if(b!==!1)if(b===!0)for(a.tooltips=[],c=0;c<a.handles;c++)a.tooltips.push(!0);else{if(a.tooltips=h(b),a.tooltips.length!==a.handles)throw new Error("noUiSlider: must pass a formatter for all handles.");a.tooltips.forEach(function(a){if("boolean"!=typeof a&&("object"!=typeof a||"function"!=typeof a.to))throw new Error("noUiSlider: 'tooltips' must be passed a formatter or 'false'.")})}}function M(a,b){if(a.format=b,"function"==typeof b.to&&"function"==typeof b.from)return!0;throw new Error("noUiSlider: 'format' requires 'to' and 'from' methods.")}function N(a,b){if(void 0!==b&&"string"!=typeof b)throw new Error("noUiSlider: 'cssPrefix' must be a string.");a.cssPrefix=b}function O(a){var b,c={margin:0,limit:0,animate:!0,format:T};b={step:{r:!1,t:A},start:{r:!0,t:C},connect:{r:!0,t:F},direction:{r:!0,t:J},snap:{r:!1,t:D},animate:{r:!1,t:E},range:{r:!0,t:B},orientation:{r:!1,t:G},margin:{r:!1,t:H},limit:{r:!1,t:I},behaviour:{r:!0,t:K},format:{r:!1,t:M},tooltips:{r:!1,t:L},cssPrefix:{r:!1,t:N}};var d={connect:!1,direction:"ltr",behaviour:"tap",orientation:"horizontal"};return Object.keys(b).forEach(function(e){if(void 0===a[e]&&void 0===d[e]){if(b[e].r)throw new Error("noUiSlider: '"+e+"' is required.");return!0}b[e].t(c,void 0===a[e]?d[e]:a[e])}),c.pips=a.pips,c.style=c.ort?"top":"left",c}function P(b,d){function e(a,b,c){var d=a+b[0],e=a+b[1];return c?(0>d&&(e+=Math.abs(d)),e>100&&(d-=e-100),[g(d),g(e)]):[d,e]}function p(a,b){a.preventDefault();var c,d,e=0===a.type.indexOf("touch"),f=0===a.type.indexOf("mouse"),g=0===a.type.indexOf("pointer"),h=a;return 0===a.type.indexOf("MSPointer")&&(g=!0),e&&(c=a.changedTouches[0].pageX,d=a.changedTouches[0].pageY),b=b||m(),(f||g)&&(c=a.clientX+b.x,d=a.clientY+b.y),h.pageOffset=b,h.points=[c,d],h.cursor=f||g,h}function q(a,b){var c=document.createElement("div"),d=document.createElement("div"),e=["-lower","-upper"];return a&&e.reverse(),j(d,da[3]),j(d,da[3]+e[b]),j(c,da[2]),c.appendChild(d),c}function r(a,b,c){switch(a){case 1:j(b,da[7]),j(c[0],da[6]);break;case 3:j(c[1],da[6]);case 2:j(c[0],da[7]);case 0:j(b,da[6])}}function s(a,b,c){var d,e=[];for(d=0;a>d;d+=1)e.push(c.appendChild(q(b,d)));return e}function t(a,b,c){j(c,da[0]),j(c,da[8+a]),j(c,da[4+b]);var d=document.createElement("div");return j(d,da[1]),c.appendChild(d),d}function u(a,b){if(!d.tooltips[b])return!1;var c=document.createElement("div");return c.className=da[18],a.firstChild.appendChild(c)}function v(){d.dir&&d.tooltips.reverse();var a=Y.map(u);d.dir&&(a.reverse(),d.tooltips.reverse()),U("update",function(b,c,e){a[c]&&(a[c].innerHTML=d.tooltips[c]===!0?b[c]:d.tooltips[c].to(e[c]))})}function w(a,b,c){if("range"===a||"steps"===a)return aa.xVal;if("count"===a){var d,e=100/(b-1),f=0;for(b=[];(d=f++*e)<=100;)b.push(d);a="positions"}return"positions"===a?b.map(function(a){return aa.fromStepping(c?aa.getStep(a):a)}):"values"===a?c?b.map(function(a){return aa.fromStepping(aa.getStep(aa.toStepping(a)))}):b:void 0}function x(b,c,d){function e(a,b){return(a+b).toFixed(7)/1}var f=aa.direction,g={},h=aa.xVal[0],i=aa.xVal[aa.xVal.length-1],j=!1,k=!1,l=0;return aa.direction=0,d=a(d.slice().sort(function(a,b){return a-b})),d[0]!==h&&(d.unshift(h),j=!0),d[d.length-1]!==i&&(d.push(i),k=!0),d.forEach(function(a,f){var h,i,m,n,o,p,q,r,s,t,u=a,v=d[f+1];if("steps"===c&&(h=aa.xNumSteps[f]),h||(h=v-u),u!==!1&&void 0!==v)for(i=u;v>=i;i=e(i,h)){for(n=aa.toStepping(i),o=n-l,r=o/b,s=Math.round(r),t=o/s,m=1;s>=m;m+=1)p=l+m*t,g[p.toFixed(5)]=["x",0];q=d.indexOf(i)>-1?1:"steps"===c?2:0,!f&&j&&(q=0),i===v&&k||(g[n.toFixed(5)]=[i,q]),l=n}}),aa.direction=f,g}function y(a,b,c){function e(a){return["-normal","-large","-sub"][a]}function f(a,b,c){return'class="'+b+" "+b+"-"+h+" "+b+e(c[1])+'" style="'+d.style+": "+a+'%"'}function g(a,d){aa.direction&&(a=100-a),d[1]=d[1]&&b?b(d[0],d[1]):d[1],k+="<div "+f(a,da[21],d)+"></div>",d[1]&&(k+="<div "+f(a,da[22],d)+">"+c.to(d[0])+"</div>")}var h=["horizontal","vertical"][d.ort],i=document.createElement("div"),k="";return j(i,da[20]),j(i,da[20]+"-"+h),Object.keys(a).forEach(function(b){g(b,a[b])}),i.innerHTML=k,i}function z(a){var b=a.mode,c=a.density||1,d=a.filter||!1,e=a.values||!1,f=a.stepped||!1,g=w(b,e,f),h=x(c,b,g),i=a.format||{to:Math.round};return $.appendChild(y(h,d,i))}function A(){var a=X.getBoundingClientRect(),b="offset"+["Width","Height"][d.ort];return 0===d.ort?a.width||X[b]:a.height||X[b]}function B(a,b,c){void 0!==b&&1!==d.handles&&(b=Math.abs(b-d.dir)),Object.keys(ca).forEach(function(d){var e=d.split(".")[0];a===e&&ca[d].forEach(function(a){a.call(Z,h(P()),b,h(C(Array.prototype.slice.call(ba))),c||!1,_)})})}function C(a){return 1===a.length?a[0]:d.dir?a.reverse():a}function D(a,b,c,e){var f=function(b){return $.hasAttribute("disabled")?!1:l($,da[14])?!1:(b=p(b,e.pageOffset),a===R.start&&void 0!==b.buttons&&b.buttons>1?!1:e.hover&&b.buttons?!1:(b.calcPoint=b.points[d.ort],void c(b,e)))},g=[];return a.split(" ").forEach(function(a){b.addEventListener(a,f,!1),g.push([a,f])}),g}function E(a,b){if(-1===navigator.appVersion.indexOf("MSIE 9")&&0===a.buttons&&0!==b.buttonsProperty)return F(a,b);var c,d,f=b.handles||Y,g=!1,h=100*(a.calcPoint-b.start)/b.baseSize,i=f[0]===Y[0]?0:1;if(c=e(h,b.positions,f.length>1),g=L(f[0],c[i],1===f.length),f.length>1){if(g=L(f[1],c[i?0:1],!1)||g)for(d=0;d<b.handles.length;d++)B("slide",d)}else g&&B("slide",i)}function F(a,b){var c=X.querySelector("."+da[15]),d=b.handles[0]===Y[0]?0:1;null!==c&&k(c,da[15]),a.cursor&&(document.body.style.cursor="",document.body.removeEventListener("selectstart",document.body.noUiListener));var e=document.documentElement;e.noUiListeners.forEach(function(a){e.removeEventListener(a[0],a[1])}),k($,da[12]),B("set",d),B("change",d),void 0!==b.handleNumber&&B("end",b.handleNumber)}function G(a,b){"mouseout"===a.type&&"HTML"===a.target.nodeName&&null===a.relatedTarget&&F(a,b)}function H(a,b){var c=document.documentElement;if(1===b.handles.length&&(j(b.handles[0].children[0],da[15]),b.handles[0].hasAttribute("disabled")))return!1;a.preventDefault(),a.stopPropagation();var d=D(R.move,c,E,{start:a.calcPoint,baseSize:A(),pageOffset:a.pageOffset,handles:b.handles,handleNumber:b.handleNumber,buttonsProperty:a.buttons,positions:[_[0],_[Y.length-1]]}),e=D(R.end,c,F,{handles:b.handles,handleNumber:b.handleNumber}),f=D("mouseout",c,G,{handles:b.handles,handleNumber:b.handleNumber});if(c.noUiListeners=d.concat(e,f),a.cursor){document.body.style.cursor=getComputedStyle(a.target).cursor,Y.length>1&&j($,da[12]);var g=function(){return!1};document.body.noUiListener=g,document.body.addEventListener("selectstart",g,!1)}void 0!==b.handleNumber&&B("start",b.handleNumber)}function I(a){var b,e,g=a.calcPoint,h=0;return a.stopPropagation(),Y.forEach(function(a){h+=c(a)[d.style]}),b=h/2>g||1===Y.length?0:1,Y[b].hasAttribute("disabled")&&(b=b?0:1),g-=c(X)[d.style],e=100*g/A(),d.events.snap||f($,da[14],300),Y[b].hasAttribute("disabled")?!1:(L(Y[b],e),B("slide",b,!0),B("set",b,!0),B("change",b,!0),void(d.events.snap&&H(a,{handles:[Y[b]]})))}function J(a){var b=a.calcPoint-c(X)[d.style],e=aa.getStep(100*b/A()),f=aa.fromStepping(e);Object.keys(ca).forEach(function(a){"hover"===a.split(".")[0]&&ca[a].forEach(function(a){a.call(Z,f)})})}function K(a){var b,c;if(!a.fixed)for(b=0;b<Y.length;b+=1)D(R.start,Y[b].children[0],H,{handles:[Y[b]],handleNumber:b});if(a.tap&&D(R.start,X,I,{handles:Y}),a.hover)for(D(R.move,X,J,{hover:!0}),b=0;b<Y.length;b+=1)["mousemove MSPointerMove pointermove"].forEach(function(a){Y[b].children[0].addEventListener(a,n,!1)});a.drag&&(c=[X.querySelector("."+da[7])],j(c[0],da[10]),a.fixed&&c.push(Y[c[0]===Y[0]?1:0].children[0]),c.forEach(function(a){D(R.start,a,H,{handles:Y})}))}function L(a,b,c){var e=a!==Y[0]?1:0,f=_[0]+d.margin,h=_[1]-d.margin,i=_[0]+d.limit,l=_[1]-d.limit;return Y.length>1&&(b=e?Math.max(b,f):Math.min(b,h)),c!==!1&&d.limit&&Y.length>1&&(b=e?Math.min(b,i):Math.max(b,l)),b=aa.getStep(b),b=g(parseFloat(b.toFixed(7))),b===_[e]?!1:(window.requestAnimationFrame?window.requestAnimationFrame(function(){a.style[d.style]=b+"%"}):a.style[d.style]=b+"%",a.previousSibling||(k(a,da[17]),b>50&&j(a,da[17])),_[e]=b,ba[e]=aa.fromStepping(b),B("update",e),!0)}function M(a,b){var c,e,f;for(d.limit&&(a+=1),c=0;a>c;c+=1)e=c%2,f=b[e],null!==f&&f!==!1&&("number"==typeof f&&(f=String(f)),f=d.format.from(f),(f===!1||isNaN(f)||L(Y[e],aa.toStepping(f),c===3-d.dir)===!1)&&B("update",e))}function N(a){var b,c,e=h(a);for(d.dir&&d.handles>1&&e.reverse(),d.animate&&-1!==_[0]&&f($,da[14],300),b=Y.length>1?3:1,1===e.length&&(b=1),M(b,e),c=0;c<Y.length;c++)null!==e[c]&&B("set",c)}function P(){var a,b=[];for(a=0;a<d.handles;a+=1)b[a]=d.format.to(ba[a]);return C(b)}function Q(){for(da.forEach(function(a){a&&k($,a)});$.firstChild;)$.removeChild($.firstChild);delete $.noUiSlider}function T(){var a=_.map(function(a,b){var c=aa.getApplicableStep(a),d=i(String(c[2])),e=ba[b],f=100===a?null:c[2],g=Number((e-c[2]).toFixed(d)),h=0===a?null:g>=c[1]?c[2]:c[0]||!1;return[h,f]});return C(a)}function U(a,b){ca[a]=ca[a]||[],ca[a].push(b),"update"===a.split(".")[0]&&Y.forEach(function(a,b){B("update",b)})}function V(a){var b=a.split(".")[0],c=a.substring(b.length);Object.keys(ca).forEach(function(a){var d=a.split(".")[0],e=a.substring(d.length);b&&b!==d||c&&c!==e||delete ca[a]})}function W(a){var b,c=P(),e=O({start:[0,0],margin:a.margin,limit:a.limit,step:a.step,range:a.range,animate:a.animate,snap:void 0===a.snap?d.snap:a.snap});for(["margin","limit","step","range","animate"].forEach(function(b){void 0!==a[b]&&(d[b]=a[b])}),e.spectrum.direction=aa.direction,aa=e.spectrum,_=[-1,-1],N(c),b=0;b<Y.length;b++)B("update",b)}var X,Y,Z,$=b,_=[-1,-1],aa=d.spectrum,ba=[],ca={},da=["target","base","origin","handle","horizontal","vertical","background","connect","ltr","rtl","draggable","","state-drag","","state-tap","active","","stacking","tooltip","","pips","marker","value"].map(o(d.cssPrefix||S));if($.noUiSlider)throw new Error("Slider was already initialized.");return X=t(d.dir,d.ort,$),Y=s(d.handles,d.dir,X),r(d.connect,$,Y),d.pips&&z(d.pips),d.tooltips&&v(),Z={destroy:Q,steps:T,on:U,off:V,get:P,set:N,updateOptions:W,options:d,target:$,pips:z},K(d.events),Z}function Q(a,b){if(!a.nodeName)throw new Error("noUiSlider.create requires a single element.");var c=O(b,a),d=P(a,c);return d.set(c.start),a.noUiSlider=d,d}var R=window.navigator.pointerEnabled?{start:"pointerdown",move:"pointermove",end:"pointerup"}:window.navigator.msPointerEnabled?{start:"MSPointerDown",move:"MSPointerMove",end:"MSPointerUp"}:{start:"mousedown touchstart",move:"mousemove touchmove",end:"mouseup touchend"},S="noUi-";z.prototype.getMargin=function(a){return 2===this.xPct.length?q(this.xVal,a):!1},z.prototype.toStepping=function(a){return a=u(this.xVal,this.xPct,a),this.direction&&(a=100-a),a},z.prototype.fromStepping=function(a){return this.direction&&(a=100-a),e(v(this.xVal,this.xPct,a))},z.prototype.getStep=function(a){return this.direction&&(a=100-a),a=w(this.xPct,this.xSteps,this.snap,a),this.direction&&(a=100-a),a},z.prototype.getApplicableStep=function(a){var b=t(a,this.xPct),c=100===a?2:1;return[this.xNumSteps[b-2],this.xVal[b-c],this.xNumSteps[b-c]]},z.prototype.convert=function(a){return this.getStep(this.toStepping(a))};var T={to:function(a){return void 0!==a&&a.toFixed(2)},from:Number};return{create:Q}});
window.Formula = {};

Formula.ARGSCONCAT = function (args) {
  var result = [];
  for (var i = 0; i < args.length; i++) {
    result = result.concat(args[i]);
  }
  return result;
};

//En: PMT, Fr: VPM
Formula.PMT = function (rate, periods, present, future, type) {
  // Credits: algorithm inspired by Apache OpenOffice

  // Initialize type
  type = (typeof type === 'undefined') ? 0 : type;

  // Evaluate rate and periods (TODO: replace with secure expression evaluator)
  rate = eval(rate);
  periods = eval(periods);

  // Return payment
  var result;
  if (rate === 0) {
    result = (present + future) / periods;
  } else {
    var term = Math.pow(1 + rate, periods);
    if (type === 1) {
      result = (future * rate / (term - 1) + present * rate / (1 - 1 / term)) / (1 + rate);
    } else {
      result = future * rate / (term - 1) + present * rate / (1 - 1 / term);
    }
  }
  return -result;
};

Formula.MIN = function () {
  var range = Formula.ARGSCONCAT(arguments);
  var n = range.length;
  var min = (n > 0) ? range[0] : 0;
  for (var i = 0; i < n; i++) {
    min = (range[i] < min && (range[i] !== true) && (range[i] !== false)) ? range[i] : min;
  }
  return min;
};

Formula.MAX = function () {
  var range = Formula.ARGSCONCAT(arguments);
  var n = range.length;
  var max = (n > 0) ? range[0] : 0;
  for (var i = 0; i < n; i++) {
    max = (range[i] > max && (range[i] !== true) && (range[i] !== false)) ? range[i] : max;
  }
  return max;
};

//En: POWER, Fr: PUISSANCE
Formula.POWER = function (number, power) {
  return Math.pow(number, power);
};

//En: PV, Fr: VA
Formula.PV = function (rate, periods, payment, future, type) {
  // Initialize type
  type = (typeof type === 'undefined') ? 0 : type;

  // Evaluate rate and periods (TODO: replace with secure expression evaluator)
  rate = eval(rate);
  periods = eval(periods);

  // Return present value
  if (rate === 0) {
    return -payment * periods - future;
  } else {
    return (((1 - Math.pow(1 + rate, periods)) / rate) * payment * (1 + rate * type) - future) / Math.pow(1 + rate, periods);
  }
};

Formula.ROUND = function (number, digits) {
  return Math.round(number * Math.pow(10, digits)) / Math.pow(10, digits);
};

Formula.ROUNDDOWN = function (number, digits) {
  var sign = (number > 0) ? 1 : -1;
  return sign * (Math.floor(Math.abs(number) * Math.pow(10, digits))) / Math.pow(10, digits);
};

Formula.ROUNDUP = function (number, digits) {
  var sign = (number > 0) ? 1 : -1;
  return sign * (Math.ceil(Math.abs(number) * Math.pow(10, digits))) / Math.pow(10, digits);
};

Formula.FV = function (rate, periods, payment, value, type) {
  // Credits: algorithm inspired by Apache OpenOffice

  // Initialize type
  type = (typeof type === 'undefined') ? 0 : type;

  // Evaluate rate (TODO: replace with secure expression evaluator)
  rate = eval(rate);

  // Return future value
  var result;
  if (rate === 0) {
      result = value + payment * periods;
  } else {
      var term = Math.pow(1 + rate, periods);
      if (type === 1) {
          result = value * term + payment * (1 + rate) * (term - 1.0) / rate;
      } else {
          result = value * term + payment * (term - 1) / rate;
      }
  }
  return (-1)*result;
};

(function (){/**
 * ...
 * @author Emz
 * @version 3.0.0
 * @date 2015-11-18
 * @company Bluerush
 * @codeReview -
 */

(function(){
	"use strict";
	/* We look if the utils object exist. If not, we simply create it */

	if(!window.BU){
		window.BU = {};
	}

	var cssTestElem,
		settings = {cssSupport:{}};

	window.BU = window.blueUtils = {

		getWindowLanguage:function(){
			var lang = window.lang||window.language,
				defaultLang = 'en';
			if(!lang){
				lang = document.documentElement.lang;
			}
			if(lang){
				var langSp = lang.split("_");
				lang = langSp[langSp.length-1];
			}
			return (lang||defaultLang).toLowerCase();
		},

		getTypeOf:function(p_value){
		var t = typeof p_value;
			if(t === 'object'&&p_value.push !== undefined){
				return 'array';
			}
		return t;
		},
		/* method that determine if a object is empty */
		isEmpty:function(obj) {
			var key;
		    // null and undefined are "empty"
		    if (obj=== null||obj===undefined){ 
		    	return true;
		    }
		    // Assume if it has a length property with a non-zero value
		    // that that property is correct.
		    if (obj.length > 0){
		    	return false;
		    }
		    if (obj.length === 0) {
		    	return true;
		    }
		    // Otherwise, does it have any properties of its own?
		    // Note that this doesn't handle
		    // toString and valueOf enumeration bugs in IE < 9
		    for (key in obj) {
		        if (obj.hasOwnProperty(key)){
		        	return false;
		        }
		    }
		    return true;
		},
		
		clone:function (obj) {
			return typeof obj === 'undefined' ? this : (this.clone.prototype = Object(obj), new this.clone());
		},	

		checkForAbsolutePath:function(p_url){
			/* TODO */
			/* Check for // at pos 0 + file:// at pos 0 + ws:// + wss:// */
			//return (p_url && p_url.substring(0, 4) === 'http') ? true : false;
			//var rx=/^((https?|wss?|file):)?[\/\\\\]{2,}(.*?)$/gmi;
			if (typeof p_url === "string")
			{
				var p = p_url.substring(0, 6);
				if (p.indexOf('http:')===0 || p.indexOf('https:')===0 || p.indexOf('ftp:') ===0 || p.indexOf('file:') === 0 || p.indexOf('ws:') === 0 || p.indexOf('wss:') === 0 || p.indexOf('//') === 0) { return true; 
				}
			}
			return false;
		},

		formatTime :function(p_seconds){
		var seconds = Math.round(p_seconds),
			minutes = Math.floor(seconds / 60);
			minutes = (minutes >= 10) ? minutes : '0' + minutes;
			seconds = Math.floor(seconds % 60);
			seconds = (seconds >= 10) ? seconds : '0' + seconds;
			return minutes + ':' + seconds;
		},

		blockTextSelection:function(){
			document.body.focus();
			document.onselectstart = function () { return false; };
		},

		unblockTextSelection:function(){
			document.onselectstart = function () { return true; };
		},

		importJS:function(src,async){
			var n="script",
				g=document.createElement(n),
				s=document.getElementsByTagName(n)[0];
			g.type="text/javascript";
			if(async){
				g.async=true;
			}

			g.src=src;
			s.parentNode.insertBefore(g,s);
		},

		getExtension:function(url){
			if(typeof url === "string"){
				return url.substr(url.lastIndexOf('.') + 1);
			}
			return false;
		},

		setCookie:function(c_name,value,exdays,domain){
			var expire;
			if(exdays !== undefined && exdays === 0){
				expire = "0";///will create session cookie
			}else{
				var exdate=new Date();
				exdate.setDate(exdate.getDate() + exdays);
				expire = exdate.toUTCString();
			}
			var c_value=escape(value) + ((exdays===null) ? "" : "; expires="+expire),
				path = "; path=/";
			if(domain !== undefined){
				if(domain.substring(0) === "/") path = "; path=";
				path+=domain;
			}

			/* todo - to test */
		var secure = "";
		/* check for https ; if yes, add "; secure" at the end of the cookie */
		if(window.location.protocol === "https"){
			secure = "; secure";
		}
		document.cookie=c_name + "=" + c_value + path + secure;
		},

		getUrlVars:function(p_var,p_var2) {
			var vars = {},
				isUrlParam = BU.isUrl(p_var),
				varToUse = isUrlParam ? p_var2 : p_var,
				url = isUrlParam ? p_var : window.location.href;

			url.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
				var sp = value.split("#");
				if(sp.length > 1) value = sp[0];
				vars[key] = value;
			});
			if(varToUse !== undefined){
				return vars[varToUse];
			}
			return vars;
		},

		isUrl:function(str) {
			var pattern = /^(((([A-Za-z]{3,9}:(?:\/\/)?)|(\/\/))(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)/;
  				return pattern.test(str);
		},

		getHashVars:function(p_var) {
			var vars = {},
				hash;
			if(BU.temporaryHash !== undefined){
				hash = BU.temporaryHash;
				delete BU.temporaryHash;
			}else{
				hash = window.location.hash;
			}
			var a = hash.split("&"),
				l = a.length;
			for(var x=0;x<l;x++){
				var v = a[x];
				v = v.replace(/#/g,'');
				a[x]=v;
				var va = v.split("=");
				if(va.length >= 1 && va[0] !== undefined && va[0] !== "") vars[va[0]] = va[1] || "EMPTY-HASH";
			}
		if(p_var !== undefined){
			return vars[p_var];
		}
			return vars;
		},

		setHashVars:function(p_var,p_value,p_remove) {
			var varType = BU.getTypeOf(p_var),
				valueType = BU.getTypeOf(p_value);

			if(varType === "string" && p_value === undefined){
				valueType = "string";
			}

			if(varType !== "array" && varType!== "string"){
				return;
			}

			if(varType === "string"){
				p_var = [p_var];
				p_value = [p_value];
			}
			var len = p_var.length;
			if(p_remove !== undefined){
					BU.blockSetHashFunction = true;
					BU.removeHashVars(p_remove);
					BU.blockSetHashFunction = false;
			}
				var varObj = BU.getHashVars();
			for(var x=0;x<len;x++){
				var val = p_value[x];
				if(val === undefined) val = "EMPTY-HASH";
				var variable = p_var[x];
				if(varObj[variable] !== val){
					varObj[variable] = val;
				}
			}

			if(len){
				setHash(varObj);
			}
		},

		removeHashVars:function(p_var) {
			var type = BU.getTypeOf(p_var);
			if(type === "boolean"){
				setHash({});
				return;
			}
			if(type !== "array" && type!== "string") return;
			if(type === "string") p_var = [p_var];
				var varObj = BU.getHashVars(), l = p_var.length;
			for(var x=0;x<l;x++) delete varObj[p_var[x]];
			setHash(varObj);
		},

		getCookie:function(c_name){
			var i,x,y,ARRcookies=document.cookie.split(";");
			for (i=0;i<ARRcookies.length;i++)
			{
				x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
				y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
				x=x.replace(/^\s+|\s+$/g,"");
				if (x===c_name) return unescape(y);
			}
		},

		deleteCookie:function(c_name){
			var date = new Date();
			date.setDate(date.getDate() -1);
			document.cookie = escape(c_name) + '=;expires=' + date;
		},

		toNumber:function(p_value){
			var val = p_value;
			if(isNaN(val)){
				if(window.language === "fr"){
					val = val.replace(/[^0-9,\.]/g,'');
					val = val.replace(',','.');
				}
				else val = val.replace(/[^0-9\.]/g,'');
				if(val.split('.').length>2) val =val.replace(/\.+$/,"");
			}
			val *= 1;
			return val;
		},

		formatTimeStringToNumber:function(p_time){
			var timeArray = p_time.split(":"),
				l = timeArray.length,
				sec = 0,
				min = 0;
			if(l - 1 >= 0) sec = BU.toNumber(timeArray[l - 1]);
			if(l - 2 >= 0) min = BU.toNumber(timeArray[l - 2]);
			return  min * 60 + sec;
		},

		getDocumentPath:function(){
			if(!settings.documentPath){
				var documentUrl = window.location.href || '',
					pos = documentUrl.lastIndexOf('/'),
					documentPath = pos < 0 ? documentUrl : documentUrl.slice(0,pos);

				documentPath = documentPath + '/';

				settings.documentPath = documentPath;
			}
			return settings.documentPath;
		},

		checkForUnprefixedPath:function(path){
			if(typeof path !== "string"){
				return false;
			}
			var isAbs = BU.checkForAbsolutePath(path),
				isExplicitRel = path.indexOf("./") === 0 || path.indexOf(".\\") === 0,
				isRoot = !BU.detect.isLocal() && (path.indexOf("/") === 0 || path.indexOf("\\") === 0);
			if(isAbs || isExplicitRel || isRoot){
				return true;
			}
			return false;
		},

		adjustPath:function(url,prefix){
			prefix = prefix||"";

			var prefixAbsolute = BU.checkForUnprefixedPath(prefix),
				docPath=BU.detect.isLocal() ? BU.getDocumentPath() || '' : '',
				isAbs = BU.checkForUnprefixedPath(url);
			
			if(!prefixAbsolute && prefix.indexOf("/") === 0){
				prefix = prefix.substr(1);
			}

			url = isAbs ? url : prefixAbsolute ? prefix + url : docPath + prefix + url;
			if(isAbs){
				var httpIndex = url.indexOf('http');
				if(httpIndex > -1){
					// var isCloudFront = url.indexOf('cloudfront.net') > -1;
					var isLimelight = url.indexOf('llnwd.net') > -1;
					if(isLimelight){
						if(me.settings.isSSL){
							url = url.replace('vo.llnwd.net','hs.llnwd.net');
						}else{
							url = url.replace('hs.llnwd.net','vo.llnwd.net');
						}
					}
					// if(me.settings.isSSL === true){
					// 	url = url.replace('http://','https://');
					// }else{
					// 	url = url.replace('https://','http://');
					// }
				}
			}
			

			/* If the url is absolte and start with //, we need to add the protocol. We do */
			if(url.indexOf('//') === 0){
				/* Generally, the double slashed url will come from the outside, this is why we are going to add http: instead of file:. Like this, the local testing are going to work */
				if(BU.detect.isLocal()){
					url = "http:"+url;
				}else if(window.location.protocol){
					url = window.location.protocol+url;
					
				}
			}
			return url;
		}
	};

	function setHash(varObj){
		var newHash = "",
			isFirst = true;
		for(var x in varObj){
			var add = isFirst ? "" : "&";
			if(isFirst) isFirst = false;
			var v = varObj[x];
			if(v === "EMPTY-HASH" || v === "") newHash+=add + x;
			else newHash+=add + x+"="+v;
		}
		if(newHash.length > 0) newHash = "#"+newHash;
		if(BU.blockSetHashFunction === undefined || BU.blockSetHashFunction === false) window.location.hash = newHash;
		else BU.temporaryHash = newHash;
		var z = "",
		t = document.title || window.title || z;
		// Fix IE repeat hash bug
		// IE678 (title to infinite if not using Fred fixed version)
		if (t && (t.indexOf("#") >= 0)) document.title = t.replace(/\#(.*?)$/, z);
	}

	/* IE9 and less console.log fixe to avoid script error on closed console pannel */
	if(!window.console){
		window.console = {log:function(){}};
	}else if(!window.console.log){
		window.console.log = function(){};
	}

}());
/**
 * ...
 * @author Emz
 * @version 3.0.0
 * @date 2015-11-18
 * @company Bluerush
 * @codeReview -
 */
(function(){
	"use strict";

	/* We look if the utils object exist. If not, we simply create it */
	if(!window.BU){
		window.BU = {};
	}

	var cache = {},
		detect,
		//CONSTANTS
		FIREFOX_BROWSER='Firefox',
		IE_BROWSER='IE',
		EDGE_BROWSER='Edge',
		CHROME_BROWSER='Chrome',
		OPERA_BROWSER='Opera',
		SAFARI_BROWSER='Safari',
		NATIVE_BROWSER='Native',
		UNKNOWN_BROWSER='Unknown',
		///OS LIST
		IOS_OS='iOS',
		BLACKBERRY_OS='Blackberry',
		ANDROID_OS='Android',
		WINDOWS_OS='Windows',
		MAC_OS='Mac',
		LINUX_OS='Linux',
		UNIX_OS='UNIX',
		PLAYBOOK_OS='PlayBook',
		UNKNOWN_OS='Unknown';
			
	BU.detect = detect = {
		/* Method that return a simple JSON Object with many information from the browser, like the name, the version, etc */
		getBrowserInfo:function(){
			var browserInfo = cache.browserInfo,
				nVer,
				nAgt,
				browserName,
				fullVersion = 0,
				majorVersion = 0,
				minorVersion = 0,
				releaseVersion = 0,
				revisionVersion = 0,
				nameOffset,verOffset,ix,
				isIe = false,
				arr,
				naGTS,
				regex,
				rv;

			if(browserInfo === undefined){
				browserInfo = {};
				nVer = navigator.appVersion;
				nAgt = navigator.userAgent;
				browserName  = navigator.appName;
				fullVersion  = ''+parseFloat(nVer);
				majorVersion = parseInt(nVer,10);

				/* Microsoft Edge detection */
				if ((verOffset=nAgt.indexOf("Edge/"))!==-1) {
					browserName = EDGE_BROWSER;
					naGTS = nAgt.split("Edge/");
					fullVersion = naGTS[1] || "12.0";
					majorVersion = parseInt(''+fullVersion,10);
					minorVersion = fullVersion.split(".")[1] || 0;
					minorVersion = parseInt(minorVersion,10);
				}
				/* Opera Browser detection */
				// In Opera, the true version is after "Opera" or after "Version"
				else if ((verOffset=nAgt.indexOf("Opera"))!==-1) {
					browserName = OPERA_BROWSER;
					fullVersion = nAgt.substring(verOffset+6);
					if ((verOffset=nAgt.indexOf("Version"))!=-1){
						fullVersion = nAgt.substring(verOffset+8);
					}
				}
				/* Internet explorer 10 detection */
				// In MSIE, the true version is after "MSIE" in userAgent
				else if ((verOffset=nAgt.indexOf("MSIE"))!==-1) {
					browserName = IE_BROWSER;
					fullVersion = nAgt.substring(verOffset+5);
					majorVersion = parseInt(''+fullVersion,10);
					isIe = true;
				}
				/* Internet explorer 11+ detection */
				else if ((verOffset=nAgt.indexOf("Trident/"))!==-1) {
					browserName = IE_BROWSER;
					regex  = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
				    rv = 11;
				    if (regex.exec(nAgt) !== null){
				    	rv = parseFloat( RegExp.$1 );
				    }
					fullVersion = rv+ '.0';
					majorVersion = rv;
					isIe = true;
				}
				/* Google Chrome detection */
				else if ((verOffset=nAgt.indexOf("Chrome"))!==-1) {
					browserName = CHROME_BROWSER;
					fullVersion = nAgt.substring(verOffset+7);
					arr = fullVersion.split(".");
					majorVersion = parseInt(arr[0],10) || 0;
					minorVersion = parseInt(arr[1],10) || 0;
					releaseVersion = parseInt(arr[2],10) || 0;
					revisionVersion = parseInt(arr[3],10) || 0;
				}
				/* Apple Safari detection */
				// In Safari, the true version is after "Safari" or after "Version"
				else if ((verOffset=nAgt.indexOf("Safari"))!==-1) {
					if(detect.isAndroidOS){
						browserName = NATIVE_BROWSER;	
					}else if((verOffset=nAgt.indexOf("CriOS"))!==-1){
						browserName = CHROME_BROWSER;	
					}else{
						browserName = SAFARI_BROWSER;	
					}
					fullVersion = nAgt.substring(verOffset+7);
					if ((verOffset=nAgt.indexOf("Version"))!==-1){
						fullVersion = nAgt.substring(verOffset+8);
					}
				}
				/* Mozilla Firefox detection */
				/* In Firefox, the true version is after "Firefox" */
				else if ((verOffset=nAgt.indexOf("Firefox"))!==-1) {
					browserName = FIREFOX_BROWSER;
					fullVersion = nAgt.substring(verOffset+8);
					arr = fullVersion.split(".");
					majorVersion = parseInt(arr[0],10) || 0;
					minorVersion = parseInt(arr[1],10) || 0;
					releaseVersion = parseInt(arr[2],10) || 0;
					revisionVersion = parseInt(arr[3],10) || 0;
				}
				// In most other browsers, "name/version" is at the end of userAgent
				else if ( (nameOffset=nAgt.lastIndexOf(' ')+1) < (verOffset=nAgt.lastIndexOf('/')) ){
					browserName = nAgt.substring(nameOffset,verOffset);
					fullVersion = nAgt.substring(verOffset+1);
					if (browserName.toLowerCase()===browserName.toUpperCase()) {
						browserName = navigator.appName;
					}
				}
				// trim the fullVersion string at semicolon/space if present
				if ((ix=fullVersion.indexOf(";"))!=-1){
					fullVersion=fullVersion.substring(0,ix);	
				}

				if ((ix=fullVersion.indexOf(" "))!=-1){
					fullVersion=fullVersion.substring(0,ix);
				}

				majorVersion = parseInt(''+fullVersion,10);
				if (isNaN(majorVersion)) {
					fullVersion  = ''+parseFloat(nVer);
					majorVersion = parseInt(nVer,10);
				}
				/* WEIRD CASE TO DETECT IE9 version */
				if(isIe){
					if(nAgt.indexOf("Trident/5.0")!==-1 && majorVersion === 7){
						majorVersion = 9;
						fullVersion = 9;
					}
				}

				browserInfo.nVer = nVer;	
				browserInfo.nAgt = nAgt;
				browserInfo.browserName = browserName || 0;
				browserInfo.fullVersion = fullVersion || 0;
				browserInfo.majorVersion = majorVersion || 0;
				browserInfo.minorVersion = minorVersion || 0;
				browserInfo.releaseVersion = releaseVersion || 0;
				browserInfo.revisionVersion = revisionVersion || 0;
				browserInfo.verOffset = verOffset || 0;
				if(nameOffset){
					browserInfo.nameOffset = nameOffset;
				}
				if(ix){
					browserInfo.ix = ix;
				}

				cache.browserInfo = browserInfo;
			}
			return browserInfo;
		},

		isFirefoxBrowser:function(){
			return detect.getBrowserInfo().browserName === FIREFOX_BROWSER;
		},

		isIEBrowser:function(){
			return detect.getBrowserInfo().browserName === IE_BROWSER;
		},

		isEdgeBrowser:function(){
			return detect.getBrowserInfo().browserName === EDGE_BROWSER;
		},

		isChromeBrowser:function(){
			return detect.getBrowserInfo().browserName === CHROME_BROWSER;
		},

		isOperaBrowser:function(){
			return detect.getBrowserInfo().browserName === OPERA_BROWSER;
		},

		isSafariBrowser:function(){
			return detect.getBrowserInfo().browserName === SAFARI_BROWSER;
		},

		isAndroidNativeBrowser:function(){
			return detect.getBrowserInfo().browserName === NATIVE_BROWSER;
		},

		getOSInfo:function(){
			var osInfo,
				ua,
				d, dv, r, wVM, wV, oscpu,
				version,
				versionArr,
				osName;

	/* 	CODE REVIEW
			Style: GOOD
			Logic: WARNING
			Other: NONE
			Summary: 
				1.	cache n'est pas validé avant sa méthode
			Comments: 
				1.	cache est un objet publique qui peux etre ré-écrit.
						S'il devient autre chose qu'un objet le script va arrêter.
	*/
			if(cache.osInfo === undefined){
				osInfo = cache.osInfo = {};
				ua = window.navigator.userAgent;
				d = ua.match(/([\(][^\(\)]*[\)])/g);
				dv = d && d[0] ? d[0] : '';
				r = dv.match(/[0-9.,]*[0-9.,]/g);
				wVM = ua.match(/Windows[^;]*/gi);
				wV = wVM && wVM[0] ? wVM[0] : false;
				oscpu = window.navigator.oscpu;
				
				if(!oscpu){
					if(wV){
						oscpu = wV;
					}else if(r && r.length){
						oscpu = r.join('.');
					}else if(dv){
						oscpu = dv[0];
					}else{
						oscpu = "Unknown";
					}
				}
				
				version = oscpu.match(/[0-9.,]*[0-9.,]/g)[0];
				if(!version){
					version = "0";
				}
				
				versionArr = version.split('.');

				osInfo.majorVersion = parseInt(versionArr[0],10) || 0;
				osInfo.minorVersion = parseInt(versionArr[1],10) || 0;
				osInfo.version = (osInfo.majorVersion + '.' + osInfo.minorVersion) * 1;
				osInfo.releaseVersion = parseInt(versionArr[2],10) || 0;

				if (dv.indexOf('Android')>-1){ 
					osName = ANDROID_OS;
				}else if (dv.indexOf('iPad')>-1){ 
					osName = IOS_OS;
				}else if (dv.indexOf('iPhone')>-1){ 
					osName = IOS_OS;
				}else if (dv.indexOf('PlayBook')>-1 ){ 
					osName = PLAYBOOK_OS;
				}else if (dv.indexOf('BlackBerry')>-1){ 
					osName = BLACKBERRY_OS;
				}else if (dv.indexOf('BB')>-1){ 
					osName = BLACKBERRY_OS;
				}else if (dv.indexOf('Win')>-1){ 
					osName = WINDOWS_OS;
				}else if (dv.indexOf('Mac')>-1){ 
					osName = MAC_OS;
				}else if (dv.indexOf('Linux')>-1){ 
					osName = LINUX_OS;
				}else if (dv.indexOf('X11')>-1){ 
					osName = UNIX_OS;
				}else { 
					osName = UNKNOWN_OS; 
				}
				osInfo.osName = osName;

			}
			return cache.osInfo;
		},

		isAndroidOS:function(){
			return detect.getOSInfo().osName === ANDROID_OS;
		},

		isIOSOS:function(){
			return detect.getOSInfo().osName === IOS_OS;
		},

		isBlackberryOS:function(){
			return detect.getOSInfo().osName === BLACKBERRY_OS;
		},

		isWindowsOS:function(){
			return detect.getOSInfo().osName === WINDOWS_OS;
		},

		isMacOS:function(){
			return detect.getOSInfo().osName === MAC_OS;
		},

		isLinuxOS:function(){
			return detect.getOSInfo().osName === MAC_OS;
		},

		isUnixOS:function(){
			return detect.getOSInfo().osName === UNIX_OS;
		},

		isPlaybookOS:function(){
			return detect.getOSInfo().osName === PLAYBOOK_OS;
		},

		/* Method that indicates if we are on a mobile device */
		isMobileBrowser:function(){
			var userAgent, ua, rmobile;

			if(cache.isMobile === undefined){
				if(detect.isTabletBrowser()){
					cache.isMobile = false;
					return cache.isMobile;
				}

				userAgent = navigator.userAgent;
				ua = userAgent.toLowerCase();

				if(ua.indexOf("trident/") > -1 && ua.indexOf("tablet pc") > -1){
					cache.isMobile = false;
					return cache.isMobile;
				}

				if( /\b(msie)\b/.test(ua) ) { /// If you are Internet Explorer
					/// If you are windows phone
					if( /\b(iemobile)\b/.test(ua) ){
						cache.isMobile = true;
					}else{
						cache.isMobile = false;
					}
					return cache.isMobile;
				}
				// NO BOUNDARY check \b ?
				// [mini]mum == isMobile = true
				// Droid should be mobile
				rmobile = /(iPhone|a?n?droid|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|iPod|pie|tablet|up\.browser|up\.link|webos|wos)/;
				cache.isMobile = ( rmobile.exec( ua ) );
				cache.isMobile = cache.isMobile === null ? false : true;
			}
			return cache.isMobile;
		},

		/* Method that indicates if we are on a tablet device */
		isTabletBrowser:function(ua0){
			var ua, tablet, tabletOther, android, firefox, mobile, r;
			if(cache.isTablet === undefined || ua0){
				ua=(ua0||navigator.userAgent||'').toLowerCase();

				if( /\b(msie)\b/.test(ua)){
					cache.isTablet = false;
					return cache.isTablet;
				}

				/* detect ie11 */
				if(ua.indexOf("trident/") > -1 && ua.indexOf("tablet pc") > -1){
					cache.isTablet = false;
					return cache.isTablet;
				}

				tablet=/\b((ipad)|(playbook)|(tablet)|(kindle))\b/.test(ua);
				if(tablet){
					cache.isTablet = true;
					return cache.isTablet;
				}
				tabletOther=/\b((xoom)|(sch-i800))\b/.test(ua);
				android=/\b(a?n?droid)\b/.test(ua);
				firefox=/\b(firefox)\b/.test(ua);
				mobile=/\b(mobile)\b/.test(ua);

				if(firefox && android){
					cache.isTablet = false;
					return cache.isTablet;
				}
				r=tablet||tabletOther||android&&!mobile||firefox&&mobile;
				if(ua0){
					return r;
				}else{
					cache.isTablet = r;
				}
			}
			return cache.isTablet;
		},

		/* Method that indicates if we are on a desktop device */
		isDesktopBrowser:function(){
			if(cache.isDesktop === undefined){
					cache.isDesktop = !detect.isTabletBrowser() && !detect.isMobileBrowser();
			}
			return cache.isDesktop;
		},

		/* Method that indicates if the http live streaming is supported by the current device */
		isHLSSupported:function(){
			var bInfo,osInfo;
			if(cache.hLSSupported === undefined){
				bInfo = detect.getBrowserInfo();
				osInfo = detect.getOSInfo();
				if(detect.isDesktopBrowser()){
					//SAFARI 6 MAC SUPPORT HLS, OTHER DESKTOP DOESN'T SUPPORT HLS
					if(detect.isMacOS() && detect.isSafariBrowser() && bInfo.majorVersion >= 6){
						cache.hLSSupported = true;
					}else{
						cache.hLSSupported = false;
					}
				}else{
					if(detect.isIOSOS() && detect.isSafariBrowser() && bInfo.majorVersion >= 5){
						cache.hLSSupported = true;
					}else if(detect.isAndroidOS() && detect.isChromeBrowser() && bInfo.majorVersion >= 30){
						cache.hLSSupported = true;
					}else if(detect.isAndroidOS() && osInfo.version >= 4.1 && detect.isAndroidNativeBrowser()){
						cache.hLSSupported = true;
					}else{
						cache.hLSSupported = false;
					}
				}
			}
			return cache.hLSSupported;
		},

		isFullScreenEnable:function(){
			var v;
			if(cache.fullScreenEnable === undefined){
				v = document.createElement('video');
				cache.fullScreenEnable = (v) ? (v.requestFullScreen || v.mozRequestFullScreen || v.webkitRequestFullScreen || v.webkitEnterFullscreen || v.msRequestFullscreen) ? true : false : false;
			}
			return cache.fullScreenEnable;
		},

		/* Method that indicate if the current browser can read H264 medias */
		isH264Player:function(){
			var v,r;
			if(cache.isH264 === undefined){
				v=document.createElement('video'),
				r=(v&&v.canPlayType&&v.canPlayType('video/mp4')||'').replace(/non?e?/gmi,'');
				cache.isH264 = !!r;
			}
			return cache.isH264;
		},

		isVideoSupported:function(){
			var v;
			if(cache.useVideo === undefined){
				v = document.createElement('video');
				cache.useVideo = v ? true : false;
			}
			return cache.useVideo;
		},

		isAudioSupported:function(){
			if(cache.isAudioSupported === undefined){
				cache.isAudioSupported = !!document.createElement('audio').canPlayType;
			}
			return cache.isAudioSupported;
		},

		isSVGSupported:function(){
			var bInfo;
			if(cache.isSVGSupported === undefined){
				bInfo = detect.getBrowserInfo();
				if(bInfo.browserName === IE_BROWSER && bInfo.majorVersion < 9){
					cache.isSVGSupported = false;
				}else if(bInfo.browserName === FIREFOX_BROWSER && bInfo.majorVersion < 4){
					cache.isSVGSupported = false;
				}else if(bInfo.browserName === OPERA_BROWSER && bInfo.majorVersion < 9){
					cache.isSVGSupported = false;
				}else{
					cache.isSVGSupported = true;
				}
			}
			return cache.isSVGSupported;
		},

		isMp3Player:function(){
			var browserI, browserName, majorVersion, minorVersion;
			if(cache.isMp3 === undefined){
				cache.isMp3 = isSupportedAudio([
					{browserName:FIREFOX_BROWSER,majorVersion:22},
					{browserName:OPERA_BROWSER,majorVersion:15},
					{browserName:SAFARI_BROWSER,majorVersion:4},
					{browserName:IE_BROWSER,majorVersion:9},
					{browserName:EDGE_BROWSER,majorVersion:12},
					{browserName:NATIVE_BROWSER,majorVersion:4},
					{browserName:CHROME_BROWSER}
				]);
			}
			return cache.isMp3;
		},

		isOggPlayer:function(){
			var browserI, browserName, majorVersion, minorVersion;
			if(cache.isOgg === undefined){
				cache.isOgg = isSupportedAudio([
					{browserName:FIREFOX_BROWSER,majorVersion:3,minorVersion:5},
					{browserName:OPERA_BROWSER,majorVersion:11,minorVersion:50},
					{browserName:CHROME_BROWSER}
				]);
			}
			return cache.isOgg;
		},

		/* Method that return a boolean to tell if the .opus is supported by the current browser */
		/* Firefox 15 and Chrome 27 support the .opus format */
		isOpusPlayer:function(){
			var browserI, browserName, majorVersion, minorVersion;
			if(cache.isOpus === undefined){
				cache.isOpus = isSupportedAudio([
					{browserName:FIREFOX_BROWSER,majorVersion:15},
					{browserName:OPERA_BROWSER,majorVersion:20},
					{browserName:CHROME_BROWSER,majorVersion:33}
				]);
			}
			return cache.isOpus;
		},

		/* Method that return a boolean to tell if the .opus is supported by the current browser */
		/* Firefox 3.5 and all Chrome support the .wav format */
		isWavPlayer:function(){
			var browserI, browserName, majorVersion, minorVersion;
			if(cache.isWav === undefined){
				cache.isWav = isSupportedAudio([
					{browserName:FIREFOX_BROWSER,majorVersion:3,minorVersion:5},
					{browserName:OPERA_BROWSER,majorVersion:11,minorVersion:50},
					{browserName:SAFARI_BROWSER,majorVersion:4},
					{browserName:EDGE_BROWSER,majorVersion:12},
					{browserName:NATIVE_BROWSER,majorVersion:4},
					{browserName:CHROME_BROWSER,majorVersion:8}
				]);
			}
			return cache.isWav;
		},

		isWebMPlayer:function(){
			var browserI, browserName, majorVersion, minorVersion;
			if(cache.isWebM === undefined){
				cache.isWebM = isSupportedAudio([
					{browserName:FIREFOX_BROWSER,majorVersion:4},
					{browserName:OPERA_BROWSER,majorVersion:11,minorVersion:50},
					{browserName:CHROME_BROWSER,majorVersion:6}
				]);
			}
			return cache.isWebM;
		},

		is3GPPlayer:function(){
			if(cache.is3GP === undefined){
				cache.is3GP = detect.isMobileBrowser() && !detect.isH264Player();
			}
			return cache.is3GP;
		},

		isLocal:function(){
			if(cache.isLocal === undefined){
				switch(window.location.protocol) {
					case 'http:':
					case 'https:':
						cache.isLocal = false;
						break;
					case 'file:':
						cache.isLocal = true;
						break;
					default:
						cache.isLocal = false;
				}
			}
			return cache.isLocal;
		},

		getFlashPlayerInfo:function(){
			detect.hasFlashPlayer();
			return cache.flashPlayerInfo;
		},

		/* Method that indicates if we the flash player plugin is availlaible */
		hasFlashPlayer:function(){
			var a,b,c,e,f,g,h,url,urlParam;
			if(cache.flashPlayer === undefined){
				cache.flashPlayerInfo = {};
				cache.flashPlayerInfo.majorVersion = 0;
				cache.flashPlayerInfo.minorVersion = 0;
				cache.flashPlayerInfo.releaseVersion = 0;
				cache.flashPlayerInfo.fullVersion = 0;
				a=!1;
				b="";
				url=(window.location.href||b).toLowerCase();
				c = function(d) {
					d = d.match(/[\d]+/g);
					d.length = 3;
					cache.flashPlayerInfo = {};
					cache.flashPlayerInfo.majorVersion = d[0] !== undefined ? d[0] : 0;
					cache.flashPlayerInfo.minorVersion = d[1] !== undefined ? d[1] : 0;
					cache.flashPlayerInfo.releaseVersion = d[2] !== undefined ? d[2] : 0;
					cache.flashPlayerInfo.fullVersion  = (cache.flashPlayerInfo.majorVersion + "." + cache.flashPlayerInfo.minorVersion) * 1;
					return d.join(".");
				};
				if (navigator.plugins && navigator.plugins.length) {
					e = navigator.plugins["Shockwave Flash"];
					e && (a = !0, e.description && (b = c(e.description)));
					navigator.plugins["Shockwave Flash 2.0"] && (a = !0, b = "2.0.0.11");
				} else {
					if (navigator.mimeTypes && navigator.mimeTypes.length) {
						f = navigator.mimeTypes["application/x-shockwave-flash"];
						(a = f && f.enabledPlugin) && (b = c(f.enabledPlugin.description));
					} else {
						try {
							g = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");a = !0;b = c(g.GetVariable("$version"));
						} catch (h) {
							try {
								g = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");a = !0;b = "6.0.21";
							} catch (i) {
								try {
									g = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");a = !0;b = c(g.GetVariable("$version"));
								} catch (j) {}
							}
						}
					}
				}

				urlParam = url.indexOf("noflash")>0 ? 'noFlash' : urlParam; 
				urlParam = url.indexOf("ishtml")>0 ? 'isHtml' : urlParam; 
				urlParam = url.indexOf("ismobile")>0 ? 'isMobile' : urlParam; 

				if(urlParam){
					cache.flashPlayer = false;
					cache.flashPlayerInfo.blocked = true;
				}else{
					cache.flashPlayerInfo.blocked = false;
					cache.flashPlayer = a;
				}
			}
			return cache.flashPlayer;
		}

	};

	function isSupportedAudio(obj){
		var browserI = detect.getBrowserInfo(),
			browserName = browserI.browserName,
			majorVersion = browserI.majorVersion,
			minorVersion = browserI.minorVersion,
			supported = false,
			x=0,
			len = obj&&obj.length||0,
			b,
			bMajorVersion,
			bMinorVersion;
		for(;x<len;x++){
			b = obj[x];
			if(b.browserName === browserName){
				bMajorVersion = b.majorVersion;
				bMinorVersion = b.minorVersion;
				if(bMajorVersion === undefined){
					return true;
				}else if(majorVersion > bMajorVersion){
					return true;
				}else if(majorVersion === bMajorVersion && minorVersion >= bMinorVersion){
					return true;
				}else{
					return false;
				}
			}
		}
		return false;
	}
}());}());
(function($/*,jQuery*/){

window.cachedLang = false;

window.getLanguage = function(){
	var htmlLang = $('html').attr('lang'),
		splLang,
		winLang;
	if(window.cachedLang){
		return window.cachedLang;
	}else if(htmlLang){
		splLang = htmlLang.split("-")[0];
		window.cachedLang = splLang;
		return splLang;
	}else{
		winLang = window.lang||window.lg||window.language;
		if(typeof winLang === "string"){
			window.cachedLang = winLang;
			return winLang;
		}
	}
	window.cachedLang = 'en';
	return window.cachedLang;
};

window.getSelectOption = function (optionsArray,value,prop) {
	prop = prop || 'value';
	if (typeof optionsArray === 'object' && optionsArray.length) {
		optionsArray = optionsArray.filter(function(option){return option[prop]===value;});
		if (optionsArray.length) return optionsArray[0];
		// else return value;
	}
};

window.getItemAtPath = function (path,scope) {
	scope = scope || window;
	if (path) {
		path = path.split('.');
		do {
			if (scope[path[0]]!==undefined) scope = scope[path.shift()];
			else break;
		} while (path.length);

		return scope;
	}
	return undefined;
};

// Backward compatible trim function
window.trimString = function (x) {
	return x.replace(/^\s+|\s+$/gm,'');
};

// In dev...
// 
// function matchInArray (array,matchMe,strict) {
// 	strict = strict!==undefined ? strict : true;
// 	var result,
// 		isDirectMatch = function (o){return typeof o==='string' || typeof o==='number';},
// 		isNull = function (o){return o === null;},
// 		isArray = function (o){return !isNull(o) && typeof o==='object' && o.length!==undefined;},
// 		isObject = function (o){return !isArray(o) && typeof o==='object';};

// 	if (array && typeof array === 'object' && array.length) {
// 		result = array.filter(function(item){
// 			if (isDirectMatch(matchMe)) {
// 				return item === matchMe;
// 			}
// 			else if (isArray) {
// 				return matchInArray()
// 			}
// 		})[0];
// 	}

// 	return result;
// }

window.cleanValue = function (value){
	if(typeof value === "string"){
		value = value.replaceAll("\\$").replaceAll("%").replaceAll(",");
	}
	return value;
};


window.brCalc = angular.module('br-calc', [/*'ui.bootstrap',*/'angular-bind-html-compile'])

	.service("contentManager",function(){
		var me = this,
			 
			originalContent = {}, // will never be transcluded
			originalConfig = {}, // will never be transcluded
			
			locContent = {},

			content = {},
			config = {},

			GENERAL = 'general',
			CONTENT_MODEL = 'contentModel',
			CONFIG_MODEL = 'configModel',

			getLanguage = window.getLanguage,
			// getLanguage = getLanguage,

			language = getLanguage();
		///////////////////////////
		// LOCAL general methods //
		///////////////////////////
		function getItemAtPath (path,scope) {
			scope = scope || window;
			if (path) {
				path = path.split('.');
				do {
					scope = scope[path.shift()];
				} while (path.length && scope !== undefined);

				return scope;
			}
			return undefined;
		}
		// Go though a config and fetch the models to replace in config
		function transcludeModels (config, scope, modelKey, deepCopy) {
			config = config || {};
			modelKey = modelKey || 'model';
			var isNull = config === null, 
				isObject = !isNull && typeof config === 'object',
				isArray = isObject && config.length !== undefined,
				key,
				model,
				prop,
				value,
				potentialPath,
				i=0;

			if (isObject) {
				if (deepCopy) {

					if (isArray) { config = $.merge([],config); }
					else { config = $.extend(true,{},config); }
				}
				for (key in config) {
					value = config[key];
					if (value!==null) {
						if (typeof value==='object') { config[key] = transcludeModels(value,scope,modelKey,deepCopy); }
						else if (key===modelKey) {

							value = value.split(',');
							for (;i<value.length;i++) {

								potentialPath = trimString(value[i]);
								if (potentialPath.indexOf(':')!==-1) {
									prop = potentialPath.split(':').shift();
									potentialPath = potentialPath.split(':').pop();
								}
								else {
									prop = false;
								}

								model = getItemAtPath(potentialPath, scope);

								if (model!==undefined) {
									if (typeof model==='object') {
										transcludeModels(model,scope,modelKey,deepCopy);
										if (prop) { config[prop] = $.extend({},model); }
										else { config = $.extend(true,{},model,config); }
									}
									else { config[prop||potentialPath.split('.').pop()] = model; }
								}
							}
							delete config[modelKey]; // cleanup
							prop = undefined;
						}
					}
				}
			}
			return config;
		}
		function getName (name) {
			return typeof name === 'string' && name !== '' && name || GENERAL;
		}
		///////////////////////////
		// LOCAL content methods //
		///////////////////////////
		function getLocalisedContent (contentObject,deepCopy) {
			contentObject = contentObject || {};
			if (deepCopy) { contentObject = $.extend(true,{},contentObject); }
			return contentObject[language] || {};
		}

		// Should be used any time config is changed
		// 	-> transclude config's contentModel with content.general (assuming content.general has already been transcluded at set)
		// 	-> transclude config's configModel with itself
		// 	-> transclude content.general contentConfig with its localized version
		// 	-> for each level of content (excluding 'general'):
		// 		-> transclude content's contentModel with its localized version
		// 	-> transclude content's configModel with config
		// function transcludeAllContent(name) {
		function transcludeContent(name) {
			if (name && name!==GENERAL) {
				if (content[name]) {
					transcludeModels( locContent[name], content||{}, CONTENT_MODEL );
					transcludeModels($.extend(true, content[name], locContent[name]), config, CONFIG_MODEL);
				}
			}
			else {
				locContent.general = getLocalisedContent( originalContent.general, true );
				$.extend(true,content,transcludeModels( locContent.general, content||{}, CONTENT_MODEL ));

				for (name in locContent) {
					if (name !== GENERAL) {
						locContent[name] = getLocalisedContent( originalContent[name], true );
						$.extend(true,content[name],transcludeModels( locContent[name], content||{}, CONTENT_MODEL ));
					}
				}
				// CONFIG transclude all content's config
				transcludeModels(content,config, CONFIG_MODEL);
			}
		}
		/**
		 * setContent (LOCAL)
		 * 	Extracts the appropriate localized (language sensitive) part of the config and store it
		 * 	Create a content entry using the localized content config
		 * 	Transclude the new content
		 * @param {object} contentObject Full content config, where the first layer refers to language description. Ex: {en:{...},fr:{...}}
		 * @param {string} name          Name given to the content config.
		 */
		function setContent (name) {
			// Get localised content AND create deep copy of originalContent
			locContent[name] = getLocalisedContent( originalContent[name], true );
			// New content entry
			if (name!==GENERAL) {
				if (content[name]===undefined) {
					content[name] = $.extend(true,{},locContent[name]);
				}
				else {
					$.extend(true,content[name],locContent[name]);
				}
			}
			else {
				$.extend(true,content,locContent[name]);
			}
			// Transclude this content entry
			transcludeContent( name );
			transcludeConfig();
		}
		/////////////////////////////
		// INTERNAL config methods //
		/////////////////////////////
		function transcludeConfig () {
			$.extend(true, config, getTranscludedConfig());
		}
		function getTranscludedConfig () {
			var transcludedConfig = transcludeModels(originalConfig,content||{}, CONTENT_MODEL, true);
			transcludeModels(transcludedConfig, $.extend(true,{},config,transcludedConfig), CONFIG_MODEL);

			return transcludedConfig;
		}
		////////////////////
		// PUBLIC methods //
		////////////////////
		this.setContent = function (contentObject, name) {
			// Provided object should at least have English language
			if (contentObject&&contentObject.en) {
				name = getName( name );
				originalContent[name] = $.extend(true, originalContent[name]||{}, contentObject); // merge with existing object
				setContent( name );
			}
			// me.setConfig();
			return me;
		};
		this.setConfig = function (configObject) {
			// config shouldn't be localised (possess language attributes)
			$.extend(true, originalConfig, configObject || {}); // merge with existing object
			transcludeConfig();
			transcludeContent(); // Transclude ALL content
			return me;
		};
		this.getContent = function (name) {
			if (getName(name)!==GENERAL) {
				return content[getName(name)];
			}
			return content;
		};
		this.getConfig = function (path,clone) {

			if (typeof path === 'boolean') {
				clone = path;
				path = undefined;
			}
			if (clone===true) {
				return path && $.extend(true,{},getItemAtPath(path,config)) || $.extend(true,{},config);
			}
			else {
				return path && getItemAtPath(path,config) || config;
			}
		};
		// Gives out a clone of the originalConfig object in order to prevent changes to the configs by reference
		this.getOriginalConfig = function () {
			return $.extend(true,{},originalConfig);
		};
		this.getHighchartConfig = function (name) {
			return config.highchart&&config.highchart[name]||{};
		};
	})
////////////////
// CONTROLLER //
////////////////
	.controller('br-calc', ['$scope','$location','tabData','contentManager',function($scope,$location,tabData,contentManager/*,$filter*/) {
	 		var dispellAllFocus = function(e){
		 			// data.ignore -> any other focusable elements we wouldn't like to prevent a focus to be transfered to
		 			var ignore = e&&e.data&&e.data.ignore&&$(e.data.ignore) || $(''),
		 				currentActiveField = e&&e.data&&e.data.originalEvent&&$(e.data.originalEvent.currentTarget) || $(e.currentTarget);

		 			if (e.type!=='keydown'&&$(e.target).not(ignore).length===0) return;
		 			currentActiveField.blur();
		 			
	 			},
	 			focusOnNextField = function(e){
	 				var self = $(e.currentTarget),
						body = $('body [ng-app="br-calc"]'),
						focusable, next;
					
					focusable = body.find('input,select,textarea').filter(':visible');
					next = focusable.eq(focusable.index(e.currentTarget)+1);
					if (next.length) { next.focus(); }
					else {
						if (focusable.length!==1) { focusable.eq(0).focus(); }
						else { self.blur(); }
					}
	 			},
	 			interceptEnterKey = function (callback) {
	 				return function (e) {
						if (e.keyCode === 13 && e.which === 13) {
							callback(e);
							return false;
						}
	 				};
	 			},
	 			// Interdependant events to select input field texts
	 			addSelectText = function (e) {
	 				$(e.currentTarget).on('focus',selectText);
	 			},
	 			selectText = function (e) {
	 				e.currentTarget.setSelectionRange(0,e.currentTarget.value.length);
	 				$(e.currentTarget).on('blur',removeSelectText);
	 			},
	 			removeSelectText = function (e) {
	 				$(e.currentTarget)
	 					.off('focus',selectText)
	 					.off('blur',removeSelectText);
	 			};
	
			$scope.tabData = tabData;

			$scope.isMobile = window.BU && BU.detect.isMobileBrowser() || false;
			$('body')
				// Listen on popover close event
				.on('click','[ng-app="br-calc"] .popover .close',function(e){
					$(e.currentTarget).parents('.popover').popover('hide');
				})

				.on('click','[ng-app="br-calc"] button',function(e){ return false; })
	
				// ENTER key behaviour
				.on('keydown', '[ng-app="br-calc"] input, [ng-app="br-calc"] select, [ng-app="br-calc"] textarea', interceptEnterKey(dispellAllFocus))
				// .on('keydown', 'input, select, textarea', interceptEnterKey(focusOnNextField))
	
				// Mousedown while a field :focus automatically BLUR the field
				.on('focus','[ng-app="br-calc"] input, [ng-app="br-calc"] select, [ng-app="br-calc"] textarea',function(e){
					$('body').on('mousedown',{ignore:'[ng-app="br-calc"] input, [ng-app="br-calc"] select, [ng-app="br-calc"] option, [ng-app="br-calc"] textarea',originalEvent:e},dispellAllFocus);
				})
				.on('focus','[ng-app="br-calc"] input',addSelectText)
				.on('blur','[ng-app="br-calc"] input, [ng-app="br-calc"] select, [ng-app="br-calc"] textarea',function(){
					$('body').off('mousedown',dispellAllFocus);
				})

				.on('click','[ng-app="br-calc"] [data-toggle="collapse"]',function (){
					if ($(this.getAttribute('data-target')).attr('aria-expanded')==="true") {
						$(this).addClass('active');
					}
					else {
						$(this).removeClass('active');
					}
				});
	
			// Close visible popovers and tooltip on resize
			// This fixes resize and orientationchange positionning issues.
			$(window).on('resize orientationchange',function (/*e*/) {
			    $('[ng-app="br-calc"] [tooltip]+.tooltip:visible').tooltip('hide');
			    $('[ng-app="br-calc"] [popover]+.popover:visible').popover('hide');
			});

			$scope.module = {
				investmentSelector : 'app/investmentSelector/investmentSelector.html',
				affordabilityCalculator :'app/affordabilityCalculator/affordabilityCalculator.html',

				lineOfCreditCalculator :'app/lineOfCreditCalculator/lineOfCreditCalculator.html',
				lineOfCreditCalculatorScenario :'app/lineOfCreditCalculator/scenario/lineOfCreditScenario.html',
				lineOfCreditCalculatorScenarioDetails :'app/lineOfCreditCalculator/scenario/lineOfCreditScenarioDetails.html',
				lineOfCreditCalculatorScenarioReport :'app/lineOfCreditCalculator/scenarioReport/lineOfCreditScenarioReport.html',
	
				retirementSavingsCalculator :'app/retirementSavingsCalculator/retirementSavingsCalculator.html',
				retirementSavingsCalculatorScenario :'app/retirementSavingsCalculator/scenario/retirementSavingsScenario.html',
				retirementSavingsCalculatorScenarioResults :'app/retirementSavingsCalculator/scenarioResults/retirementSavingsScenarioResults.html',
				retirementSavingsCalculatorScenarioDetails :'app/retirementSavingsCalculator/scenario/retirementSavingsScenarioDetails.html',
				retirementSavingsCalculatorScenarioReport :'app/retirementSavingsCalculator/scenarioReport/retirementSavingsScenarioReport.html',
	
				mortgagePaymentCalculator : 'app/mortgagePaymentCalculator/mortgagePaymentCalculator.html',
				mortgagePaymentCalculatorScenario : 'app/mortgagePaymentCalculator/scenario/mortgagePaymentScenario.html',
				mortgagePaymentCalculatorScenarioDetails : 'app/mortgagePaymentCalculator/scenario/mortgagePaymentScenarioDetails.html',
				mortgagePaymentCalculatorScenarioResults : 'app/mortgagePaymentCalculator/scenarioResults/mortgagePaymentScenarioResults.html',
				mortgagePaymentCalculatorScenarioReport : 'app/mortgagePaymentCalculator/scenarioReport/mortgagePaymentScenarioReport.html'
			};

			contentManager.setContent(defaultBRCalcDataContent);
			contentManager.setConfig(defaultBRCalcDataConfig);
	
			$scope.content = contentManager.getContent();

			$scope.config = contentManager.getConfig();
	
			$scope.round = function(value){
				return Math.round(value);
			};
	
			$scope.sortable = function (object){
				var results = object?Object.keys($.extend({},object)):[],i=0;
				for(;i<results.length;i++) {
					results[i]=object[results[i]];
				}
				return results;
			};

			// replace the config's own model with language selected:
			/*var tempConfig = $.extend(true,{},meridianDataConfig);
			delete tempConfig.content;
			tempConfig = $scope.getContent(tempConfig,$scope.content);
			meridianDataConfig = $.extend(true,meridianDataConfig,tempConfig);*/
	
		}])
////////////////
// DIRECTIVES //
////////////////
	// Modal
	// 	Call a partial using bootstrap's modal
	.directive("modal",function(){
		var directiveDefinitionObject = {
			restrict:'E',
			scope:{
				header:'@',
				close:'@'
			},
			transclude:true,
			replace:true,
			templateUrl:'app/partials/modal.html',
			link: function (scope, elem, attrs/*, ctrl*/) {
				elem.attr('id',attrs.name || 'myModal');
			}
		};
		return directiveDefinitionObject;
	})
	// tooltip
	// 	Init Bootstrap tooltip elements
	.directive("tooltip",function(){
		return {
			restrict:"A",
			link: function (scope,element/*,attrs*/) { element.tooltip(); /*console.log('Defined tooltip - directive')*/ }
		};
	})
	// collapse
	// 	Init Bootstrap collapse elements
	.directive("collapse",function(){
		return {
			restrict:"A",
			link: function (scope,element/*,attrs*/) { /*console.log('sdlfkhsldfsjkdf"');*/element.collapse(); }
		};
	})
	// popover
	// 	Init Bootstrap popover elements
	.directive("popover",['$compile',function($compile){

		return {
			restrict:"E",
			transclude:true,
			replace: true,
			controller: function ($scope,$element,$attrs,$transclude) { 
				// console.log('$element.html()',$element.html(),$element);
				// Replace <transclude-content> element with content inserted in meri-select
				$transclude(function(clone, scope) {
					if (clone.length) {
						// console.log('clone.html()',clone.html());
						$scope.popContent = clone.html();
					}
				});
			},
			compile: function compile(/*tElement, tAttrs*/) {		

				return {
					// Before Link compile
					pre: function preLink(/*scope, elem, attrs, ctrl*/) { },
					// After Link compile
					// Attach events here
					post: function postLink(scope, elem, attrs/*, ctrl*/) {
						var content = scope.popContent || attrs.content || '';

						elem.popover({
							template:'<div class="popover"><div class="popover-content"></div><a href="javascript:void(0)" class="close">X</a></div>',
							trigger:'click'
						})
						.on('hidden.bs.popover', function (e) {
						   $(e.target).data("bs.popover").inState.click = false;
						});
					}
				};
			},
			template:'<a href="javascript:void(0)" class="br-icon" data-toggle="popover" data-placement="top" popover>&nbsp;</a>'
		};
	}])
	// slider
	.directive("slider",function(contentManager){
		return {
			restrict: 'A',
			link: function(scope, ele, attr){	
				var config,
					configName,
					slider,
					update = function (number,event) {
						number = number===undefined || isNaN(number) ? 0 : number;
						setDataToScope(attr.slider,scope,stringToNumber(number));
						if (!event || event==='change') {
							slider.set(number);
						}
					},
					generalUpdateMethod = function (eventType) {
						return function(number){update(number,eventType);};
					};
				if(contentManager.getConfig().slider&&noUiSlider){
					configName = attr.config || "";
					config = contentManager.getConfig().slider[configName];
					if(config){

						config.start = getDataAtScope(attr.slider,scope) || (config.start!==undefined?config.start:undefined);
						slider = noUiSlider.create(ele[0], config);

						slider.on('change.meri', generalUpdateMethod('change'));
						slider.on('update.meri', generalUpdateMethod('update'));
						scope.$watch(attr.slider,function(value){
							slider.off('.meri');
							slider.set(value);
							slider.on('change.meri', generalUpdateMethod('change'));
							slider.on('update.meri', generalUpdateMethod('update'));
						});
					}
				}
			}
		};
	})

	.directive("ngFlag",function($injector){
		return {
			restrict: 'A',
			link: function(scope, ele, attr){
				ele.on("click",function(){
					var flagKey = attr.ngFlag,
						flagValue = attr.ngFlagValue;

					if(flagValue === "true"){
						flagValue = true;
					}else if(flagValue === "false"){
						flagValue = false;
					}
					setDataToScope(flagKey,scope,flagValue,$injector);
				});
			}
		};
	})

	.directive("boolean", function () {
		return {
			restrict: 'A',
			require: 'ngModel',
			link: function(scope, ele, attr, ctrl){

				var formatter = function (value) {
						return value?'true':'false';
					},
					parser = function (value/*,e*/) {
						return value!=='false' && value!=='0';
					};

				ctrl.$formatters.unshift(formatter);
				ctrl.$parsers.unshift(parser);
			}
		};
	})
	
	.directive("number", function ($filter/*,$compile, $locale, $window*/) {
		return {
			restrict: 'A',
			require: '?ngModel',
			link: function(scope, ele, attr, ctrl){
				if (attr.ngModel) {
					var precision = parseFloat(attr.precision),
						type = attr.number||'number',
						percentModifier = 1,
						filter,
						parser,
						formatter,
						min,
						max,
						forceRange,
						removeFormat,
						applyFormat,
						resolveDataPercent = function(value){return value/percentModifier;},
						resolveViewPercent = function(value){return value*percentModifier;};

					if (!$filter(type)) {
						type = 'number';
					}
					else if (type === 'percent') {
						percentModifier = 100;
					}

					filter = $filter(type);
					
					if(isNaN(precision)){
						precision = undefined;
					}

					// Where formattedValue = 3.00%
					// 	return: 3.00 (plainValue)
					removeFormat = function (formattedValue) {
						return $filter("naturalNumber")(formattedValue,precision);
					};

					// Where plainValue = 3.00 for 0.03 (3%)
					// 	return: %3.00 (formattedValue)
					applyFormat = function (plainValue) {
						// remove anything NOT a number
						plainValue = $filter('naturalNumber')(plainValue,precision);
						plainValue = resolveDataPercent(plainValue);
						return filter(plainValue,precision);
					};

					// Where value = modelValue 0.03 (for 3%)
					ctrl.$render = function(value){
						// console.log('RENDER');
						// Take entered value and apply the format
						value = value || ctrl.$modelValue;
						// applyFormat() will divide by 100; filter('percent') already does *100
						// But $formatters will only use applyFormat
						value = resolveViewPercent(value);
						ctrl.$viewValue = applyFormat(value);
						ele.val(ctrl.$viewValue);
					};

					// Executes when model data changed and view must be updated
					formatter = function (value) {
						// console.log('FORMATTER');
						return applyFormat(value);
					};

					parser = function (value) {
						// console.log('PARSER');
						value = cleanValue(value);
						value = stringToNumber(value,precision);
						value = resolveDataPercent(value);

						// if meriValid is present, let it take care of min-max validation
						if (!attr.meriValid) {
							min = attr.min&&attr.min!=='' ? stringToNumber(attr.min,precision) : undefined;
							max = attr.max&&attr.max!=='' ? stringToNumber(attr.max,precision) : undefined;
							forceRange = attr.forceRange==="false"?false:true;

							if (forceRange) {
								if (min!==undefined) {
									value = Math.max(min,value);
								}
								if (max!==undefined) {
									value = Math.min(max,value);
								}
							}
						}
						return value;
					};

					ctrl.$formatters.unshift(formatter);
					ctrl.$parsers.unshift(parser);

					ele.on("focus",function(/*e*/){
						// console.log('focus...');
						// Get and modify model value before raw display
						var value = resolveViewPercent(ctrl.$modelValue);
						// Set new view value
						ctrl.$setViewValue($filter("naturalNumber")(value,precision));
						// Update field element display
						ele.val(ctrl.$viewValue);
					});

					ele.on("blur",function(/*e*/){
						// console.log('blur...');
						// Set view value to formatted current view value
						// !! WARNING This value hasn't gone through parsers or validation yet
						ctrl.$setViewValue(applyFormat(ctrl.$viewValue));
						// Update field element display
						ele.val(ctrl.$viewValue);
					});
				}
			}
		};
	})

	/* Directive used on select html tag. It forces the select to keep their options values in string format but to save the selected value in number into the data object. */
	/* For example : We used this directive on payment frequency select. The value of the monthly option is : "1".But we want to have 1 in the data. We also use this directive on the product and term select field. */
	.directive("selectNumber", function (/*$filter,$locale, $window*/ ) {
		
		function parser (value) {
			return stringToNumber(value);
		}
		function formatter (value) {
			return value+"";
		}

		return {
			restrict: 'A',
			require: 'ngModel',
			link: function(scope, ele, attr, ctrl){
				ctrl.$formatters.unshift(formatter);
				ctrl.$parsers.unshift(parser);
			}
		};
	})
	/* Directive that permit to control the tabData service */
	/* This directive should be put on a A html element */
	/* The tabValue will */
	.directive("tabDefaultValue", function (tabData) {
		return {
			restrict: 'A',
			link: function(scope, ele, attr/*, ctrl*/){
				var tabValue = attr.tabDefaultValue||"",
					tabValueSp = tabValue.split(":"),
					tabGroupName,
					tabGroupValue;

				if(tabValueSp.length==2){
					tabGroupName = tabValueSp[0];
					tabGroupValue = tabValueSp[1];

					tabData.setCurrentTab(tabGroupName,tabGroupValue);
				}

			}
		};
	})
	/* Directive that permit to control the tabData service */
	/* This directive should be put on a A html element */
	/* the tab-group determine which group value will be set by clicking on this elem */
	.directive("tabGroup", function (tabData) {
		return {
			restrict: 'A',
			link: function(scope, ele, attr/*, ctrl*/){
				var tabName = attr.href||attr.tabValue,
					tabGroup = attr.tabGroup,
					storedValue = getStoredData(tabGroup+'-tab');

				if(typeof tabGroup === "string" && typeof tabName === "string"){
					tabName = tabName.replaceAll("#","");
					if(attr.tabDefault && attr.tabDefault==="true"&&!storedValue||storedValue===tabName){
						tabData.setCurrentTab(tabGroup,tabName);
					}
				}
				
				ele.on('click', function(e){
					e.preventDefault();
					e.stopPropagation();

					tabData.setCurrentTab(attr.tabGroup,tabName);
					scope.$apply();
				});
			}
		};
	})
	/* Directive that permit to save the current element ngModel value into the localStorage */
	/* The directive will also get back the value from the localStorage and inject it onto the ngModel */
	.directive('ngStorage',function(){
	    return {
	        restrict: 'A',
	        require: 'ngModel',
	        link: function($scope, $element, $attrs/*, ngModel*/) {
	            
	            var ngModelStr = $attrs.ngModel,
	                ngModelStrSplit = ngModelStr.split("."),
	                x = 0,
	                len = ngModelStrSplit.length,
	                obj = $scope,
	                last = len - 1,
	                key;

	            for(;x<len;x++){
	                key = ngModelStrSplit[x];

	                if(x === last){
	                    obj[key] = getStoredData($attrs.ngModel);
	                }else{
	                    if(obj[key]){
	                        obj = obj[key];
	                    }else{
	                        obj = obj[key] = {};
	                    }
	                }
	            }

	            $scope.$watch($attrs.ngModel, function(value) {
	                setStoredData($attrs.ngModel,value);
	            });
	            
	        }
	    };
	})

	.directive('meriSelect',function($compile){

		var directiveDefinitionObject = {
				restrict: 'E',
				// transclude: true,
				transclude: false,
				scope: {
					fieldSpecs:'<'
				},
				replace: true,
				controller: function ($scope,$element,$attrs/*,$transclude*/) {

					var excludeAttrTransfer = {fieldSpecs:true,fieldValidation:true,binding:true,label:true},
						addAttributes = [],
						filterDirective,
						binding = $attrs.binding,
						fieldSpecs = $scope.fieldSpecs || {};


// // Replace <transclude-content> element with content inserted in meri-select
// $transclude(function(clone, scope) {
// 	$element.find('transcluded-content').replaceWith(clone);
// 	// transcludedContent = clone;
// 	// transclusionScope = scope;
// });
					
					$scope.options = fieldSpecs.options || []
					
					$scope.label = fieldSpecs.label || '';

					switch (fieldSpecs.directive) {
						case 'boolean':
							filterDirective = 'boolean';
							break;
						case 'year':
						case 'percent':
						case 'currency':
						case 'number':
							filterDirective = 'select-number';
							break;
						default:
							filterDirective = false;
					}

					addAttributes.push({attr: 'ng-model', value: binding });

					$scope.label = fieldSpecs.label || $attrs.label || "";

					if (filterDirective) addAttributes.push({attr: filterDirective, value: fieldSpecs.directive });
					if (fieldSpecs.precision !== undefined) addAttributes.push({attr: 'data-precision', value: fieldSpecs.precision });
					// if ($attrs.fieldValidation) addAttributes.push({attr: 'meri-valid', value: $attrs.fieldValidation });
					if ($attrs.fieldValidation) addAttributes.push({attr: 'meri-form-valid', value: $attrs.fieldValidation });

					for (prop in $attrs.$attr) {
						if (excludeAttrTransfer[prop] === undefined) {
							addAttributes.push({attr: $attrs.$attr[prop], value: $attrs[prop] });
						}
					}

					$scope.selectAttributes = addAttributes;
				},
				compile: function compile(/*tElement, tAttrs*/) {
					
					return {
						// Before Link compile
						pre: function preLink(scope, elem/*, attrs, ctrl*/) {
							var i = 0,
								len = scope.selectAttributes.length,
								prop,
								select = elem.find('select');
							for (;i<len;i++) {
								if (scope.selectAttributes[i].attr === 'class') {
									select.addClass(scope.selectAttributes[i].value || '');
								}
								else {
									select.attr(scope.selectAttributes[i].attr, scope.selectAttributes[i].value !== undefined ? scope.selectAttributes[i].value : '');
								}
							}

							select.on('keyup',function(e){
								var eKey = e.which || e.key,
									selected = select.find("option:selected");
								if ( (eKey === 38) || (eKey === 40) ) {
									select.change();

									// console.log('KEY UP, current now',selected.val());
									return false;
								}

								
							});

							// select.on('keydown',function(e){
							// 	var eKey = e.which || e.key,
							// 		selected = select.find("option:selected"),
							// 		next = selected.next(); // previous
							// // 	if ( (eKey === 38 && !selected.is(":first-child")) || (eKey === 40 && !selected.is(":last-child")) ) {    //    up arrow
							// // 		// console.log('----- KEYDOWN value:',selected.val(),select);
							// // 		console.log('----- KEYDOWN value:',selected.val(),select);
							// // 		select.change();
							// // 		return false;
							// // 	}
								
							// 	// console.log('KEY DOWN, current, next',selected.val(),next.val());
							// 	return false;
							// });
						},
						// After Link compile
						// Attach events here
						post: function postLink(scope, elem/*, attrs, ctrl*/) {
							$compile(elem.contents())(scope.$parent);
						}
					};
				},

				template: function(element,attr){
					return '<div class="form-group">'+
							'<label for="{{ name }}">{{ label }}</label>'+
							'<select id="{{ name }}" class="form-control">'+
								'<option ng-repeat="option in options" value="{{ option.value }}">{{ option.label }}</option>'+
							'</select>'+
// '<transcluded-content></transcluded-content>' +
							'<span class="clearfix"></span>'+
						'</div>';
				}
			};

		return directiveDefinitionObject;
	})

	.directive('meriTooltip',function($compile){
		var template = {
				tooltip:'<a href="javascript:void(0)" class="br-icon" data-toggle="tooltip" data-placement="top">&nbsp;</a>'
			},

			directiveDefinitionObject = {
				restrict: 'E',
				transclude: false,
				scope: {
					parent:'=',
					message:'='
				},
				replace: true,
				controller: function ($scope,$element,$attrs,$interpolate) {
					$scope.getMeriTooltipContent = function () {
						if (typeof $scope.message.getMessage) {
							return $interpolate($scope.message.getMessage())($scope.parent || $scope.$parent);
						}
						else if (typeof $scope.message === 'string') {
							return $interpolate($scope.message)($scope.parent || $scope.$parent);
						}
						else {
							return '';
						}
					};

					// $scope.el = $element;
				},
				compile: function compile(tElement, tAttrs) {
					
					return {
						// Before Link compile
						pre: function preLink(scope, elem/*, attrs, ctrl*/) {
							elem.removeClass('tooltip');
							elem.removeAttr('tooltip');
						},
						// After Link compile
						// Attach events here
						post: function postLink(scope, elem/*, attrs, ctrl*/) {
							elem.attr('data-original-title',scope.getMeriTooltipContent());
							elem.tooltip();
							elem.on('show.bs.tooltip',function(){
								elem.attr('data-original-title',scope.getMeriTooltipContent());
							});

							// console.log('elem.parent()',elem.parent());
							// console.log('tElement.parent()',tElement.parent());
							// console.log('scope.el.parent()',scope.el.parent());
						}
					};
				},

				template: function(element,attr){
					return template.tooltip;
				}
			};

		return directiveDefinitionObject;
	})

	.directive('meriInput',function($compile,$interpolate){

		var template = {
				meriTooltip:'<meri-tooltip parent="parent" message="tooltip"></meri-tooltip>',
				// unbreakable:{open:'<span class="unbreakable">',close:'</span>'}
				unbreakable:'<span class="unbreakable"></span>'
			},

			// 
			directiveDefinitionObject = {
				restrict: 'E',
				// transclude: true,
				transclude: false,
				scope: {
					fieldSpecs:'<'
				},
				replace: true,
				controller: function ($scope,$element,$attrs/*,$transclude*/) {
					var excludeAttrTransfer = {fieldSpecs:true,fieldValidation:true,binding:true,label:true}, 
						inputAttributes = [],
						filterDirective,
						fieldSpecs = $scope.fieldSpecs || {},
						binding = $attrs.binding,
						prop;

					$scope.parent = $scope.$parent;

// // Replace <transclude-content> element with content inserted in meri-input
// $transclude(function(clone, scope) {
// 	$element.find('transcluded-content').replaceWith(clone);
// 	// transcludedContent = clone;
// 	// transclusionScope = scope;
// });
					
					if ($attrs.fieldSpecs && $attrs.fieldSpecs!== '' && $attrs.fieldSpecs.split('.').length > 1) {
						$scope.name = 'meri-' + $attrs.fieldSpecs.split('.').slice(1).join('-');
					}
					else {
						$scope.name = 'meri-' + ($attrs.fieldSpecs || '');
					}
					
					$scope.id = $scope.$parent.$eval($attrs.id) || $attrs.id || '';

					switch (fieldSpecs.directive) {
						case 'boolean':
							filterDirective = 'boolean';
							break;
						case 'year':
						case 'percent':
						case 'currency':
							filterDirective = 'number';
							break;
						default:
							filterDirective = false;
					}

					inputAttributes.push({attr: 'ng-model', value: binding });

					$scope.binding = binding;
					$scope.label = fieldSpecs.label || $attrs.label || "";

					if (filterDirective) inputAttributes.push({attr: filterDirective, value: fieldSpecs.directive });
					if (fieldSpecs.precision !== undefined) inputAttributes.push({attr: 'data-precision', value: fieldSpecs.precision });
					if ($attrs.fieldValidation) inputAttributes.push({attr: 'meri-form-valid', value: $attrs.fieldValidation });
					if (fieldSpecs.tooltip) {

						$scope.tooltip = customMessageFactory(fieldSpecs.tooltip);
						// TEMPORARY!!!
						// Create function to get a parse-safe string from $attrs.tooltipCustoms
						if ($attrs.tooltipCustoms) {
							$scope.tooltip.setCustom(JSON.parse($attrs.tooltipCustoms.split("'").join('"')));
						}
					}

					for (prop in $attrs.$attr) {
						if (excludeAttrTransfer[prop] === undefined) {
							inputAttributes.push({attr: $attrs.$attr[prop], value: $attrs[prop] });
						}
					}

					$scope.inputAttributes = inputAttributes;
				},
				compile: function compile(tElement, tAttrs) {
					
					return {
						// Before Link compile
						pre: function preLink(scope, elem/*, attrs, ctrl*/) {
							var i = 0,
								len = scope.inputAttributes.length,
								prop,
								input = elem.find('input'),
								label = elem.find('label'),
								labelText,
								labelLastWord;
							for (;i<len;i++) {
								if (scope.inputAttributes[i].attr === 'class') {
									input.addClass(scope.inputAttributes[i].value || '');
									elem.removeClass(scope.inputAttributes[i].value || '');
								}
								else {
									input.attr(scope.inputAttributes[i].attr, scope.inputAttributes[i].value !== undefined ? scope.inputAttributes[i].value : '');
								}
							}

							if (scope.tooltip) {
								labelText = scope.label.split(' ');
								labelLastWord = labelText.pop();


								scope.label = labelText.join(' ') + ' ';
								prop = $(template.unbreakable).text(labelLastWord).append($compile(template.meriTooltip)(scope));

								labelText = label.text('{{ label }} ').append(prop);
							}
						},
						// After Link compile
						// Attach events here
						post: function postLink(scope, elem/*, attrs, ctrl*/) {
							$compile(elem.contents())(scope.$parent);
						}
					};
				},

				template: function(element,attr){
					return '<div class="form-group">' +
						'<label for="{{ id }}">{{ label }}</label>' +
						'<input id="{{ id }}" name="{{ id }}" class="form-control" type="text" ng-model-options="\{ updateOn: \'blur\',allowInvalid: \'true\' \}"/>' +
					'<span class="clearfix"></span>' +
				'</div>';
				}
			};

		return directiveDefinitionObject;
	})

	.directive('chart',function(){
		return {
			restrict: 'E',
			require: '?ngModel',
			transclude: true,
			scope: {
				value: '=ngModel',
				highchart: '=highchart'
			},
			link: function(scope, elem, attrs, ngModel){
				if (!ngModel || !window.Highcharts) return;

				ngModel.$render = function(){
               scope.value = ngModel.$modelValue;

               if (scope.value) {

               	elem.highcharts(scope.value);
               	
               	if (attrs.highchart) {
               		scope.highchart = elem.highcharts();
               	}

               	var count=0,
               		countMax=10,
               		tmFunc = function(){
	               			++count;
								if (elem.is(':visible')) {
									if (count!==1) {
										elem.highcharts().reflow();
										elem.highcharts().redraw();
									}
								}
								else if (count < countMax){
									setTimeout(tmFunc,100);
								}
							};
						tmFunc();
               }
            };
			}
		};
	})

	.directive("meriFormValid", function($compile) {

		var validStr = 'validation',
			directiveDefinitionObject = {
				restrict:'A',
				require:'?ngModel',
				scope:true,

				link:function (scope,elem,attrs,ngModelCtrl) {

					var parentElem = elem.parents('.form-group'),
						validator = function (value) { return value; },
						errorElem,v;

					v = scope.$parent.$eval(attrs.meriFormValid) || {} /*validationConfig[validStr][propName] = factoryValidation( specs )*/;

					if (v && typeof v.validate === 'function') {

						// This will allow the validation object to trigger the ngModel validator
						v.setModel(ngModelCtrl);

						parentElem.append('<span class="error-message"></span>');

						errorElem = parentElem.find('.error-message');

						if (elem[0].tagName === 'INPUT') {

							validator = function (value) {
								// console.log('validate value',value,ngModelCtrl.$modelValue,ngModelCtrl);
								var valid;

								if (v && typeof v.validate==='function') {

									valid = v.validate(value);
									if (valid!==true) {
										// set error message
										errorElem.text(valid.message);
										$compile(errorElem.contents())(scope.$parent);
										// Make error visible
										parentElem.addClass('error');

										value = valid.value;
										// Update view value with validated value (will format value)
										// Render function from "number" also updates $modelValue
										ngModelCtrl.$viewValue = value;
										ngModelCtrl.$render(value);
										ngModelCtrl.$setViewValue(ngModelCtrl.$viewValue);
										elem.val(ngModelCtrl.$viewValue);
										// Commit view value to the actual model (and corrects any unsynchronised data between view/model)
										// This step will recommit the value through the $parsers & $validators pipelines
										ngModelCtrl.$commitViewValue();
									}
								}

								// console.log('VALIDATOR value',value,ngModelCtrl.$pending);
								return value;
							};
						}
						
						else if (elem[0].tagName === 'SELECT') {

							validator = function (value) {
								var valid;

								if (v && typeof v.validate==='function') {
									valid = v.validate(value);
									if (valid!==true) {
										
										value = valid.value;
										// Update view value with validated value (will format value)
										// Render function from "number" also updates $modelValue
										ngModelCtrl.$viewValue = value;
										ngModelCtrl.$render(value);
										elem.val(ngModelCtrl.$viewValue);
										elem.find('option[value="'+value+'"]').eq(0).prop('selected',true);
										ngModelCtrl.$setViewValue(ngModelCtrl.$viewValue);
										// Commit view value to the actual model (and corrects any unsynchronised data between view/model)
										// This step will recommit the value through the $parsers & $validators pipelines
										ngModelCtrl.$commitViewValue();

										// set error message
										errorElem.text(valid.message);
										$compile(errorElem.contents())(scope.$parent);
										// Make error visible
										parentElem.addClass('error');
									}
								}
								return value;
							};
						}

						ngModelCtrl.$validators.meriValid = validator;

						// Errors are always removed from element onBlur
						// Event order:
						// 	focus
						// 	blur
						// 	parsers
						// 	validators
						// If errors remain, validator will reset error
						elem.on('blur',function(/*event*/){
							parentElem.removeClass('error');
							errorElem.text('');
						});
					}
				}
			};
		return directiveDefinitionObject;
	})
	
/////////////
// FILTERS //
/////////////
	// html
	// 	Allow ng-bind-html to render html tags
	// 	To enable render expression, use bind-html-compile directive (plug-in)
	.filter('html',['$sce',/*'$compile',*/ function ($sce/*,$compile*/) {

		return function (text) {
			return $sce.trustAsHtml(text);
		};
	}])
	// number
	// 	Filter to convert a displayed value into numeral string
	.filter('number', function() {
	  return function(val,precision,round,natural) {
			var hasPrecision,
				roundFct = Formula.ROUND/*,
				indexStart,
		  		len,
		  		supposeLen*/;
			if (typeof precision === "string") {
				precision = stringToNumber(precision);
			}
			hasPrecision = typeof precision === "number";
			val = stringToNumber(val);
			round = stringToNumber(round);

			if(round<0){
				roundFct = Formula.ROUNDDOWN;
			}else if(round>0){
				roundFct = Formula.ROUNDUP;
			}

			if(hasPrecision){

				val = roundFct(val,precision);

				if(!natural){
					// WARNING toLocaleString() is not compatible with IE9
					// val = val.toLocaleString(getLanguage());
					val = formatGeneral(val,precision,getLanguage());
				}
			}
			return val+"";
		};
	})

	.filter('naturalNumber',function($filter) {
		return function(val,precision,round) {
			val = $filter('number')(val,precision,round,true);
			return val;
		};
	})
	// percent
	// 	Filter to convert a displayed value into numeral percentage string
	.filter('percent', function($filter) {
	  return function(val,precision,round) {
	  	val = stringToNumber(val);
	  	val *=100;
	  	val = $filter('number')(val,precision,round);
	    return val+"%";
	  };
	})
	//year
	.filter('year', function($filter) {
	  return function(val,precision,round) {
	  	var lg = getLanguage(),
	  		word;

	  	if(lg === 'en'){
	  		word = 'year';
	  	}else if(lg === 'fr'){
	  		word = 'an';
	  	}

	  	if(word){
	  		val = $filter('number')(val,precision,round);
	  		val = val + " "+ plurializeWordWithNumber(word,val);
	  	}

	    return val;
	  };
	})
	.filter('month',function($filter){
		return function(val,precision,round) {

	    	var lg = getLanguage(),
		  		word;

		  	if(lg === 'en'){
		  		word = 'month';
		  	}else if(lg === 'fr'){
		  		word = 'mois';
		  	}

		  	if(word){
			  	val = val * 365.25 / (365.25/12);
				val = $filter('number')(val,precision,round);
		  		val = val + " "+ (lg!=='fr'?plurializeWordWithNumber(word,val):word);
		  	}
		    return val;
	    };
	})
	.filter('day',function($filter){
		return function(val,precision,round) {

	    	var lg = getLanguage(),
		  		word;

		  	if(lg === 'en'){
		  		word = 'day';
		  	}else if(lg === 'fr'){
		  		word = 'jour';
		  	}

		  	if(word){
			  	val = val*365.25;
				val = $filter('number')(val,precision,round);
		  		val = val + " "+ plurializeWordWithNumber(word,val);
		  	}
		    return val;
	    };
	})
	.filter("moreThanAYear",function($filter){
		return function(val,precision,round) {
	  	
	  	val = $filter('number')(val,precision,round);

	  	if(val < 1){
	  		return "< "+$filter('year')(1,precision,round);
	  	}
	    return $filter('year')(val,precision,round);
	  };
	})
	//currency
	.filter('currency', function($filter) {
	  return function(val,precision,round) {
	  	var lg = getLanguage();
	  	val = $filter('number')(val,precision,round);

	  	if(lg === 'en'){
	  		val = "$"+val;
	  	}else if(lg === 'fr'){
	  		val = val+"$";
	  	}
	    return val;

	  };
	})
/////////////
// SERVICE //
/////////////

	.service("tabData",function(){
		var data = {
				tabList:{

				}
			};

		this.setCurrentTab = function(tabGroupName,tabName){
			if(typeof tabGroupName === "string" && typeof tabName === "string"){
				tabName = tabName.replaceAll("#","");
				data.tabList[tabGroupName] = tabName;
				setStoredData(tabGroupName+'-tab',tabName);
				var tabGroupElem = $('[ng-app="br-calc"] [tab-group='+tabGroupName+']'),
					currentTabGroupElem = tabGroupElem.filter("[href='#"+tabName+"']"),
					otherTabGroupElem = tabGroupElem.not(currentTabGroupElem);

				currentTabGroupElem.addClass('br-selected');
				otherTabGroupElem.removeClass('br-selected');
			}
		};

		this.getCurrentTab = function(tabGroupName){
			return data.tabList[tabGroupName];
		};
	})
	// TODO: Remove validation responsibility from scenarios
	// TODO: Replace all older meri input with NEW optimised meri-input
	.service("scenarios",['contentManager',function(contentManager){

		var me = this,
			// appScenariosConfig = contentManager.getConfig('scenarios',true);
			appScenariosConfig = contentManager.getConfig('scenarios');

		this.scenarios = {
			model:{

				data:{
					scenarios:[],
					scenarioModel:{
						data:{},
						results:{},
						validation: {},

						validate: validateScenario
					}
				},

				results:{},

				validation: {},

				getScenario:getScenario
			}
		};

		this.getScenario = function(name,index){
			return me.getScenarios(name).getScenario(index);
		};

		this.getScenarios = function (name) {

			var scenarioFamily = name&&me.scenarios[name];
			if (!scenarioFamily) {
				if (name!==undefined&&name!=='') {

					if (!me.scenarios[name]&&appScenariosConfig[name]) {
						// scenarioFamily = me.scenarios[name] = $.extend(true,{},me.scenarios.model,appScenariosConfig[name]);
						scenarioFamily = me.scenarios[name] = $.extend(true,appScenariosConfig[name],me.scenarios.model);
						createDefaultValidation(scenarioFamily);
					}
				}
			}
			scenarioFamily = me.scenarios[name] = scenarioFamily ||  $.extend(true,{},me.scenarios.model);
			return scenarioFamily;
		};

		// Internal methods
		// This => reference to the element from which it is called
		function getScenario (index){
			var scenario = this.data.scenarios[index];
			if(!scenario){
				scenario = this.data.scenarios[index] = newScenario(this.data.scenarioModel);
				scenario.data.index = index;
			}
			return scenario;
		}
		function newScenario (model, overridingModel) {

			var scenario = $.extend(true,{},model||{},overridingModel||{});
			createDefaultValidation(scenario);

			scenario.resetScenario = getDefaultResetFunction(scenario);

			return scenario;
		}
		function getDefaultResetFunction (defaultModel) {
			var defaultScenario = $.extend(true,{},defaultModel);
			return function() {
				$.extend(true,this,defaultScenario);
			};
		}
		function resetScenario (){

			var scenario = this.data.scenarios[index];
			if(scenario){
				scenario = this.data.scenarios[index] = newScenario(this.data.scenarios[index],this.data.scenarioModel);
				scenario.data.index = index;
			}
			return scenario;
		}
		
		function createDefaultValidation (scenario) {
			var prop;
			// Remains for now in order to be backward compatible.
			// REMOVE when other cals config is modified
			for (prop in scenario.validation) {
				scenario.validation[prop] = factoryValidation(scenario.validation[prop]);
				// scenario.validation[prop].setValue(scenario.data[prop]);
			}
		}

		function validateScenario () {
			var prop;
			for (prop in this.validation) {
				this.validation[prop].triggerValidation();
			}
		}
	}]);

// {
// 	currentAge:'sce.data.currentAge',
// 	8:88,
// 	'lala':97,
// 	"yup":[2,4,'trevor',"another"],
// 	last:{
// 		currentAge:'sce.data.currentAge',
// 		8:88,
// 		'lala':97,
// 		"yup":[2,4,'trevor',"another"]
// 	}
// }
// 
// var TESTING = "{currentAge:'sce.data.currentAge',8:88,'lala':97,\"yup\":[2,4,'trevor',\"another\"],last:{currentAge:'sce.data.currentAge',8:88,'lala':97,\"yup\":[2,4,'trevor',\"another\"]}}";

// function getParseFriendlyString (str,recurrent) {
// 	var parseFriendlyStr='',
// 		allSplit = str.split(':'),
// 		i=0,
// 		allLen=allSplit.length,
// 		isProp=true,
// 		// isValue=false,
// 		isOpenQuote=false;

// 	for (;i<allLen;i++) {

// 	}

// 	if (!recurrent) {
// 		parseFriendlyStr = '"' + parseFriendlyStr + '"';
// 	}

// 	return parseFriendlyStr;
// }

// console.log(getParseFriendlyString(TESTING));

function customMessageFactory (options) {
	var me = typeof options === 'string' ? {message:options} : options || {},
		renderedMessage = me.message || '';

	me.message = renderedMessage;
	me.custom = me.custom || {};

	function generateMessage () {
		var m = me.message,prop;
		for (prop in me.custom) {
			if (m.indexOf('['+prop+']')!==-1) m = m.split('['+prop+']').join(me.custom[prop]);
		}
		return m;
	}

	function updateRenderedMessage () {
		renderedMessage = generateMessage();
	}

	function updateCustoms (customs) {
		customs = typeof customs === 'object' && customs !== null && customs || {};
		$.extend(true,me.custom,customs);
	}

	return {
		getMessage : function () {
			return renderedMessage;
		},
		setCustom : function (options) {
			updateCustoms(options);
			updateRenderedMessage();
			return this;
		}
	}
}


var factoryValidation = function (c) {
	// Even undefined validation config should get a validation object, as a blank slate for future setup
	var validationConfig = $.extend(true,{ rules: [] }, c || {}),
		defaultIsValid = true,
		currentValue,
		rulesDictionnary = {
			readjust: {
				name: 'readjust',
				validate : function (value,validationObject) {
					var bustMin = validationObject.min!==undefined && value<validationObject.min,
						bustMax = validationObject.max!==undefined && value>validationObject.max;
					if (bustMin || bustMax) {
						if (bustMin) this.correctedValue = validationObject.min;
						if (bustMax) this.correctedValue = validationObject.max;
					}

					return !(bustMin || bustMax);
				},
				message : '{{ content.errors.readjust }}'
			},
			default: {
				name: 'default',
				validate:function () { return defaultIsValid; },
				message:'{{ content.errors.default }}',
				priority:0 // 0 = no rule priority, 1 = highest priority, 2 = lower priority, etc.
			}
		},
		ngModelCtrl; // needed in order to programatically trigger ngModel validator

	function generateError (value, validationObject) {
		return {
			name: validationObject.currentRule.name,
			message: customizeMessage(validationObject,validationObject.currentRule),
			value: currentValue
		};
	}

	function customizeMessage (validationObject, rule) {
		var message = rule.message,
			customize = rule.customize,
			key,
			prop;

		if (customize) {
			for (prop in customize) {
				key = '['+prop+']';
				message = message.split(key).join(getItemAtPath(customize[prop],validationObject)+'');
			}
		}
		return message;
	}

	// Validate and set default values
	function validateRulesConfig () {

		var i=0,
			len=validationConfig.rules&&validationConfig.rules.length||0,
			rule,
			dictRule;

		if (!len && c.validation!==false) {
			// When setting validation rules, if no rule is set AND validation=false not specified,
			// assume default validation readjust
			// validationConfig.rules.push('readjust');
			validationConfig.rules.push(rulesDictionnary.readjust);
			len = 1;
		}
		else if (c.validation===false) {
			validationConfig.rules.push(rulesDictionnary.default);
			len = 1;
		}

		for(;i<len;i++) {
			rule = validationConfig.rules[i];

			dictRule = rulesDictionnary[rule.name||''];
			// Validate function && name
			if (typeof rule === 'string' && rulesDictionnary[rule]) {
				rule = validationConfig.rules[i] = rulesDictionnary[rule];
			}
			else if (typeof rule.validate === 'string' && rulesDictionnary[rule.validate]) {
				if (rule.name===undefined) {
					rule.name = rulesDictionnary[rule.validate].name;
				}
				if (rule.priority===undefined) {
					rule.priority = rulesDictionnary[rule.validate].priority || rulesDictionnary.default.priority;
				}
				if (rule.message===undefined) {
					rule.message = rulesDictionnary[rule.validate].message || rulesDictionnary.default.message;
				}
				rule.validate = rulesDictionnary[rule.validate].validate;
			}
			else if (!rule.validate || typeof rule.validate !== 'function') {
				rule.validate = dictRule&&dictRule.validate || rulesDictionnary.default.validate;
			}
			// Priority
			if (rule.priority===undefined) {
				rule.priority = rulesDictionnary.default.priority;
			}
			else if (typeof rule.priority !== 'number') {
				if (typeof rule.priority !== 'string') {
					rule.priority = rulesDictionnary.default.priority;
				}
				else {
					rule.priority = stringToNumber(rule.priority);
				}
			}
			// Message
			if (rule.message === undefined) {
				rule.message = dictRule&&dictRule.message || rulesDictionnary.default.message;
			}
			else {
				rule.message = rule.message + '';
			}
			// Autocorrect
			if (rule.autocorrect===undefined) {
				rule.autocorrect = true;
			}
		}
	}

	// Validation filters
	function organiseByPriority () {
		validationConfig.rules = validationConfig.rules.sort(function(a,b){ return (a.priority||9999999)-(b.priority||9999999); });
	}
	function removeRule (name) {
		validationConfig.rules = validationConfig.rules.filter(function(a){ return a.name!==name; });
	}
	function getRuleByName (name) {
		return validationConfig.rules.filter(function(a){ return a.name===name; })[0];
	}

	// Refresh
	function refresh () {
		validateRulesConfig();
		organiseByPriority();
	}

	function setModel (modelCtrl) {
		if (modelCtrl && modelCtrl.$setDirty) {
			ngModelCtrl = modelCtrl;
		}
	}

	function setValue (value) {
		currentValue = value;
	}

	function addRule (rule) {
		var i=0;
		if (rule&&rule.name) {
			for (;i<validationConfig.rules.length;i++) {
				if (validationConfig.rules[i].name===rule.name) {
					$.extend(true,validationConfig.rules[i],rule);
					return;
				}
			}
		}
		validationConfig.rules.push(rule);
	}

	refresh();

	return {
		triggerValidation:function () {
			if (ngModelCtrl && ngModelCtrl.$validate && currentValue !== undefined) {

				// Because validating an unchanged field "invalidates" the value from angular's point of view,
				// modelValue sent back to the data is "undefined".
				// In order to prevent this, ng-model-options allowInvalid must be set to "true".
				// meri-input elements are set to support this.
				if (ngModelCtrl.$options === null || ngModelCtrl.$options === undefined) {
					ngModelCtrl.$options = {};
				}
				if (!ngModelCtrl.$options.allowInvalid) ngModelCtrl.$options.allowInvalid = true;

				ngModelCtrl.$validate();
			}
			return this;
		},

		setModel: function (modelCtrl) {
			setModel(modelCtrl);
			return this;
		},

		setValue: function (value) {
			setValue(value);
			return this;
		},

		set: function (propName, value, revalidate) {
			propName = propName!==undefined && propName!=='rules' && propName+'' || '';
			validationConfig[propName] = value;
			if (revalidate===true) {
				return this.validate(currentValue);
			}
			else {
				return this;
			}
		},

		validate: function(value) {
			// console.log('validate', value, validationConfig.rules);
			var i = 0,
				len = validationConfig.rules.length,
				rule,
				isValid = true,
				reducedValidationConfig;

			this.setValue(value);

			for (;i<len;i++){
				rule = validationConfig.rules[i];
				reducedValidationConfig = $.extend(true,{},validationConfig,{currentRule:rule});
				// Autocorrect state is set to the whole validation object
				reducedValidationConfig.autocorrect = rule.autocorrect;

				isValid = rule.validate(currentValue, reducedValidationConfig);
				if (isValid!==true) {
					if (rule.autocorrect) setValue(rule.correctedValue || value);
					isValid = generateError(currentValue,reducedValidationConfig);
					break;
				}
			}
			return isValid;
		},

		addRule: function (rule) {
			// console.log('addRule',rule);
			addRule(rule);
			refresh();
			// console.log('after addRule',validationConfig.rules);
			return this;
		},

		removeRule: function (name) {
			if (name && typeof name === 'string' && name !== '') removeRule(name);
			return this;
		},

		refresh: function() {
			refresh();
			return this;
		},

		hasRule: function (name) {
			return name!==undefined && getRuleByName(name).length || false;
		},

		// get : function (prop) {
		// 	return validationConfig[prop];
		// },

		trace:function(){
			console.log('DEBUG VALIDATOR',rulesDictionnary.readjust.rand);
			console.log('validationConfig',$.extend(true,{},validationConfig) );
			console.log('rules',$.extend(true,{},validationConfig).rules );
			console.log('END DEBUG VALIDATOR',currentValue);

			return rulesDictionnary.readjust.rand;
		}
	};
};

window.getChangedPropertyName = function  (oldData,newData) {
	var prop,
		changedValueProp;
	for (prop in newData) {
		if (typeof newData[prop] === 'object' && typeof oldData[prop] === 'object') {
			changedValueProp = getChangedPropertyName(oldData[prop],newData[prop]);
			if (typeof changedValueProp === 'string') return changedValueProp;
		}
		else if (oldData[prop] === undefined || oldData[prop]!==newData[prop]) {
			return prop;
		}
	}
	return false;
};

window.formatGeneral = function  (v,p,lang) {
	p=p>>0;
	var s1='',s2='',nbr=String.fromCharCode(160),
		t=lang=='fr'?nbr:',',
		c=lang=='fr'?',':'.';

	v=isNaN(v=parseFloat(""+v))?0:v;
	v=v.toFixed(p!==undefined?p:2).split('.');
	v[0]=v[0].replace(/(\d)(?=(\d{3})+\b)/g,'$1'+t);

	return (s1||'')+v.join(c)+(s2||'');
};

window.plurializeWordWithNumber = function (word,num){
	var lg = getLanguage();
	num = typeof num !== 'number' ? stringToNumber(num) : num;
	if(lg === 'fr' && num > 1) word = word+"s";
	else if(lg === 'en' && num !== 1) word = word+"s";
	return word;
};

window.setStoredData = function (key,val) {
  if (window.localStorage) window.localStorage.setItem(key, val);
};

window.getStoredData = function (key) {
    return window.localStorage && window.localStorage.getItem(key);
};

/* Extension od the string class */
/* Method that replace all the found string by another one */
// String.prototype.replaceAll = function (find, replace) {
//     var str = this;
//     return str.replace(new RegExp(find.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&amp;'), 'g'), replace);
// };

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    replacement = replacement||"";
    return target.replace(new RegExp(search, 'g'), replacement);
};

String.prototype.toCamelCase = function(str) {
    return (str||this)
    	.replaceAll("-"," ")
    	.replaceAll("_"," ")
        .replace(/\s(.)/g, function($1) { return $1.toUpperCase(); })
        .replace(/\s/g, '')
        .replace(/^(.)/, function($1) { return $1.toLowerCase(); });
};

window.getCurrentPrefix = function  (url) {
	var prefix = url.split('/');
	if (prefix.length > 1) {
		prefix.pop();
	}
	prefix = prefix.join('/').split('\\');
	if (prefix.length > 1) {
		prefix.pop();
	}
	prefix = prefix.join('\\');
	return prefix;
};

window.stringToStringNumber = function (value) {
	if(typeof value === "string"){
		value = value.replaceAll("%","");
		value = value.replaceAll("$","");
		value = value.replaceAll(" ","");
	}
	return value;
};

/* Method that convert a string into a valid number */
window.stringToNumber = function (value) {
	var parsed = parseFloat(value);
	if (!isNaN(parsed)) {
		if (typeof value === 'string') {
			value = parseFloat(value.split(',').join(''));
		}
		else {
			value = parsed;
		}
	}
	else {
		value = 0;
	}	
	return value;
};

/* Filter method to use with arrays */
window.onlyUnique = function (value,index,self) {
	return self.indexOf(value) === index;
};

window.getDataAtScope = function  (ngModel,scope){
	var ngModelSplitted,
		len,
		count=0,
		obj = scope,
		key,
		isLast,
		value;
	
	ngModel = ngModel ||"";
	if(ngModel){
		ngModelSplitted = ngModel.split(".");
		len = ngModelSplitted.length;
		for(;count<len;count++){
			isLast = count+1===len;
			key = ngModelSplitted[count];
			if(isLast&&obj){
				value = obj[key];
				break;
			}
			if(obj){
				obj = obj[key];
			}	
		}
	}
	return value;
};

window.setDataToScope = function (ngModel,scope,value,$injector){
	var ngModelSplitted,
		len,
		count=0,
		obj = scope,
		key,
		isLast,
		prev,
		service;

	ngModel = ngModel ||"";
	if(ngModel){

		ngModelSplitted = ngModel.split(".");
		len = ngModelSplitted.length;
		if($injector){
			service = $injector.get(ngModelSplitted[0]);
			if(service){
				obj = service;
				count++;
			}
		}

		for(;count<len;count++){

			isLast = count+1===len;
			key = ngModelSplitted[count];

			if(isLast&&obj){

				obj[key] = value;

				if (!scope.$$phase){
					scope.$apply();
				}
			}
			if(obj){
				obj = obj[key] || {};
			}
			prev = key;
		}
	}
};
})($cmsj,$cmsj);
(function($,jQuery){

brCalc.controller('investmentSelector', function($scope, $filter, contentManager) {

		this.content = contentManager.setContent(istContent,'istContent').getContent('istContent');
		var calcConfig = contentManager.setConfig(istConfig).getConfig(),
			me = this,
			VALUE_UNLIMITED = 'unlimited';

		updateIstRates();

		//////////////////////////////
		// Scope accessible objects //
		//////////////////////////////
		// Make pageOrder scope accessible in view
		this.pageOrder = calcConfig.pageOrder;
		this.sectionsNumber = this.pageOrder.length;
		this.lastSectionId = this.sectionsNumber-1;

		this.sections = $.extend(true,{},this.content.pages,getSectionsValidation());

		this.data = {
			stopAsking:false,
			term:0,
			accessTerm:1
		};

		this.results = {
			products:{},
			graphVisibility:[],
			highchart:{}
		};

		// Set current section
		this.maxProgress = 0;
		this.progressPercent = 0;
		this.currentSection = {};

		updateCurrentSection(0);

		initHighchart();

		//////////////////////////////
		// Scope accessible methods //
		//////////////////////////////

		// Methods to change sections
		this.goToNextSection = function(){
			if (me.sections[me.currentSection.name].isValid) {
				// Can't move forward without validating answers
				updateCurrentSection(getNextSectionId(me.currentSection.id));
			}
		};
		this.goToPreviousSection = function(){
			updateCurrentSection(getPreviousSectionId(me.currentSection.id));
		};
		this.goToSection = function(name){
			var id = getSectionId(name);
			updateCurrentSection(id);
		};

		///////////////////
		// Watch objects //
		///////////////////
		$scope.$watchCollection("ist.data",function(/*data*/){
			updateAvailability(0,true);
			updateProgress(); // Update progress and allowed sections each time the data is modified
		});
		$scope.$watch("ist.data.accountType",adjustStopAksingState);
		$scope.$watch("ist.data.isReg",adjustStopAksingState);
		$scope.$watchCollection("ist.results.graphVisibility",function(){
			// Only update on result (last) page
			if(me.currentSection.name==='results') {
				updateHighchartVisibility();
			}
		});
		$scope.$watch("ist.currentSection.id",function(){
			updateAvailability(me.currentSection.id,true);
			updateProgress();
		});

		//////////////////////
		// Internal methods //
		//////////////////////
		
		function getTermString (val,precision) {
			precision = precision || 0;
			return val===0?0:val<1?$filter('day')(val,0):$filter('year')(val,precision);
		}

		function initHighchart() {
			me.results.highchart.config = (function(){

				var config = calcConfig.highchart.ist_highchart,
					content = me.content.chart;

				// Tooltip formatting
				if (!config.tooltip) config.tooltip = {};
				config.tooltip.formatter = function(){
					var options = this.point.options,
						str = '<strong>' + this.series.name + '</strong><br/>';
					if (options.x === 0) { str += content.investmentStart + $filter('currency')(this.y,2); }
					else{
						if (options.high!==undefined) str += content.from + $filter('currency')(options.low,2) + content.to + $filter('currency')(options.high,2);
						else str += $filter('currency')(options.y,2);
						str += content.after + getTermString(options.x,0);
					}
					return str;
				};

				if (!config.xAxis) config.xAxis = {};
				if (!config.xAxis.labels) config.xAxis.labels = {};
				config.xAxis.labels.formatter = function (){ return $filter('year')(this.value,2); };

				if (!config.yAxis) config.yAxis = {};
				if (!config.yAxis.labels) config.yAxis.labels = {};
				config.yAxis.labels.formatter = function (){ return $filter('currency')(this.value,0); };

				return config;
			})();
		}

		function updateAvailability(startIndex, validate){
			var i=startIndex || 0,
				len=me.pageOrder.length,
				sections = me.sections;
			for (;i<len;i++){
				sections[me.pageOrder[i]].updateAvailability();
				if (validate===true) {
					sections[me.pageOrder[i]].validate();
				}
			}
		}

		function getProgressPercent (){
			return (me.currentSection.id)/(me.pageOrder.length-1);
		}

		function adjustStopAksingState(){
			me.data.stopAsking = me.data.isReg==='reg' && (me.data.accountType==='resp'||me.data.accountType==='rdsp'||me.data.accountType===undefined);
		}

		function toggleGraphEvent (event) {
			var scenarios = me.results.scenarios,i=0,len = scenarios.length;
			for(;i<len;i++) {
				if (scenarios[i].graphID===event.target._i) {
					me.results.graphVisibility[i] = event.type === 'show';
				}
			}
			forceDigest();
		}

		function forceDigest () {
			if (!$scope.$$phase) $scope.$apply();
		}

		function updateHighchart(){
			var config = angular.extend({},me.results.highchart.config),
				results = me.results,
				highestTerm=0,
				series = [],
				graphVisibility = [],
				scenarios = me.results.scenarios,
				i=0,
				len = scenarios.length,
				hide = true;

			// Reset graph visibility
			results.graphVisibility = [];

			// Hide chart when the only scenarios available has nothing to show on chart
			for(;i<len;i++) {
				if (scenarios[i].hasChart){
					if (hide) {
						graphVisibility[i] = true;
						hide = false;
					}
					else {
						graphVisibility[i] = false;
					}

					scenarios[i].graphID = series.length;
					scenarios[i].series[0].visible = graphVisibility[i];
					series = series.concat(scenarios[i].series);
					highestTerm = scenarios[i].term>highestTerm?scenarios[i].term:highestTerm;
				}
			}

			results.hideChart = hide;

			config.series = series;

			if (highestTerm<=1) {
				config.xAxis.tickInterval = 0.25;
			}
			else if (highestTerm>1&&highestTerm<=3) {
				config.xAxis.tickInterval = 0.5;
			}
			else {
				config.xAxis.tickInterval = 1;
			}

			me.results.highchart.config = config;
			// new graph visibility
			me.results.graphVisibility = graphVisibility;
		}

		function updateHighchartVisibility () {
			var scenarios = me.results.scenarios || [],
				len = scenarios.length,
				i = 0,
				graphVisibility = me.results.graphVisibility,
				chart = me.results.highchart.element,
				series = chart.series;

			if (series) {
				for(;i<len;i++){
					if (scenarios[i].hasChart===true) {
						series[scenarios[i].graphID][graphVisibility[i]?'show':'hide']();
					}
				}
			}
		}

		function updateProgress(){
			var data = angular.extend({},me.data),
				sections = me.sections,
				po = me.pageOrder,
				len = po.length,
				curr = me.currentSection.id,
				i = curr,
				maxAllowed = curr,
				maxProgress = me.maxProgress || curr;

			maxProgress = curr>maxProgress ? curr : maxProgress;

			for (;i<=maxProgress;i++){
				if (sections[po[i]].isAvailable){
					maxAllowed = i;
				}
			}
			
			// If determined maxAllowed is smaller than previously set maxProgress...
			if (maxAllowed<maxProgress) {
				if (!sections[po[maxAllowed]].isValid) {
					maxAllowed = getPreviousSectionId(maxAllowed);
				}
			}

			me.maxProgress = maxAllowed;
			me.data = data;
			if (me.currentSection.id === len-1) calculate(data);
		}

		function updateCurrentSection (id) {
			me.currentSection = {id:id,name:me.pageOrder[id]};
			me.sections[me.currentSection.name].visited = true;
			me.progressPercent = getProgressPercent();
		}

		function getSectionId (name) {
			var i=0,
				po = me.pageOrder,
				len=po.length;
			for (;i<len;i++) {
				if (po[i]===name) {
					return i;
				}
			}
			return me.currentSection.id;
		}

		function getNextSectionId (id) {
			var i=id+1,
				po = me.pageOrder,
				len=po.length,
				sectionId;
			for (;i<len;i++) {
				sectionId = po[i];
				if (me.sections[sectionId].isAvailable) {
					return i;
				}
			}
			return id;
		}

		function getPreviousSectionId (id) {
			var i=id-1,
				po = me.pageOrder,
				sectionId;
			for (;i>=0;i--) {
				sectionId = po[i];
				if (me.sections[sectionId].isAvailable) {
					return i;
				}
			}
			return id;
		}

		function calculate (data) {
			var results = me.results;

			if (me.currentSection.id === me.pageOrder.length-1) {
				results.currentScenarioId = 0;
				createScenarios(results,data);
				updateHighchart();
			}
		}

		function createScenarios (results,data) {
			var products = getRecommendedProducts(data),
				len = products.length,
				scenarios = [],
				product,
				sc,
				i = 0,
				nbSeries,
				getTerm = function(product) {
					var term = product.term || 0;

					if (!term) {
						if (!me.sections.term.isAvailable) {
							// default term when Member can't set a term himself and when there is no term specified in product
							term = 5;
						}
						else if (me.sections.accessTerm.isAvailable) {
							term = me.data.accessTerm;
						}
						else {
							// Default to using specified member term lenght, at least one year
							term = me.data.term || 1;
						}
					}
					return term;
				};

			/* Each product get their own scenario */
			for (;i<len;i++){
				product = products[i];
				sc = {
					amount:data.amount,
					color:results.highchart.config.colors[i],
					product:product,
					term:getTerm(product)
				};

				sc.series = createSeries(sc,i);

				nbSeries = sc.series.length;
				
				if (nbSeries) {
					sc.balanceMin = sc.series[0].data[sc.series[0].data.length-1][1];
					sc.balanceMax = sc.series[nbSeries-1].data[sc.series[nbSeries-1].data.length-1][2] || sc.balanceMin;
					// Link show and hide events from graph to graphVisibility model
					sc.series[0].events = {
						show:toggleGraphEvent,
						hide:toggleGraphEvent
					};

				}

				sc.yield = sc.product.MinRate!==undefined?sc.product.MinRate:sc.product.RateNumber;

				sc.display = createScenarioDisplay(sc);
				sc.hasChart = nbSeries!==0;

				scenarios.push(sc);
			}

			// results.scenarios = scenarios.sort(function(s1,s2){return s2.balanceMin-s1.balanceMin;});
			results.scenarios = scenarios.sort(function(s1,s2){return s2.yield-s1.yield;});
		}

		function createScenarioDisplay (sc) {
			var dsScenario = {},
				p = sc.product;

			dsScenario.title = p.label;

			// Update rate text to show in definition
			if (p.MinRate!==undefined&&p.MaxRate!==undefined) {
				if (p.MaxRate!==VALUE_UNLIMITED) {
					dsScenario.rate = $filter('percent')(p.MinRate,2) +' - '+ $filter('percent')(p.MaxRate,2);
				}
				else {
					dsScenario.rate = $filter('percent')(p.MinRate,2) +' - '+ VALUE_UNLIMITED;
				}
			}
			else if (p.RateNumber) {
				dsScenario.rate = $filter('percent')(p.RateNumber,2);
			}

			dsScenario.investment = $filter('currency')(sc.amount,2);
			dsScenario.term = $filter('moreThanAYear')(sc.term,0,-1);

			// Update balance text to show in definition
			if (sc.balanceMin===sc.balanceMax) {
				dsScenario.balance = dsScenario.rate && $filter('currency')(sc.balanceMin,2) || undefined;
			}
			else if (p.MaxRate!==VALUE_UNLIMITED) {
				dsScenario.balance = $filter('currency')(sc.balanceMin,2) + ' - ' + $filter('currency')(sc.balanceMax,2);
			}

			dsScenario.url = p.productLink;
			dsScenario.note = p.note;

			return dsScenario;
		}

		function createSeries (scenario) {
			var serie = [],
				product = scenario && scenario.product || {},
				amount = scenario && scenario.amount || 0,
				term = scenario.term,
				baseSerie = {
					name:'',
					data:[]
				},

				data = [],
				range = [],

				rate = product.RateNumber,
				rateMin = product.MinRate,
				rateMax = product.MaxRate,

				hasRange = rateMin!==undefined&&rateMax!==undefined,
				isValidSerie = ((hasRange&&rateMax!==VALUE_UNLIMITED) || (!hasRange&&rate!==0)) && amount && term,

				i=0;

			baseSerie.name = product.label;

			if (!isValidSerie) return serie;
			
			// Calculate series...
				
			for(;i<=Math.ceil(term);i++){
				if (i>term&&term%1!==0) {
					// Last position in data will not match 1 year increments
					i = term;
				}

				if (hasRange) {
					amountMin = range[Math.ceil(i)-1]&&range[Math.ceil(i)-1][1] || amount;
					amountMax = range[Math.ceil(i)-1]&&range[Math.ceil(i)-1][2] || amount;

					range.push([i,(amountMin+(i!==0?amountMin*rateMin:0)),(amountMax+(i!==0?amountMax*rateMax:0))]);
				}

				amount = data[Math.ceil(i)-1] && data[Math.ceil(i)-1][1]*(1+rate) || amount;
				data.push([i,amount]);
			}

			// Set highchart graph info...
			baseSerie.data = data;
			baseSerie.color = scenario.color;
			baseSerie.marker = {lineColor:scenario.color,lineWidth:3};
			// Set additionnal graph info for a range graph (MinRate and MaxRate are available in product rates)
			if (hasRange) {
				baseSerie = angular.merge({},baseSerie,{
					name:baseSerie.name+me.content.chart.rangeSuffix,
					data:range,
					color:scenario.color,
					fillOpacity:0.3,
					lineWidth:0,
					type:'arearange'
				});
			}
			serie.push(baseSerie);

			return serie;
		}

		// Call once - fetch rates from database
		function updateIstRates () {
			var ratesMapping={},
				indexLinkedMaxs={
					updateList:[]
				},
				i=0,
				rates,product,id,nameId,title,group,ctaurl,currIndexLinkedBase;

			// fetch associated rates from mapping
			if (window.Rates && Rates.getAll) {
				rates = Rates.getAll();

				for (;i<rates.length;i++) {
					id = rates[i].ID;
					ratesMapping[id]=rates[i];
				}

			}


			
			// Replace dummy rates with rates found
			for (nameId in calcConfig.istRates) {
				product = calcConfig.istRates[nameId];

				id = product.ID;
				if (ratesMapping[id]!==undefined) {

					product.enabled = true;

					$.extend(product,ratesMapping[id]);

					// Set Rates as number
					if (product.MaxRate!==undefined && product.MinRate!==undefined) {
						product.MinRate = stringToNumber(product.MinRate)/100;
						currIndexLinkedBase = nameId.split('_')[0];
						
						if (String(product.MaxRate).toLowerCase()===VALUE_UNLIMITED) {
							indexLinkedMaxs.updateList.push(nameId);
						}
						else {
							product.MaxRate = stringToNumber(product.MaxRate)/100;

							if (!indexLinkedMaxs[currIndexLinkedBase] || indexLinkedMaxs[currIndexLinkedBase]&&indexLinkedMaxs[currIndexLinkedBase]<product.MaxRate) {
								indexLinkedMaxs[currIndexLinkedBase] = product.MaxRate;
							}
						}
					}

					product.RateNumber = product.RateNumber/100;

					// Set TERM
					title = product.Title && String(product.Title).toLowerCase() || '';
					group = product.Group && String(product.Group).toLowerCase() || '';

					if (title.indexOf('year')!==-1) {
						product.term = stringToNumber(title.substr(0,title.indexOf('year')));
					}
					else if (title.indexOf('days')!==-1) {
						product.term = stringToNumber(title.substr(0,title.indexOf('days')))/365;
					}
					else if (group.indexOf('year')!==-1) {
						product.term = stringToNumber(group.substr(0,group.indexOf('year')));
					}
					else if (group.indexOf('days')!==-1) {
						product.term = stringToNumber(group.substr(0,group.indexOf('days')))/365;
					}
					// No TERM, will default to term selected by Member
					else {
						product.term = calcConfig.istRatesDefault.term;
					}

					// Set CTAs
					product.CTAURL = product.CTAURL || calcConfig.istRatesDefault.CTAURL;
					ctaurl = product.CTAURL;
					if (ctaurl.indexOf('find-us')!==-1) {
						product.ctaLabel = 'Contact Us';
					}
					else if (ctaurl.indexOf('GetStarted')!==-1) {
						product.ctaLabel = 'Open Now';
					}
					else {
						product.ctaLabel = calcConfig.istRatesDefault.ctaLabel;
					}

					product.label = product.CalculatorProductName || product.Title;
					calcConfig.istRates[nameId] = product;
				}
				else {
					product.enabled = false;
				}
			}

			// Replace VALUE_UNLIMITED with highest available value
			if (indexLinkedMaxs.updateList.length) {
				do {
					nameId = indexLinkedMaxs.updateList.shift();
					currIndexLinkedBase = nameId.split('_')[0];
					calcConfig.istRates[nameId].MaxRate = indexLinkedMaxs[currIndexLinkedBase];
				} while (indexLinkedMaxs.updateList.length);
			}
			
		}

		function getIndexLinkedGICList (id) {
			var allIndexLinked = calcConfig.istProductsPriorityList
					.filter(function(value){
						return value.indexOf(id)!==-1;
					});
			return getProductsFromData(allIndexLinked);
		}

		function getProductsFromData (requestObj) {

			requestObj = typeof requestObj === 'string' ? [requestObj] : requestObj ;
			requestObj = requestObj.filter(onlyUnique);
			var i=0,
				rLen = requestObj.length,
				products=[],
				linkedProducts=[],
				p;

			for (;i<rLen;i++){
				if (requestObj[i].indexOf('indexLinkedGIC')!==-1 && requestObj[i].indexOf('_')===-1) {
					linkedProducts = getIndexLinkedGICList(requestObj[i]);
				}
				else {
					p = calcConfig.istRates[requestObj[i]];
					if (p.enabled) products.push(p);
				}
			}

			products.sort(function(b,a){
				return (a.RateNumber||(a.MaxRate&&(a.MaxRate!==VALUE_UNLIMITED||0))||0)-(b.RateNumber||(b.MaxRate&&(b.MaxRate!==VALUE_UNLIMITED||0))||0);
			});
			return linkedProducts.concat(products);
		}

		function getRecommendedProducts (data) {
			var products = [],
				baseGroup1 = ['advantageSavings','gtgHisa'],
				baseGroup2 = [],
				index,

				isReg = data.isReg==='reg',

				accountType = data.accountType,
				isResp = accountType==='resp',
				isTfsa = accountType==='tfsa',
				isRrif = accountType==='rrif',
				isRrsp = accountType==='rrsp',
				isRdsp = accountType==='rdsp',
				isRegOther = isTfsa || isRrsp || isRrif, // those reg scenarios don't have the "stopAsking" effect

				term = data.term,

				earlyAccess = data.earlyAccess,
				accessBeforeTerm = 'true',
				accessAtTerm = 'false',
				mayAccessBeforeTerm = 'maybe',

				returnType = data.returnType,
				isVariableGuaranteed = returnType === 'variableGuaranteed',
				isFlexible = returnType === 'flexible',
				isGuaranteed = returnType === 'guaranteed',
				isVariable = returnType === 'variable',

				accessTerm = data.accessTerm,
				amount = data.amount,

				mutualFundsMin = 10000;

			if ( isReg ) {
				// Cover the basics...
				if (isResp) {
					products.push('respSavings');
					if (amount >= mutualFundsMin) {
						products.push('mutualFunds');
					}
				}
				else if (isRdsp) {
					products.push('mutualFunds');
				}
			}

			if ( !isReg || isRegOther ) {
				// Cover the basics...
				baseGroup2 = baseGroup1.concat(['redeemableShortTermGICs']);				

				if (earlyAccess===accessBeforeTerm || term===0) {
					if (term<=3 || accessTerm===1) {
						products = products.concat(baseGroup2);
					}
					else if (term>3) {
						products = products.concat(baseGroup1);
					}
				}
				else if (earlyAccess===mayAccessBeforeTerm) {
					if (term<=3) {
						products = products.concat(baseGroup1);
					}
				}
				else if (earlyAccess===accessAtTerm) {
					if ( (term<=3 && isVariableGuaranteed) || isFlexible || (term<3 && isGuaranteed)) {
						products = products.concat(baseGroup1);
					}
				}

				// Indexed && non-redeemable
				// Escalator
				if (term!==0) {
					if (earlyAccess === accessAtTerm) {
						//Index/non-redeemable
						if (isVariableGuaranteed || isVariable) {
							index = term===5?5:term>=3?3:1;
							products.push('indexLinkedGIC'+index+'yr');
						}
						else if (isGuaranteed) {
							index = term;
							products.push('nonRedeemableLongTermGIC'+index+'yr');
						}

						//Escalator
						if (term>1) {
							if (isGuaranteed || isFlexible || (isVariableGuaranteed&&term===5)) {
								index = term===5?5:3;
								// MAY 12 feedback
								if (term!==2) {
									products.push('escalatorGIC'+index+'yr');
								}
							}
						}

						// Ladder
						if (term===5) {
							if (isGuaranteed || isFlexible) {
								products.push('ladderGIC5yr');
							}
							else if (isVariable && amount >= mutualFundsMin) {
								products.push('mutualFunds');
							}
						}
						// Mutual funds
						else if (term>=3 && isVariable && amount >= mutualFundsMin) {
							products.push('mutualFunds');
						}
					}
					else if(earlyAccess === accessBeforeTerm && term>3) {
						//Index/non-redeemable
						index = accessTerm===5?5:accessTerm>=3?3:1;
						products.push('indexLinkedGIC'+index+'yr');
						index = accessTerm;
						products.push('nonRedeemableLongTermGIC'+index+'yr');

						//Escalator
						if (accessTerm===5 && isReg) {
								products.push('escalatorGIC5yr');
						}
						else if (accessTerm>2) {
							products.push('escalatorGIC3yr');
						}
					}
					else if (earlyAccess===mayAccessBeforeTerm) {
						// Escalator
						index = term===5?5:term===1?1:3;
						if (index===1) {
							products.push('redeemableShortTermGICs');
						}
						else if (term>2&&(index===5&&isReg||index!==5)) {
							products.push('escalatorGIC'+index+'yr');
						}

						if (term>3) {
							// Mutual funds
							if (term>=4 && amount>=mutualFundsMin) {
								products.push('mutualFunds');
							}
							if (term===5) {
								products.push('ladderGIC5yr');
							}
						}						
					}
				}		

				if (isRegOther) {
					products = products.filter(function(value){return value !== 'redeemableShortTermGICs';}); // remove redeemableShortTermGICs
				}
				// Remove all escalatorGIC5yr product recommendation if nonreg
				if (!isReg) {
					products = products.filter(function(value){return value !== 'escalatorGIC5yr';});
				}
			}
			if (isReg) {
				products = getAccountSpecificProduct(products,accountType);
			}

			products = getProductsFromData(products);

			return products;
		}

		function getAccountSpecificProduct (products,accountType) {
			products = products || [];
			accountType = accountType && accountType.toUpperCase() || '';

			var i = 0,
				len = products.length,
				n;

			if (products && products.length) {
				for (;i<len;i++) {
					n = products[i]+'_'+accountType;
					if (calcConfig.istRates[n]) {
						products[i] = n;
					}
				}
			}

			return products;
		}

		function getSectionsValidation () {
			// Generic validation functions
			var defaultValidation = {
					isAvailable:false,
					isValid:false,
					updateAvailability:function(){ this.isAvailable = true; },
					validate:function(){ this.isValid = true; }
				},
				// Make sure all sections have their validate & isAvailable method
				v = (function(){
					var i=0,
						po = me.pageOrder,
						len=po.length,
						dValid={};
					for (;i<len;i++){
						dValid[po[i]]=defaultValidation;
					}
					return dValid;
				})();

			return angular.merge({},v,{
				isReg:{
					validate:function(){this.isValid = me.data.isReg!==undefined;}
				},
				accountType:{
					updateAvailability:function(){this.isAvailable = me.data.isReg==='reg';},
					validate:function(){this.isValid = me.data.accountType!==undefined;}
				},
				amount:{
					updateAvailability:function(){this.isAvailable = (me.sections.accountType.isAvailable&&me.data.accountType!==undefined) || me.data.isReg==='nonreg';},
					validate:function(){this.isValid = me.data.amount!==undefined;}
				},
				term:{
					updateAvailability:function(){this.isAvailable = !me.data.stopAsking && me.sections.amount.visited && me.sections.amount.isValid && ((me.data.isReg==='nonreg'&&me.data.amount!==undefined) || me.data.accountType!==undefined);},
					validate:function(){this.isValid = me.data.term!==undefined;}
				},
				earlyAccess:{
					updateAvailability:function(){this.isAvailable = !me.data.stopAsking && (me.data.term!==0 && me.sections.term.visited && me.sections.term.isValid);},
					validate:function(){this.isValid = me.data.earlyAccess!==undefined;}
				},
				accessTerm:{
					updateAvailability:function(){
						var available = !me.data.stopAsking && (me.sections.earlyAccess.isAvailable && me.data.earlyAccess==='true' && me.data.term>=4),
							callback = function(){
								// Method only used when the answers shown varies depending on scenario
								var choices = me.content.pages.accessTerm.inputs,
									aGroup = me.data.term===4?1:2,
									answers = {
										1:[1,2,3],
										2:[1,2,3,4,5]
									},
									availableAnswers = answers[aGroup],
									i=0,len=choices.length,j=0,lenA=availableAnswers.length,
									result=[];
								choicesLoop: {
									for (;i<len;i++) {
										j=0;
										for (;j<lenA;j++) {
											if (choices[i].value===availableAnswers[j]){
												result.push(choices[i]);
												if (result.length===lenA) break choicesLoop;
											}
										}
									}
								}

								me.sections.accessTerm.inputs = result;
							};
						if (available) callback();
						this.isAvailable = available;
					},
					validate:function(){this.isValid = me.data.accessTerm!==undefined;}
				},
				returnType:{
					updateAvailability:function(){
						var available = !me.data.stopAsking && me.data.term && me.data.earlyAccess === 'false',
							callback = function(){
								// Method only used when the answers shown varies depending on scenario
								var choices = me.content.pages.returnType.inputs,
									term = me.data.term && me.data.term >= 3 ? 3 : me.data.term,
									answers = {
										1:['guaranteed','variableGuaranteed'],
										2:['guaranteed','variableGuaranteed','flexible'],
										3:['guaranteed','variableGuaranteed','flexible','variable']
									},
									availableAnswers = answers[term],
									i=0,len=choices.length,j=0,lenA=availableAnswers.length,
									result=[];
								choicesLoop: {
									for (;i<len;i++) {
										j=0;
										for (;j<lenA;j++) {
											if (choices[i].value===availableAnswers[j]){
												result.push(choices[i]);
												if (result.length===lenA) break choicesLoop;
											}
										}
									}
								}

								me.sections.returnType.inputs = result;
							};
						if (available) callback();
						this.isAvailable = available;
					},
					validate:function(){this.isValid = me.data.returnType!==undefined;}
				},
				results:{
					updateAvailability:function(){ 
						// Accessing result different paths
						var sections = me.sections,
							data = me.data,

							stopAsking = data.stopAsking,

							done_amount = sections.amount.visited && sections.amount.isValid,
							done_term = sections.term.visited && sections.term.isValid,
							done_earlyAccess = !stopAsking && sections.earlyAccess.isAvailable && sections.earlyAccess.isValid,
							done_accessTerm = sections.accessTerm.isAvailable && sections.accessTerm.visited,
							done_returnType = sections.returnType.isAvailable && sections.returnType.isValid,

							isScenario1 = stopAsking && sections.accountType.isValid && done_amount,
							isScenario2 = !stopAsking && done_term && data.term===0,
							isScenario3 = !sections.accessTerm.isAvailable && done_earlyAccess && data.earlyAccess!='false',
							isScenario4 = done_term && data.term!==0 && done_returnType,
							isScenario5 = done_accessTerm;

						// console.log(isScenario1 , isScenario2 , isScenario3 , isScenario4 , isScenario5);
						this.isAvailable = isScenario1 || isScenario2 || isScenario3 || isScenario4 || isScenario5;
					}
				}
			});
		}
	});
})($cmsj,$cmsj);