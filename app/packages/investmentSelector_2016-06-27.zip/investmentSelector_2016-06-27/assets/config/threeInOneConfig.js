window.threeInOnePageOrder = [];
window.defaultThreeInOneConfig = {
	en: {

		affordability:{
			formHeader:'How much can<br/> you afford?',

			scenarioInputs:{
				income:{
					header:'Annual Income',
					inputs:{
						annualIncome:{
							label:'Your Gross Annual Household Income',
							model:'meridianDataConfig.input.currency2'
						}
					}
				},
				expenses:{
					header:'Monthly Expenses',
					inputs:{
						heatingCosts:{
							label:'Heating Costs',
							model:'meridianDataConfig.input.currency2'
						},
						propertyTaxes:{
							label:'Property Taxes',
							model:'meridianDataConfig.input.currency2'
						},
						condoFees:{
							label:'Condo Fees (if applicable)',
							model:'meridianDataConfig.input.currency2'
						},
						totalOtherDebt:{
							label:'Total Other Debt',
							model:'meridianDataConfig.input.currency2',
							expandableID:'otherDebts',
							inputs:{
								vehicleLoanLease:{
									label:'Vehicle Loan/Lease',
									model:'meridianDataConfig.input.currency2'
								},
								personalLoan:{
									label:'Personal Loan',
									model:'meridianDataConfig.input.currency2'
								},
								lineOfCredit:{
									label:'Line of Credit',
									model:'meridianDataConfig.input.currency2'
								},
								creditCards:{
									label:'Credit Card(s)',
									model:'meridianDataConfig.input.currency2'
								},
								other:{
									label:'Other Debt',
									model:'meridianDataConfig.input.currency2'
								}
							}
						}					
					}
				},
				mortgageInformation:{
					header:'Mortgage Information',
					inputs:{
						interestRate:{
							model:'meridianDataConfig.input.interestRate'
						},
						amortization:{
							model:'meridianDataConfig.input.amortization'
						},
						downPaymentAmount:{
							label:'Down Payment Amount',
							model:'meridianDataConfig.input.currency2'
						}
					}
				}
			},

			scenarioResults: {
				header:'Based on the information provided we estimate you qualify for a home with value of',
				subtitle:'Based on your selections, here is your unique mortgage Affordability Assesment',
				maximumPurchasePrice:'Maximum Purchase Price',
				downPaymentPercent:'Down Payment Percentage',
				downPaymentAmount:'Down Payment Amount',
				principalMortgageAmount:'Principal Mortgage Amount',
				defaultInsurance:'Default Insurance',
				totalMortgageAmount:'Total Mortgage Amount',
				chartLegend:{

				}
			},

			disclaimer:'<p>The monthly affordability calculation is for illustration purposes only and should not be relied upon as financial advice without additional input from  a trusted and competent financial advisor.    Results are based on the information you provide and the calculator  assumes that the annual interest rate will never vary  over the Mortgage Amortization Period. The actual rate will likely vary over the course of the amortization period and such fluctuations will  affect the overall affordability calculation. The eligible mortgage amount and monthly mortgage payment amount factors in property taxes, default insurance, heating costs, common expenses. Applicants must meet Meridian\'s qualifying criteria.</p>',

			'affGraphMortgagePayment':{
				label:'Mortgage payment'
			},
			'affGraphHeat':{
				label:'Heat'
			},
			'affGraphPropertyTaxes':{
				label:'Property Taxes'
			},
			'affGraphCondoFees':{
				label:'Condo Fees'
			},
			'affGraphTotalOtherDebt':{
				label:'Total Other Debt'
			}
		},

		mortgagePayment:{
			formHeader:'How much will I pay?',

			additionalPaymentButton_hide:'HIDE ADDITIONAL PAYMENTS',
			additionalPaymentButton_show:'BE MORTGAGE-FREE SOONER WITH ADDITIONAL PAYMENTS',

			scenarioInputs:{
				mortgageAmount:{
					label:'Mortgage Amount',
					model:'meridianDataConfig.input.currency2'
				},
				productAndType:{
					model:'meridianDataConfig.select.productAndType'
				},
				amortization:{
					model:'meridianDataConfig.input.amortization'
				},
				interestRate:{
					model:'meridianDataConfig.input.interestRate'
				},
				paymentFrequency:{
					model:'meridianDataConfig.select.paymentFrequency'
				},
				extraPaymentFrequency:{
					model:'meridianDataConfig.select.extraPaymentFrequency'
				},
				extraPaymentAmount:{
					label:'Prepayment Amount',
					model:'meridianDataConfig.input.currency2'
				}

			},
			results:{
				header:'Your monthly mortgage payment will be',
				tabs:{
					amortization:{
						content:{
							tabLabel:'Amortization',
							detailsTableColumns:['Year','Payment','Interest','Principal','Balance']
						}
					},
					termSummary:'Mortgage Term Summary'
				}
			},
			report:{
				mortgageOptions:'Mortgage Options',

				mortgageAmount:'Mortgage Amount',
				productAndType:'Term',
				amortization:'Amortization',
				interestRate:'Interest Rate',
				paymentFrequency:'Payment Frequency',
				extraPaymentFrequency:'Extra Payment Frequency',
				extraPaymentAmount:'Extra Payment Amount',

				termSummary:'Term Summary',

				mortgagePayment:'Mortgage Payment',
				termPrincipal:'Principal Paid for Term',
				termInterest:'Interest Paid for Term',
				termInterestAndPrincipal:'Interest and Principal for Term',
				balanceAtEndOfTerm:'Balance at End of Term',

				amortizationSchedule:'Amortization Schedule'
			},
			compareScenarios:{
				scenario_0:{
					name:'Base Scenario',
					color:'#e68922'
				},
				scenario_1:{
					name:'Scenario A',
					color:'#50324c'
				},
				scenario_2:{
					name:'Scenario B',
					color:'#a9b400'
				}
			},
			disclaimer:'<p>The loan payment calculation is for illustrative purposes only and should not be relied upon as financial advice without additional input from a trusted and competent financial advisor. The  Interest rate  is an annual rate charged daily and paid according to the payment frequency selected. The calculator assumes that the interest rate will remain constant over the entire amortization/repayment period, but the  actual interest rate may vary, and is likely to vary, over the amortization period. Applicants must meet Meridian\'s qualifying criteria.</p>'
		},
		lineOfCredit:{

			scenarioInputs:{
				repaymentDetails:{
					label:'View repayment details for a',
					options:[
						{label:'Personal loan',value:'personalLoan'},
						{label:'Line of credit',value:'lineOfCredit'}
					]
				},
				borrowReason:{
					label:'What are you borrowing for?',
					options:[
						{label:'Buying a car',value:'car'},
						{label:'Consolidating debt',value:'debtConsolidation'},
						{label:'Renovating my home',value:'homeRenovation'},
						{label:'Paying for Tuition',value:'educationFees'},
						{label:'Contributing to my RRSP',value:'rrspContribution'},
						{label:'(Other reasons)',value:'other'}
					],
					defaultOption:{label:'Select',value:''}
				},
				borrowAmount:{
					label:'How much do you want to borrow?',
					model:'meridianDataConfig.input.currency2'
				},
				interestRate:{
					label:'Interest rate (as low as*):',
					model:'meridianDataConfig.input.interestRate'
				},
				amortization:{
					label:'Over how many years do you want to pay it back? (Amortization)',
					model:'meridianDataConfig.input.amortization'
				},
				reducedPaymentFrequency:{
					label:'Payment frequency?',
					model:'meridianDataConfig.select.reducedPaymentFrequency'
				}
			},

			results:{
				header:'Based on your responses we\'ve determined the following',
				monthlyPayment:'Monthly payment amount',
				interestCost:'Interest cost for item',
				compareScenarios:{
					monthlyPayment:'Monthly payment amount:',
					interestCost:'Interest cost for item:'
				}
			},

			report:{
				borrowOptions:'Borrowing options',
				paymentSummary:'Payment Summary',
				borrowReason:'Borrow Reason',
				borrowAmount:'Amount to Borrow',
				interestRate:'Interest Rate',
				amortization:'Term',
				paymentFrequency:'Payment Frequency'
			},

			scenarioTypes:{
				lineOfCredit:{
					formHeader:'Estimate your line of<br/> credit payments',
					name:'Line of Credit'
				},
				personalLoan:{
					formHeader:'Estimate your personal loan payments',
					name:'Personal Loan'
				}
			},

			disclaimer:'<p>The minimum monthly payment calculation is based on the information you provide and is for illustrative purposes only. It should not be relied upon as financial advice without additional input from a trusted and competent financial advisor. Actual results may vary. The calculator assumes a constant rate of interest, but the rate for line of credit products often varies over time.</p>'
		}
	}
};

// window.threeInOneDataContent = {
window.threeInOneDataContent = {
	
	affordability:{
		en: {
			formHeader:'How much can<br/> you afford?',

			scenarioInputs:{
				income:{
					header:'Annual Income',
					inputs:{
						annualIncome:{
							label:'Your Gross Annual Household Income',
							configModel:'input.currency2'
						}
					}
				},
				expenses:{
					header:'Monthly Expenses',
					inputs:{
						heatingCosts:{
							label:'Heating Costs',
							configModel:'input.currency2'
						},
						propertyTaxes:{
							label:'Property Taxes',
							configModel:'input.currency2'
						},
						condoFees:{
							label:'Condo Fees (if applicable)',
							configModel:'input.currency2'
						},
						totalOtherDebt:{
							label:'Total Other Debt',
							configModel:'input.currency2',
							expandableID:'otherDebts',
							inputs:{
								vehicleLoanLease:{
									label:'Vehicle Loan/Lease',
									configModel:'input.currency2'
								},
								personalLoan:{
									label:'Personal Loan',
									configModel:'input.currency2'
								},
								lineOfCredit:{
									label:'Line of Credit',
									configModel:'input.currency2'
								},
								creditCards:{
									label:'Credit Card(s)',
									configModel:'input.currency2'
								},
								other:{
									label:'Other Debt',
									configModel:'input.currency2'
								}
							}
						}					
					}
				},
				mortgageInformation:{
					header:'Mortgage Information',
					inputs:{
						interestRate:{
							configModel:'input.interestRate'
						},
						amortization:{
							configModel:'input.amortization'
						},
						downPaymentAmount:{
							label:'Down Payment Amount',
							configModel:'input.currency2'
						}
					}
				}
			},

			scenarioResults: {
				header:'Based on the information provided we estimate you qualify for a home with value of',
				subtitle:'Based on your selections, here is your unique mortgage Affordability Assesment',
				maximumPurchasePrice:'Maximum Purchase Price',
				downPaymentPercent:'Down Payment Percentage',
				downPaymentAmount:'Down Payment Amount',
				principalMortgageAmount:'Principal Mortgage Amount',
				defaultInsurance:'Default Insurance',
				totalMortgageAmount:'Total Mortgage Amount',
				chartLegend:{

				}
			},

			disclaimer:'<p>The monthly affordability calculation is for illustration purposes only and should not be relied upon as financial advice without additional input from  a trusted and competent financial advisor.    Results are based on the information you provide and the calculator  assumes that the annual interest rate will never vary  over the Mortgage Amortization Period. The actual rate will likely vary over the course of the amortization period and such fluctuations will  affect the overall affordability calculation. The eligible mortgage amount and monthly mortgage payment amount factors in property taxes, default insurance, heating costs, common expenses. Applicants must meet Meridian\'s qualifying criteria.</p>',

			'affGraphMortgagePayment':{
				label:'Mortgage payment'
			},
			'affGraphHeat':{
				label:'Heat'
			},
			'affGraphPropertyTaxes':{
				label:'Property Taxes'
			},
			'affGraphCondoFees':{
				label:'Condo Fees'
			},
			'affGraphTotalOtherDebt':{
				label:'Total Other Debt'
			}
		}
	},


	mortgagePayment:{
		en:{
			formHeader:'How much will I pay?',

			additionalPaymentButton_hide:'HIDE ADDITIONAL PAYMENTS',
			additionalPaymentButton_show:'BE MORTGAGE-FREE SOONER WITH ADDITIONAL PAYMENTS',

			scenarioInputs:{
				mortgageAmount:{
					label:'Mortgage Amount',
					configModel:'input.currency2'
				},
				productAndType:{
					label:'Mortgage Amount',
					configModel:'select.productAndType'
				},
				amortization:{
					configModel:'input.amortization'
				},
				interestRate:{
					configModel:'input.interestRate'
				},
				paymentFrequency:{
					configModel:'select.paymentFrequency'
				},
				extraPaymentFrequency:{
					contentModel:'label:select.paymentFrequency.extraPaymentFrequency',
					configModel:'select.extraPaymentFrequency'
				},
				extraPaymentAmount:{
					label:'Prepayment Amount',
					configModel:'input.currency2'
				}

			},
			results:{
				header:'Your monthly mortgage payment will be',
				tabs:{
					amortization:{
						content:{
							tabLabel:'Amortization',
							detailsTableColumns:['Year','Payment','Interest','Principal','Balance']
						}
					},
					termSummary:'Mortgage Term Summary'
				}
			},
			report:{
				mortgageOptions:'Mortgage Options',

				mortgageAmount:'Mortgage Amount',
				productAndType:'Term',
				amortization:'Amortization',
				interestRate:'Interest Rate',
				paymentFrequency:'Payment Frequency',
				extraPaymentFrequency:'Extra Payment Frequency',
				extraPaymentAmount:'Extra Payment Amount',

				termSummary:'Term Summary',

				mortgagePayment:'Mortgage Payment',
				termPrincipal:'Principal Paid for Term',
				termInterest:'Interest Paid for Term',
				termInterestAndPrincipal:'Interest and Principal for Term',
				balanceAtEndOfTerm:'Balance at End of Term',

				amortizationSchedule:'Amortization Schedule'
			},
			compareScenarios:{
				scenario_0:{
					name:'Base Scenario',
					color:'#e68922'
				},
				scenario_1:{
					name:'Scenario A',
					color:'#50324c'
				},
				scenario_2:{
					name:'Scenario B',
					color:'#a9b400'
				}
			},
			disclaimer:'<p>The loan payment calculation is for illustrative purposes only and should not be relied upon as financial advice without additional input from a trusted and competent financial advisor. The  Interest rate  is an annual rate charged daily and paid according to the payment frequency selected. The calculator assumes that the interest rate will remain constant over the entire amortization/repayment period, but the  actual interest rate may vary, and is likely to vary, over the amortization period. Applicants must meet Meridian\'s qualifying criteria.</p>'
		}
	},

	
	lineOfCredit:{
		en:{
			scenarioInputs:{
				repaymentDetails:{
					label:'View repayment details for a',
					options:[
						{label:'Personal loan',value:'personalLoan'},
						{label:'Line of credit',value:'lineOfCredit'}
					]
				},
				borrowReason:{
					label:'What are you borrowing for?',
					options:[
						{label:'Buying a car',value:'car'},
						{label:'Consolidating debt',value:'debtConsolidation'},
						{label:'Renovating my home',value:'homeRenovation'},
						{label:'Paying for Tuition',value:'educationFees'},
						{label:'Contributing to my RRSP',value:'rrspContribution'},
						{label:'(Other reasons)',value:'other'}
					],
					defaultOption:{label:'Select',value:''}
				},
				borrowAmount:{
					label:'How much do you want to borrow?',
					max:9999999.99,
					min:1,
					configModel:'input.currency2'
				},
				interestRate:{
					label:'Interest rate (as low as*):',
					max:0.3,
					min:0.0001,
					configModel:'input.interestRate'
				},
				amortization:{
					label:'Over how many years do you want to pay it back? (Amortization)',
					configModel:'input.amortization'
				},
				reducedPaymentFrequency:{
					label:'Payment frequency?',
					configModel:'select.reducedPaymentFrequency'
				}
			},

			results:{
				header:'Based on your responses we\'ve determined the following',
				monthlyPayment:'Monthly payment amount',
				interestCost:'Interest cost for item',
				compareScenarios:{
					monthlyPayment:'Monthly payment amount:',
					interestCost:'Interest cost for item:'
				}
			},

			report:{
				borrowOptions:'Borrowing options',
				paymentSummary:'Payment Summary',
				borrowReason:'Borrow Reason',
				borrowAmount:'Amount to Borrow',
				interestRate:'Interest Rate',
				amortization:'Term',
				paymentFrequency:'Payment Frequency'
			},

			scenarioTypes:{
				lineOfCredit:{
					formHeader:'Estimate your line of<br/> credit payments',
					name:'Line of Credit'
				},
				personalLoan:{
					formHeader:'Estimate your personal loan payments',
					name:'Personal Loan'
				}
			},

			disclaimer:'<p>The minimum monthly payment calculation is based on the information you provide and is for illustrative purposes only. It should not be relied upon as financial advice without additional input from a trusted and competent financial advisor. Actual results may vary. The calculator assumes a constant rate of interest, but the rate for line of credit products often varies over time.</p>'
		}
	}
};