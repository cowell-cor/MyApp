window.defaultRetirementSavingsConfig = {
	en: {
		formHeader:'Retirement planning',
		incomeSourceHeader:'Sources of Income',
		investmentsHeader:'RRSP Investments - Current',
		investmentsMonthlyHeader:'RRSP Investments - Monthly',

		errorMessages:{
			rrspContributionTooHigh:'Your annual RRSP contribution exceeds the maximum contribution allowed based on your income entered.'
		},

		scenarioInputs:{
			addSpouse:{
				label:'Would you like to add a spouse?',
				model:'meridianDataConfig.input.boolean'
			},
			isScenarioViewSpouse:{
				label:'Edit retirement information for:',
				options:[
					{label:'You',value:false},
					{label:'Spouse',value:true}
				],
				model:'meridianDataConfig.input.boolean'
			},
			// Retirement Information
			currentAge:{
				label:'Current age',
				model:'meridianDataConfig.input.year'
			},
			retirementStartAge:{
				label:'Retirement start age',
				model:'meridianDataConfig.input.year'
			},
			yearsInRetirement:{
				label:'Years in retirement',
				model:'meridianDataConfig.input.year'
			},
			annualIncome:{
				label:'Annual income',
				model:'meridianDataConfig.input.currency2'
			},
			targetIncomeIsPercent:{
				label:'Use a percentage of your annual income for your target retirement income?',
				model:'meridianDataConfig.input.boolean'
			},
			targetIncomeAmount:{
				label:'Target retirement income amount',
				model:'meridianDataConfig.input.currency2'
			},
			targetIncomePercent:{
				label:'Target retirement income percent',
				model:'meridianDataConfig.input.percent3'
			},
			// Sources of Income
			oas:{
				label:'Old Age Security',
				model:'meridianDataConfig.input.currency2'
			},
			cpp:{
				label:'CPP/QPP',
				model:'meridianDataConfig.input.currency2'
			},
			companyPension:{
				label:'Company pension',
				model:'meridianDataConfig.input.currency2'
			},
			nonRegInvestments:{
				label:'Non-registered investments',
				model:'meridianDataConfig.input.currency2'
			},
			otherIncome:{
				label:'Other sources of income',
				model:'meridianDataConfig.input.currency2'
			},
			// RRSP Investments
			currentRRSPSavings:{
				label:'RRSP savings',
				model:'meridianDataConfig.input.currency2'
			},
			monthlyRRSPcontribution:{
				label:'RRSP contribution',
				model:'meridianDataConfig.input.currency2'
			},
			currentTFSASavings:{
				label:'TFSA savings',
				model:'meridianDataConfig.input.currency2'
			},
			monthlyTFSAcontribution:{
				label:'TFSA contribution',
				model:'meridianDataConfig.input.currency2'
			},
			currentNONREGSavings:{
				label:'Non-registered savings',
				model:'meridianDataConfig.input.currency2'
			},
			monthlyNONREGcontribution:{
				label:'Non-registered contribution',
				model:'meridianDataConfig.input.currency2'
			},
			// OTHER
			estimatedROR:{
				label:'Estimated rate of return',
				model:'meridianDataConfig.input.percent3'
			},
			inflationRate:{
				label:'Inflation rate',
				model:'meridianDataConfig.input.percent3'
			}
		},

		spouseSuffix:'_spouse',

		results:{
			// header:'Based on your responses we\'ve determined the following',
			headerPart1:'You will need to save ',
			headerPart1_spouse:'Your spouse will need to save ',
			headerPart2:' for your retirement.',
			headerPart2_spouse:' for their retirement.',

			scenarioShortfallPart1:'To make up for your shortfall, you can contribute: ',
			scenarioShortfallPart1_spouse:'Your spouse can make up for the shortfall, by contributing: ',
			scenarioShortfallPart2:' monthly.',

			scenarioOnTrack:'Congratulations. You are on track to reach your retirement savings goal.',
			scenarioOnTrack_spouse:'Congratulations. Your spouse is on track to reach their retirement savings goal.'
		},

		chartTooltip:{
			age:'Age: '
		},

		report:{

		},

		disclaimer:''
	}
};
