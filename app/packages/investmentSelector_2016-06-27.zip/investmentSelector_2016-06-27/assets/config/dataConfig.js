var meridianDataConfig = {

	content: {
		en: {
			paymentFrequency: {
				oneTime: 'One Time Payment',
				annual: 'Annual',
				monthly: 'Monthly',
				semiMonthly: 'Semi-Monthly',
				biWeekly: 'Bi-Weekly',
				weekly: 'Weekly',
				acceleratedBiWeekly: 'Accelerated Bi-Weekly',
				acceleratedWeekly: 'Accelerated Weekly'
			},

			errors: {
				default: 'Value entered is incorrect.',
				readjust: 'Value entered has been adjusted to the minimum or maximum value allowed.',
				aboveAllowedByMortgage: 'The mortgage amount doesn\'t allow the amount to be above {{ [max] | year }}.',
				aboveAllowedPrepayment:'Prepayments of up to {{ 20 | percent }} of the original mortgage amount are allowed annually without notice or penalty. Additionally, an increase to payments of up to {{ 20 | percent }} of the original payment amount is permitted once each calendar year.'
			},

			charts: {
				chartLOC:{
					title: {
						text: 'Outstanding Loan Balance'
					},
					yAxis: {
						title: {
							text: 'Amount'
						}
					}
				},
				chartRSC:{
					title: {
						text: 'Retirement Saving Goals'
					},
					yAxis: {
						title: {
							text: 'Amount'
						}
					}
				},
				chartMPC:{
					title: {
						text: 'This illustrates the total amortization of the selected mortgage options.'
					},
					yAxis: {
						title: {
							text:'Amount'
						}
					}
				},
				chartCompareMPC:{
					title: {
						text:'This illustrates the total amortization of the selected mortgage options.'
					},
					yAxis: {
						title: {
							text:'Amount'
						}
					}
				},
				ist_highchart:{
					title: {
						text: ''
					},
					xAxis: {
						title: {
							text: 'Term'
						}
					},
					yAxis: {
						title: {
							text: 'Amount'
						}
					}
				},
				affordability:{
					tooltip: {
						pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
					}
				}
			},

			units:{
				year:'year',
				year_plural:'years',
				day:'day',
				day_plural:'days'
			},

			ui: {
				btnNext:'Next',
				btnPrevious:'Previous',
				btnBack:'Back',
				btnClose:'Close',
				btnBackToTop:'Back to top',
				startOver:'Start over',
				btnAmortizationTable:'Amortization Table',
				btnCompareScenarios:'Compare Scenarios',
				btnCompareSideBySide:'Compare Side by Side',
				btnPrintReport:'Print Report',
				btnShowReport:'Show Report',
				btnContactAdvisor:'Contact an Advisor'
			}
		},
		// TEMP FR
		fr: {
			
			errors: {
				readjust: 'Valeur Valeur Valeur Valeur Valeur Valeur Valeur Valeur '
			},

			units:{
				year:'an',
				year_plural:'ans',
				day:'jour',
				day_plural:'jours'
			},

			ui: {
				btnNext:'Suivant',
				btnPrevious:'Précédent',
				btnBack:'Retour',
				btnClose:'Fermer'
			}
		}
	},

	scenarios:{
		retirementSavingsData:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						currentAge:30,
						retirementStartAge :65,
						yearsInRetirement : 30,

						monthlyRRSPcontribution	:	100,
						monthlyTFSAcontribution	:	100,
						monthlyNONREGcontribution	:	0,

						annualIncome : 55000,
						targetIncomePercent:0.7,
						targetIncomeAmount:35000,

						oas:6846.24,
						cpp:6000,
						companyPension:100,
						otherIncome:100,
						nonRegInvestments:100,

						currentRRSPSavings:50000,
						currentTFSASavings:50000,
						currentNONREGSavings:40000,

						targetIncomeIsPercent:true
					},
					results:{}
				},
				estimatedROR:0.03,
				inflationRate: 0.02,
				addSpouse:false,
				isScenarioViewSpouse:false,
				annualRRSPlimitPerYear:{
	 				2005:16500,
	 				2006:18000,
	 				2007:19000,
	 				2008:20000,
	 				2009:21000,
	 				2010:22000,
	 				2011:22450,
	 				2012:22970,
	 				2013:23820,
	 				2014:24270,
	 				2015:24270,
	 				2016:24270
	 			},
				constants:{
					maxYears: 101,
					annualRRSPlimit: 24270
				}
			},
			results:{}
		},
		affordability:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						annualIncome:50000,
						heatingCosts:100,
						propertyTaxes:250,
						condoFees:0,
						totalOtherDebt:450,
						otherDebt:{
							vehicleLoanLease:0,
							personalLoan:0,
							lineOfCredit:0,
							creditCards:0,
							other:0
						},
						interestRate:0.025,
						amortization:25,
						downPaymentAmount:45000
					},
					results:{
						
					}
				},
				isComparingScenario:false
			},
			results:{}
		},
		lineOfCreditData:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						borrowReason:"homeRenovation",
						borrowAmount:10000,
						interestRate:0.03,
						amortization:10,
						repaymentDetails:"personalLoan",
						paymentFrequency:2
					},
					validation:{
						borrowAmount:{
							max:9999999.99,
							min:1,
							rules:['readjust']
						},
						interestRate:{
							max:0.3,
							min:0.0001,
							rules:['readjust']
						}
					},
					results:{
						
					}
				},
				isComparingScenario:false
			},
			results:{}
		},
		mortgagePaymentData:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						scenarioIndex:0,
						mortgageAmount:300000,
						productAndType:5,
						interestRate:0.0249,
						paymentFrequency:2,
						extraPaymentAmount:0,
						extraPaymentFrequency:1,
						amortization:25,
						showExtra:false
					},
					results:{
						resultsByPaymentOption:{}
					},
					validation:{
						amortization: {
							min:0,
							max:25,
							rules:['readjust',
								{
									name:'aboveAllowedByMortgage',
									validate:'readjust',
									priority:0,
									model:'message:errors.aboveAllowedByMortgage',
									customize:{
										max:'max'
									}
								}
							]
						},
						mortgageAmount: {
							min:1,
							max:10000000,
							rules:['readjust']
						}
					}
				},
				isComparingScenario:false
			},
			results:{}
		}
	},

	slider:{
		paymentFrequency:{
			start:1,
			connect: 'lower',
			step:1,
			range: {
				'min': 2,
				'max': 5
			}
		},
		ist_amount:{
			start:0,
			connect: 'lower',
			range: {
				'min': 500,
				'max': 100000
			}
		}
	},

	input:{
		amortization:{
			label:'Amortization',
			directive:'year',
			precision:0
		},
		year:{
			directive:'year',
			precision:0
		},
		interestRate:{
			label:'Interest Rate',
			directive:'percent',
			precision:3
		},
		currency2:{
			directive:'currency',
			precision:2
		},
		currency0:{
			directive:'currency',
			precision:0
		},
		percent0:{
			directive:'percent',
			precision:0
		},
		percent3:{
			directive:'percent',
			precision:3
		},
		boolean:{
			directive:'boolean',
			options:[
				{label:'Yes',value:true},
				{label:'No',value:false}
			]
		}
	},

	select:{
		paymentFrequency:{
			label:'Payment Frequency',
			options: [
				{label:'Monthly',value:2},
				{label:'Semi-monthly',value:3},
				{label:'Bi-weekly',value:4},
				{label:'Weekly',value:5},
				{label:'Accelerated Bi-weekly',value:6},
				{label:'Accelerated Weekly',value:7}
			]
		},
		reducedPaymentFrequency:{
			label:'Payment Frequency',
			options: [
				{label:'Monthly',value:2},
				{label:'Semi-monthly',value:3},
				{label:'Bi-weekly',value:4},
				{label:'Weekly',value:5}
			]
		},
		extraPaymentFrequency:{
			label:'Prepayment Frequency',
			options: [
				{label:'Annual',value:1},
				{label:'One-time',value:0},
				{label:'Monthly',value:2},
				{label:'Semi-monthly',value:3},
				{label:'Bi-weekly',value:4},
				{label:'Weekly',value:5},
				{label:'Accelerated Bi-weekly',value:6},
				{label:'Accelerated Weekly',value:7}
			]
		},
		productAndType:{
			label:'Term',
			options:[
				{label:'1 year fixed closed',value:1},
				{label:'2 year fixed closed',value:2},
				{label:'3 year fixed closed',value:3},
				{label:'4 year fixed closed',value:4},
				{label:'5 year fixed closed',value:5},
				{label:'7 year fixed closed',value:7},
				{label:'10 year fixed closed',value:10}
			]
		}						
	},

	highchart:{

		chartLOC:{
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true
			},
			yAxis: {
				min:0
			},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0.2,
					borderWidth: 0
				}
			},
			series: [{
				name: 'Balance',
				color: '#4f324c'
			}]
		},

		chartRSC: {
			colors:['#a8b400','#e68923','#3b6e98'],
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true,
				categories: []
			},
			yAxis: {},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					stacking: 'normal',
					pointPadding: 0,
					borderWidth: 0
				}
			},
			series: []
		},

		chartMPC:{
			colors:['#e68923','#a8b400','#4f324c','#7facc2','#515350','#856f8e','#266685'],
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true
			},
			yAxis: {
				min: 0
			},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0.2,
					borderWidth: 0
				}
			},
			series: []
		},

		chartCompareMPC:{
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true
			},
			yAxis: {
				min: 0
			},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0,
					borderWidth: 0
				}
			},
			series: []
		},

		ist_highchart:{
			colors:['#e68923','#a8b400','#4f324c','#7facc2','#515350','#856f8e','#266685'],
			credits:{
				enabled:false
			},
			chart:{
				type:'spline'
			},
			title: {
				text: ''
			},
			xAxis: {
				min:0,
				type: 'number',
				labels:{}
			},
			yAxis: {
				labels:{},
				title:{
					align:'high',
					style:{display:'none'},
					margin:0,
					x:0,y:0,
					rotation:0
				}
			},
			tooltip: {
	      	crosshairs: true
			},
			legend:{
				useHTML:true
			},
			plotOptions: {
				spline: {
					pointStart:0,
					states:{
						hover:{
							marker:{
								enabled:true,
								symbol:'circle',
								halo:{
									size:0
								}
							}
						}
					},
					marker: {
						enabled:false,
						symbol:'circle'
					}
				},
				arearange: {
					pointStart:0,
					states:{
						hover:{
							marker:{
								enabled:true,
								symbol:'circle',
								halo:{
									size:0
								}
							}
						}
					}
				},
				
			},
			series:[]
		},

		affordability:{
			chart: {
				plotBackgroundColor: null,
				plotBorderWidth: null,
				plotShadow: false,
				type: 'pie'
			},
			title: {
				text:''
			},
			tooltip: {
				pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
			},
			credits: {
				enabled: false
			},
			plotOptions: {
				pie: {
					allowPointSelect: true,
					cursor: 'pointer',
					dataLabels: {
						enabled: false
					},
					showInLegend: true
				}
			},
			legend: {
				layout: 'vertical',
				itemMarginBottom: 0,
				verticalAlign: 'middle',
				labelFormat: '',
				enabled: false
			},
			series: [{
				name: 'Proportion',
				colorByPoint: true,
				data: [{
					dataKey:"results.totalMonthlyMortgageYouCanAfford",//will determine which entry of the data to us as the y
					contentKey:"affGraphMortgagePayment",//will determine which entry of the content to us as the name
					color: '#a8b400'
				}, {
					dataKey:"data.heatingCosts",
					contentKey:"affGraphHeat",
					color: '#faa620'
				}, {
					dataKey:"data.propertyTaxes",
					contentKey:"affGraphPropertyTaxes",
					color: '#4f324c'
				}, {
					dataKey:"data.condoFees",
					contentKey:"affGraphCondoFees",
					color: '#39709a'
				}, {
					dataKey:"data.totalOtherDebt",
					contentKey:"affGraphTotalOtherDebt",
					color: '#39709a'
				}]
			}]
		}
	}
};

var defaultMeridianDataContent = {
	en: {

		input:{
			amortization:'Amortization',
			interestRate:'Interest Rate'
		},

		select:{
			paymentFrequency: {
				oneTime: 'One Time Payment',
				annual: 'Annual',
				monthly: 'Monthly',
				semiMonthly: 'Semi-Monthly',
				biWeekly: 'Bi-Weekly',
				weekly: 'Weekly',
				acceleratedBiWeekly: 'Accelerated Bi-Weekly',
				acceleratedWeekly: 'Accelerated Weekly',
				paymentFrequency:'Payment Frequency',
				extraPaymentFrequency:'Extra Payment Frequency'
			},

			boolean: {
				yes: 'Yes',
				no: 'No'
			},

			productAndTerm: {
				closed_1_year:'1 year fixed closed',
				closed_2_year:'2 year fixed closed',
				closed_3_year:'3 year fixed closed',
				closed_4_year:'4 year fixed closed',
				closed_5_year:'5 year fixed closed',
				closed_7_year:'7 year fixed closed',
				closed_10_year:'10 year fixed closed',
				open_5_year_variable:'5 Year Open Variable',
				closed_5_year_variable:'5 Year Closed Variable',
				open_1_year_fixed:'1 Year Open Fixed',
				convertible_6_months_fixed:'6 Month Convertible Fixed'
			}
		},

		errors: {
			default: 'Value entered is incorrect.',
			readjust: 'Value entered has been adjusted to the minimum or maximum value allowed.',
			aboveAllowedByMortgage: 'The mortgage amount doesn\'t allow the amount to be above {{ [max] | year }}.'
		},

		charts: {
			chartLOC:{
				title: {
					text: 'Outstanding Loan Balance'
				},
				yAxis: {
					title: {
						text: 'Amount'
					}
				}
			},
			chartRSC:{
				title: {
					text: 'Retirement Saving Goals'
				},
				yAxis: {
					title: {
						text: 'Amount'
					}
				}
			},
			chartMPC:{
				title: {
					text: 'This illustrates the total amortization of the selected mortgage options.'
				},
				yAxis: {
					title: {
						text:'Amount'
					}
				}
			},
			chartCompareMPC:{
				title: {
					text:'This illustrates the total amortization of the selected mortgage options.'
				},
				yAxis: {
					title: {
						text:'Amount'
					}
				}
			},
			ist_highchart:{
				title: {
					text: ''
				},
				xAxis: {
					title: {
						text: 'Term'
					}
				},
				yAxis: {
					title: {
						text: 'Amount'
					}
				}
			},
			affordability:{
				tooltip: {
					pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
				}
			}
		},

		units:{
			year:'year',
			year_plural:'years',
			day:'day',
			day_plural:'days'
		},

		ui: {
			btnNext:'Next',
			btnPrevious:'Previous',
			btnBack:'Back',
			btnClose:'Close',
			btnBackToTop:'Back to top',
			startOver:'Start over',
			btnAmortizationTable:'Amortization Table',
			btnCompareScenarios:'Compare Scenarios',
			btnCompareSideBySide:'Compare Side by Side',
			btnPrintReport:'Print Report',
			btnShowReport:'Show Report',
			btnContactAdvisor:'Contact an Advisor'
		}
	}
};

window.defaultMeridianDataConfig = {
	scenarios:{
		
		retirementSavingsData:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						currentAge:30,
						retirementStartAge :65,
						yearsInRetirement : 30,

						monthlyRRSPcontribution	:	100,
						monthlyTFSAcontribution	:	100,
						monthlyNONREGcontribution	:	0,

						annualIncome : 55000,
						targetIncomePercent:0.7,
						targetIncomeAmount:35000,

						oas:6846.24,
						cpp:6000,
						companyPension:100,
						otherIncome:100,
						nonRegInvestments:100,

						currentRRSPSavings:50000,
						currentTFSASavings:50000,
						currentNONREGSavings:40000,

						targetIncomeIsPercent:true
					},
					results:{}
				},
				estimatedROR:0.03,
				inflationRate: 0.02,
				addSpouse:false,
				isScenarioViewSpouse:false,
				annualRRSPlimitPerYear:{
	 				2005:16500,
	 				2006:18000,
	 				2007:19000,
	 				2008:20000,
	 				2009:21000,
	 				2010:22000,
	 				2011:22450,
	 				2012:22970,
	 				2013:23820,
	 				2014:24270,
	 				2015:24270,
	 				2016:24270
	 			},
				constants:{
					maxYears: 101,
					annualRRSPlimit: 24270
				}
			},
			results:{}
		},
		affordability:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						annualIncome:50000,
						heatingCosts:100,
						propertyTaxes:250,
						condoFees:0,
						totalOtherDebt:450,
						otherDebt:{
							vehicleLoanLease:0,
							personalLoan:0,
							lineOfCredit:0,
							creditCards:0,
							other:0
						},
						interestRate:0.025,
						amortization:25,
						downPaymentAmount:45000
					},
					results:{ }
				},
				isComparingScenario:false
			},
			results:{}
		},
		lineOfCreditData:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						borrowReason:"homeRenovation",
						borrowAmount:10000,
						interestRate:0.03,
						amortization:10,
						repaymentDetails:"personalLoan",
						paymentFrequency:2
					},
					validation:{
						borrowAmount:{
							max:9999999.99,
							min:1,
							rules:['readjust']
						},
						interestRate:{
							max:0.3,
							min:0.0001,
							rules:['readjust']
						}
					},
					results:{
						
					}
				},
				isComparingScenario:false
			},
			results:{}
		},
		mortgagePaymentData:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						scenarioIndex:0,
						mortgageAmount:300000,
						productAndType:5,
						interestRate:0.0249,
						paymentFrequency:2,
						extraPaymentAmount:0,
						extraPaymentAnnualAmount:0,
						extraPaymentFrequency:1,
						amortization:25,
						showExtra:false
					},
					results:{
						resultsByPaymentOption:{ }
					},
					validation:{
						amortization: {
							configModel:'validation.amortization'
							// min:5,
							// max:25,
							// // dependancy:{
							// // 	max:3000
							// // },
							// rules:[
							// 	{
							// 		configModel:'validation.rules.readjust'
							// 	},
							// 	{
							// 		// This one has no validate method AND isn't a default validation => will not validate
							// 		name:'aboveAllowedByMortgage',
							// 		validate:'readjust',
							// 		priority:0,
							// 		contentModel:'message:errors.aboveAllowedByMortgage',
							// 		// Compiling the message allows for angular expressions to be rendered
							// 		// message:'The mortgage amount doesn\'t allow the amount to be above {{ [max] | year }}.',
							// 		customize:{
							// 			// values here are paths present in the validation object (min,max... more can be set using validator.set('name',value) )
							// 			max:'max' // 25
							// 			// max:'dependancy.max' // 3000
							// 		}
							// 	}
							// ]
						},
						mortgageAmount: {
							min:1,
							max:10000000,
							rules:[ {configModel:'validation.rules.readjust'} ]
						},
						interestRate: {
							configModel:'validation.interestRate'
						},
						extraPaymentAmount: {
							min:0,
							max:100000,
							rules:[ {configModel:'validation.rules.readjust'} ]
						},
						extraPaymentAnnualAmount: {
							min:0,
							max:100000,
							rules:[ {configModel:'validation.rules.readjust'} ]
						}
					}
				},
				isComparingScenario:false
			},
			results:{}
		}
	},

	validation:{
		rules:{
			readjust: {
				name:'readjust',
				contentModel:'message:errors.readjust'
			}
		},
		interestRate: {
			min:0.1,
			max:20,
			rules:[{configModel:'validation.rules.readjust'}]
		},
		amortization: {
			min:5,
			max:25,
			rules:[{configModel:'validation.rules.readjust'}]
		}
	},

	slider:{
		paymentFrequency:{
			start:1,
			connect: 'lower',
			step:1,
			range: {
				'min': 2,
				'max': 5
			}
		},
		ist_amount:{
			start:0,
			connect: 'lower',
			range: {
				'min': 500,
				'max': 100000
			}
		}
	},
	
	input:{
		amortization:{
			contentModel:'label:input.amortization.label',
			directive:'year',
			precision:0
		},
		year:{
			directive:'year',
			precision:0
		},
		interestRate:{
			contentModel:'label:input.interestRate.label',
			directive:'percent',
			precision:3
		},
		currency2:{
			directive:'currency',
			precision:2
		},
		currency0:{
			directive:'currency',
			precision:0
		},
		percent0:{
			directive:'percent',
			precision:0
		},
		percent3:{
			directive:'percent',
			precision:3
		},
		boolean:{
			directive:'boolean',
			options:[
				{contentModel:'label:select.boolean.yes',value:true},
				{contentModel:'label:select.boolean.no',value:false}
			]
		}
	},

	select:{
		paymentFrequencyOptions:{
			annual:{
				contentModel:'label:select.paymentFrequency.annual',
				value:1
			},
			oneTime:{
				contentModel:'label:select.paymentFrequency.oneTime',
				value:0
			},
			monthly:{
				contentModel:'label:select.paymentFrequency.monthly',
				value:2
			},
			semiMonthly:{
				contentModel:'label:select.paymentFrequency.semiMonthly',
				value:3
			},
			biWeekly:{
				contentModel:'label:select.paymentFrequency.biWeekly',
				value:4
			},
			weekly:{
				contentModel:'label:select.paymentFrequency.weekly',
				value:5
			},
			acceleratedBiWeekly:{
				contentModel:'label:select.paymentFrequency.acceleratedBiWeekly',
				value:6
			},
			acceleratedWeekly:{
				contentModel:'label:select.paymentFrequency.acceleratedWeekly',
				value:7
			},
		},
		productAndTermOptions: {
			closed_1_year:{
				contentModel:'label:select.productAndTerm.closed_1_year',
				value:1,
				yearValue:1
			},
			closed_2_year:{
				contentModel:'label:select.productAndTerm.closed_2_year',
				value:2,
				yearValue:2
			},
			closed_3_year:{
				contentModel:'label:select.productAndTerm.closed_3_year',
				value:3,
				yearValue:3
			},
			closed_4_year:{
				contentModel:'label:select.productAndTerm.closed_4_year',
				value:4,
				yearValue:4
			},
			closed_5_year:{
				contentModel:'label:select.productAndTerm.closed_5_year',
				value:5,
				yearValue:5
			},
			closed_7_year:{
				contentModel:'label:select.productAndTerm.closed_7_year',
				value:7,
				yearValue:7
			},
			closed_10_year:{
				contentModel:'label:select.productAndTerm.closed_10_year',
				value:10,
				yearValue:10
			},
			open_5_year_variable:{
				contentModel:'label:select.productAndTerm.open_5_year_variable',
				value:11,
				yearValue:5
			},
			closed_5_year_variable:{
				contentModel:'label:select.productAndTerm.closed_5_year_variable',
				value:12,
				yearValue:5
			},
			open_1_year_fixed:{
				contentModel:'label:select.productAndTerm.open_1_year_fixed',
				value:13,
				yearValue:1
			},
			convertible_6_months_fixed:{
				contentModel:'label:select.productAndTerm.convertible_6_months_fixed',
				value:14,
				yearValue:0.5
			}
		},
		paymentFrequency:{
			contentModel:'label:select.paymentFrequency.paymentFrequency',
			options: [
				{configModel:'select.paymentFrequencyOptions.monthly'},
				{configModel:'select.paymentFrequencyOptions.semiMonthly'},
				{configModel:'select.paymentFrequencyOptions.biWeekly'},
				{configModel:'select.paymentFrequencyOptions.weekly'},
				{configModel:'select.paymentFrequencyOptions.acceleratedBiWeekly'},
				{configModel:'select.paymentFrequencyOptions.acceleratedWeekly'}
			]
		},
		reducedPaymentFrequency:{
			contentModel:'label:select.paymentFrequency.paymentFrequency',
			options: [
				{configModel:'select.paymentFrequencyOptions.monthly'},
				{configModel:'select.paymentFrequencyOptions.semiMonthly'},
				{configModel:'select.paymentFrequencyOptions.biWeekly'},
				{configModel:'select.paymentFrequencyOptions.weekly'}
			]
		},
		extraPaymentFrequency:{
			contentModel:'label:select.paymentFrequency.paymentFrequency',
			options: [
				{configModel:'select.paymentFrequencyOptions.annual'},
				{configModel:'select.paymentFrequencyOptions.oneTime'},
				{configModel:'select.paymentFrequencyOptions.monthly'},
				{configModel:'select.paymentFrequencyOptions.semiMonthly'},
				{configModel:'select.paymentFrequencyOptions.biWeekly'},
				{configModel:'select.paymentFrequencyOptions.weekly'},
				{configModel:'select.paymentFrequencyOptions.acceleratedBiWeekly'},
				{configModel:'select.paymentFrequencyOptions.acceleratedWeekly'}
			]
		},
		productAndType:{
			options:[
				{configModel:'select.productAndTermOptions.open_5_year_variable'},
				{configModel:'select.productAndTermOptions.closed_5_year_variable'},
				{configModel:'select.productAndTermOptions.open_1_year_fixed'},
				{configModel:'select.productAndTermOptions.convertible_6_months_fixed'},
				{configModel:'select.productAndTermOptions.closed_1_year'},
				{configModel:'select.productAndTermOptions.closed_2_year'},
				{configModel:'select.productAndTermOptions.closed_3_year'},
				{configModel:'select.productAndTermOptions.closed_4_year'},
				{configModel:'select.productAndTermOptions.closed_5_year'},
				{configModel:'select.productAndTermOptions.closed_7_year'},
				{configModel:'select.productAndTermOptions.closed_10_year'}
			]
		}						
	},

	highchart:{

		chartLOC:{
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true
			},
			yAxis: {
				min:0
			},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0.2,
					borderWidth: 0
				}
			},
			series: [{
				name: 'Balance',
				color: '#4f324c'
			}]
		},

		chartRSC: {
			colors:['#a8b400','#e68923','#3b6e98'],
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true,
				categories: []
			},
			yAxis: {},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					stacking: 'normal',
					pointPadding: 0,
					borderWidth: 0
				}
			},
			series: []
		},

		chartMPC:{
			colors:['#e68923','#a8b400','#4f324c','#7facc2','#515350','#856f8e','#266685'],
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true
			},
			yAxis: {
				min: 0
			},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0.2,
					borderWidth: 0
				}
			},
			series: []
		},

		chartCompareMPC:{
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true
			},
			yAxis: {
				min: 0
			},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0,
					borderWidth: 0
				}
			},
			series: []
		},

		ist_highchart:{
			colors:['#e68923','#a8b400','#4f324c','#7facc2','#515350','#856f8e','#266685'],
			credits:{
				enabled:false
			},
			chart:{
				type:'spline'
			},
			title: {
				text: ''
			},
			xAxis: {
				min:0,
				type: 'number',
				labels:{}
			},
			yAxis: {
				labels:{},
				title:{
					align:'high',
					style:{display:'none'},
					margin:0,
					x:0,y:0,
					rotation:0
				}
			},
			tooltip: {
	      	crosshairs: true
			},
			legend:{
				useHTML:true
			},
			plotOptions: {
				spline: {
					pointStart:0,
					states:{
						hover:{
							marker:{
								enabled:true,
								symbol:'circle',
								halo:{
									size:0
								}
							}
						}
					},
					marker: {
						enabled:false,
						symbol:'circle'
					}
				},
				arearange: {
					pointStart:0,
					states:{
						hover:{
							marker:{
								enabled:true,
								symbol:'circle',
								halo:{
									size:0
								}
							}
						}
					}
				},
				
			},
			series:[]
		},

		affordability:{
			chart: {
				plotBackgroundColor: null,
				plotBorderWidth: null,
				plotShadow: false,
				type: 'pie'
			},
			title: {
				text:''
			},
			tooltip: {
				pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
			},
			credits: {
				enabled: false
			},
			plotOptions: {
				pie: {
					allowPointSelect: true,
					cursor: 'pointer',
					dataLabels: {
						enabled: false
					},
					showInLegend: true
				}
			},
			legend: {
				layout: 'vertical',
				itemMarginBottom: 0,
				verticalAlign: 'middle',
				labelFormat: '',
				enabled: false
			},
			series: [{
				name: 'Proportion',
				colorByPoint: true,
				data: [{
					dataKey:"results.totalMonthlyMortgageYouCanAfford",//will determine which entry of the data to us as the y
					contentKey:"affGraphMortgagePayment",//will determine which entry of the content to us as the name
					color: '#a8b400'
				}, {
					dataKey:"data.heatingCosts",
					contentKey:"affGraphHeat",
					color: '#faa620'
				}, {
					dataKey:"data.propertyTaxes",
					contentKey:"affGraphPropertyTaxes",
					color: '#4f324c'
				}, {
					dataKey:"data.condoFees",
					contentKey:"affGraphCondoFees",
					color: '#39709a'
				}, {
					dataKey:"data.totalOtherDebt",
					contentKey:"affGraphTotalOtherDebt",
					color: '#39709a'
				}]
			}]
		}
	}
};