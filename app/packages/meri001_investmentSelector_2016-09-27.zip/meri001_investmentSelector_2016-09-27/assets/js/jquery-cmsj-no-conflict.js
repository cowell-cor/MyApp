var $cmsj = $.noConflict(true);
// var $cmsj = $;