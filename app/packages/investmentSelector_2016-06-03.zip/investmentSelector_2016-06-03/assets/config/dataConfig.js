var meridianDataConfig = {

	content: {
		en: {
			paymentFrequency: {
				oneTime: 'One Time Payment',
				annual: 'Annual',
				monthly: 'Monthly',
				semiMonthly: 'Semi-Monthly',
				biWeekly: 'Bi-Weekly',
				weekly: 'Weekly',
				acceleratedBiWeekly: 'Accelerated Bi-Weekly',
				acceleratedWeekly: 'Accelerated Weekly'
			},

			charts: {
				chartLOC:{
					title: {
						text: 'Outstanding Loan Balance'
					},
					yAxis: {
						title: {
							text: 'Amount'
						}
					}
				},
				chartRSC:{
					title: {
						text: 'Retirement Saving Goals'
					},
					yAxis: {
						title: {
							text: 'Amount'
						}
					}
				},
				chartMPC:{
					title: {
						text: 'This illustrates the total amortization of the selected mortgage options.'
					},
					yAxis: {
						title: {
							text:'Amount'
						}
					}
				},
				chartCompareMPC:{
					title: {
						text:'This illustrates the total amortization of the selected mortgage options.'
					},
					yAxis: {
						title: {
							text:'Amount'
						}
					}
				},
				ist_highchart:{
					title: {
						text: ''
					},
					xAxis: {
						title: {
							text: 'Term'
						}
					},
					yAxis: {
						title: {
							text: 'Amount'
						}
					}
				},
				affordability:{
					tooltip: {
						pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
					}
				}
			},

			units:{
				year:'year',
				year_plural:'years',
				day:'day',
				day_plural:'days'
			},

			ui: {
				btnNext:'Next',
				btnPrevious:'Previous',
				btnBack:'Back',
				btnClose:'Close',
				btnBackToTop:'Back to top',
				startOver:'Start over',
				btnAmortizationTable:'Amortization Table',
				btnCompareScenarios:'Compare Scenarios',
				btnCompareSideBySide:'Compare Side by Side',
				btnPrintReport:'Print Report',
				btnShowReport:'Show Report',
				btnContactAdvisor:'Contact an Advisor'
			}
		}
	},

	scenarios:{
		retirementSavingsData:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						currentAge:30,
						retirementStartAge :65,
						yearsInRetirement : 30,

						monthlyRRSPcontribution	:	100,
						monthlyTFSAcontribution	:	100,
						monthlyNONREGcontribution	:	0,

						annualIncome : 55000,
						targetIncomePercent:0.7,
						targetIncomeAmount:35000,

						oas:6846.24,
						cpp:6000,
						companyPension:100,
						otherIncome:100,
						nonRegInvestments:100,

						currentRRSPSavings:50000,
						currentTFSASavings:50000,
						currentNONREGSavings:40000,

						targetIncomeIsPercent:true,

						estimatedROR:0.03
					},
					results:{}
				},
				addSpouse:false,
				isScenarioViewSpouse:false,
				annualRRSPlimitPerYear:{
	 				2005:16500,
	 				2006:18000,
	 				2007:19000,
	 				2008:20000,
	 				2009:21000,
	 				2010:22000,
	 				2011:22450,
	 				2012:22970,
	 				2013:23820,
	 				2014:24270,
	 				2015:24270,
	 				2016:24270
	 			},
				constants:{
					maxYears: 101,
					inflationRate: 0.02,
					annualRRSPlimit: 24270
				}
			},
			results:{}
		},
		affordability:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						annualIncome:50000,
						heatingCosts:100,
						propertyTaxes:250,
						condoFees:0,
						totalOtherDebt:450,
						otherDebt:{
							vehicleLoanLease:0,
							personalLoan:0,
							lineOfCredit:0,
							creditCards:0,
							other:0
						},
						interestRate:0.025,
						amortization:25,
						downPaymentAmount:45000
					},
					results:{
						
					}
				},
				isComparingScenario:false
			},
			results:{}
		},
		lineOfCreditData:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						borrowReason:"homeRenovation",
						borrowAmount:10000,
						interestRate:0.03,
						amortization:10,
						repaymentDetails:"personalLoan",
						paymentFrequency:2
					},
					results:{
						
					}
				},
				isComparingScenario:false
			},
			results:{}
		},
		mortgagePaymentData:{
			data:{
				scenarios:[],
				scenarioModel:{
					data:{
						scenarioIndex:0,
						mortgageAmount:500000,
						productAndType:10,
						interestRate:0.035,
						paymentFrequency:4,
						extraPaymentAmount:100,
						extraPaymentFrequency:1,
						amortization:25,
						showExtra:false
					},
					results:{
						//current:{},
						resultsByPaymentOption:{
							// monthly:{},
							// semiMonthly:{},
							// biWeekly:{},
							// weekly:{},
							// acceleratedBiWeekly:{},
							// acceleratedWeekly:{},
						}
					}
				},
				isComparingScenario:false
			},
			results:{}
		}
	},

	slider:{
		paymentFrequency:{
			start:1,
			connect: 'lower',
			step:1,
			range: {
				'min': 2,
				'max': 5
			}
		},
		ist_amount:{
			start:0,
			connect: 'lower',
			range: {
				'min': 500,
				'max': 100000
			}
		}
	},
	
	input:{
		amortization:{
			label:'Amortization',
			min:1,
			max:25,
			directive:'number:year',
			precision:0
		},
		year:{
			directive:'number:year',
			precision:0
		},
		interestRate:{
			label:'Interest Rate',
			directive:'number:percent',
			precision:3
		},
		currency2:{
			directive:'number:currency',
			precision:2
		},
		currency0:{
			directive:'number:currency',
			precision:0
		},
		percent0:{
			directive:'number:percent',
			precision:0
		},
		percent3:{
			directive:'number:percent',
			precision:3
		},
		boolean:{
			directive:'boolean',
			options:[
				{label:'Yes',value:true},
				{label:'No',value:false}
			]
		}
	},

	select:{
		paymentFrequency:{
			label:'Payment Frequency',
			// model:'label.text:meridianDataConfig.content.en.charts.chartLOC.title.text',
			options: [
				{label:'Monthly',value:2},
				{label:'Semi-monthly',value:3},
				{label:'Bi-weekly',value:4},
				{label:'Weekly',value:5},
				{label:'Accelerated Bi-weekly',value:6},
				{label:'Accelerated Weekly',value:7}
			]
		},
		reducedPaymentFrequency:{
			label:'Payment Frequency',
			options: [
				{label:'Monthly',value:2},
				{label:'Semi-monthly',value:3},
				{label:'Bi-weekly',value:4},
				{label:'Weekly',value:5}
			]
		},
		extraPaymentFrequency:{
			label:'Extra Payment Frequency',
			options: [
				{label:'Annual',value:1},
				{label:'One-time',value:0},
				{label:'Monthly',value:2},
				{label:'Semi-monthly',value:3},
				{label:'Bi-weekly',value:4},
				{label:'Weekly',value:5},
				{label:'Accelerated Bi-weekly',value:6},
				{label:'Accelerated Weekly',value:7}
			]
		},
		productAndType:{
			label:'Product and Term',
			options:[
				{label:'1 year fixed closed',value:1},
				{label:'2 year fixed closed',value:2},
				{label:'3 year fixed closed',value:3},
				{label:'4 year fixed closed',value:4},
				{label:'5 year fixed closed',value:5},
				{label:'7 year fixed closed',value:7},
				{label:'10 year fixed closed',value:10}
			]
		}						
	},

	radio:{

	},

	checkBox:{

	},

	highchart:{

		chartLOC:{
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true
			},
			yAxis: {
				min:0
			},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0.2,
					borderWidth: 0
				}
			},
			series: [{
				name: 'Balance',
				color: '#4f324c'
			}]
		},

		chartRSC: {
			colors:['#a8b400','#e68923','#3b6e98'],
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true,
				categories: []
			},
			yAxis: {},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					stacking: 'normal',
					pointPadding: 0,
					borderWidth: 0
				}
			},
			series: []
		},

		chartMPC:{
			colors:['#e68923','#a8b400','#4f324c','#7facc2','#515350','#856f8e','#266685'],
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true
			},
			yAxis: {
				min: 0
			},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0.2,
					borderWidth: 0
				}
			},
			series: []
		},

		chartCompareMPC:{
			chart: {
				type: 'column'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				crosshair: true
			},
			yAxis: {
				min: 0
			},
			tooltip: {
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0,
					borderWidth: 0
				}
			},
			series: []
		},

		ist_highchart:{
			colors:['#e68923','#a8b400','#4f324c','#7facc2','#515350','#856f8e','#266685'],
			credits:{
				enabled:false
			},
			chart:{
				type:'spline'
			},
			title: {
				text: ''
			},
			xAxis: {
				min:0,
				type: 'number',
				labels:{}
			},
			yAxis: {
				labels:{},
				title:{
					align:'high',
					style:{display:'none'},
					margin:0,
					x:0,y:0,
					rotation:0
				}
			},
			tooltip: {
	      	crosshairs: true
			},
			legend:{
				useHTML:true
			},
			plotOptions: {
				spline: {
					pointStart:0,
					states:{
						hover:{
							marker:{
								enabled:true,
								symbol:'circle',
								halo:{
									size:0
								}
							}
						}
					},
					marker: {
						enabled:false,
						symbol:'circle'
					}
				},
				arearange: {
					pointStart:0,
					states:{
						hover:{
							marker:{
								enabled:true,
								symbol:'circle',
								halo:{
									size:0
								}
							}
						}
					}
				},
				
			},
			series:[]
		},

		affordability:{
			chart: {
				plotBackgroundColor: null,
				plotBorderWidth: null,
				plotShadow: false,
				type: 'pie'
			},
			title: {
				text:''
			},
			tooltip: {
				pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
			},
			credits: {
				enabled: false
			},
			plotOptions: {
				pie: {
					allowPointSelect: true,
					cursor: 'pointer',
					dataLabels: {
						enabled: false
					},
					showInLegend: true
				}
			},
			legend: {
				layout: 'vertical',
				itemMarginBottom: 0,
				verticalAlign: 'middle',
				labelFormat: '',
				enabled: false
			},
			series: [{
				name: 'Proportion',
				colorByPoint: true,
				data: [{
					dataKey:"results.totalMonthlyMortgageYouCanAfford",//will determine which entry of the data to us as the y
					contentKey:"affGraphMortgagePayment",//will determine which entry of the content to us as the name
					color: '#a8b400'
				}, {
					dataKey:"data.heatingCosts",
					contentKey:"affGraphHeat",
					color: '#faa620'
				}, {
					dataKey:"data.propertyTaxes",
					contentKey:"affGraphPropertyTaxes",
					color: '#4f324c'
				}, {
					dataKey:"data.condoFees",
					contentKey:"affGraphCondoFees",
					color: '#39709a'
				}, {
					dataKey:"data.totalOtherDebt",
					contentKey:"affGraphTotalOtherDebt",
					color: '#39709a'
				}]
			}]
		}
	}
}